import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sun, Moon, Menu, X, Zap, ChevronDown } from 'lucide-react';
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

interface HeaderProps {
  isDark: boolean;
  toggleTheme: () => void;
  activeSection: string;
  setActiveSection: (section: string) => void;
  showLoginButton?: boolean;
  onLoginClick?: () => void;
}

export default function Header({ isDark, toggleTheme, activeSection, setActiveSection, showLoginButton = false, onLoginClick }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'services', label: 'Services' },
    { id: 'projects', label: 'Projects' },
    { id: 'news', label: 'News' },
    { id: 'contact', label: 'Contact' }
  ];

  const glassStyle = {
    background: isDark 
      ? 'rgba(15, 23, 42, 0.7)' 
      : 'rgba(255, 255, 255, 0.8)',
    backdropFilter: 'blur(20px)',
    border: `1px solid ${isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'}`,
  };

  return (
    <motion.header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled ? 'py-2' : 'py-4'
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, type: "spring" }}
    >
      <nav 
        className="mx-4 lg:mx-8 rounded-2xl p-4 lg:p-6 shadow-xl"
        style={glassStyle}
      >
        <div className="flex items-center justify-between">
          {/* Logo */}
          <motion.div 
            className="flex items-center space-x-3"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 400 }}
          >
            <div className="relative">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-green-500 rounded-xl flex items-center justify-center shadow-lg">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <motion.div 
                className="absolute inset-0 bg-gradient-to-br from-blue-400 to-green-400 rounded-xl opacity-50"
                animate={{ 
                  scale: [1, 1.2, 1],
                  opacity: [0.5, 0.8, 0.5]
                }}
                transition={{ 
                  duration: 2,
                  repeat: Infinity,
                  repeatType: "loop"
                }}
              />
            </div>
            <div>
              <h1 className="font-bold text-lg lg:text-xl bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
                BPDB
              </h1>
              <p className="text-xs text-muted-foreground hidden lg:block">
                Power Development Board
              </p>
            </div>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-1">
            {navItems.map((item) => (
              <motion.div key={item.id} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  variant={activeSection === item.id ? "default" : "ghost"}
                  onClick={() => setActiveSection(item.id)}
                  className={`relative px-4 py-2 rounded-xl transition-all duration-300 ${
                    activeSection === item.id 
                      ? 'bg-gradient-to-r from-blue-500 to-green-500 text-white shadow-lg' 
                      : 'hover:bg-white/20 dark:hover:bg-white/10'
                  }`}
                >
                  {item.label}
                  {activeSection === item.id && (
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-blue-400 to-green-400 rounded-xl -z-10"
                      layoutId="activeTab"
                      transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    />
                  )}
                </Button>
              </motion.div>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-2">
            {/* Login Button */}
            {showLoginButton && onLoginClick && (
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  onClick={onLoginClick}
                  className="hidden lg:flex bg-gradient-to-r from-blue-500 to-green-500 text-white shadow-lg hover:from-blue-600 hover:to-green-600 transition-all duration-300 rounded-xl px-6"
                >
                  Staff Login
                </Button>
              </motion.div>
            )}

            {/* Theme Toggle */}
            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="rounded-xl w-10 h-10 hover:bg-white/20 dark:hover:bg-white/10 transition-all duration-300"
              >
                <AnimatePresence mode="wait" initial={false}>
                  <motion.div
                    key={isDark ? 'moon' : 'sun'}
                    initial={{ y: -20, opacity: 0, rotate: -180 }}
                    animate={{ y: 0, opacity: 1, rotate: 0 }}
                    exit={{ y: 20, opacity: 0, rotate: 180 }}
                    transition={{ duration: 0.3 }}
                  >
                    {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                  </motion.div>
                </AnimatePresence>
              </Button>
            </motion.div>

            {/* Emergency Badge */}
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="hidden lg:block"
            >
              <Badge 
                variant="destructive" 
                className="bg-red-500/20 text-red-600 dark:text-red-400 border border-red-500/30 animate-pulse"
              >
                Emergency: 999
              </Badge>
            </motion.div>

            {/* Mobile Menu Toggle */}
            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} className="lg:hidden">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="rounded-xl w-10 h-10 hover:bg-white/20 dark:hover:bg-white/10"
              >
                <AnimatePresence mode="wait">
                  <motion.div
                    key={isMenuOpen ? 'close' : 'open'}
                    initial={{ rotate: -180, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: 180, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                  </motion.div>
                </AnimatePresence>
              </Button>
            </motion.div>
          </div>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="lg:hidden mt-4 pt-4 border-t border-white/20 dark:border-white/10"
            >
              <div className="grid grid-cols-2 gap-2">
                {navItems.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Button
                      variant={activeSection === item.id ? "default" : "ghost"}
                      onClick={() => {
                        setActiveSection(item.id);
                        setIsMenuOpen(false);
                      }}
                      className={`w-full justify-start rounded-xl transition-all duration-300 ${
                        activeSection === item.id 
                          ? 'bg-gradient-to-r from-blue-500 to-green-500 text-white' 
                          : 'hover:bg-white/20 dark:hover:bg-white/10'
                      }`}
                    >
                      {item.label}
                    </Button>
                  </motion.div>
                ))}
              </div>
              
              <motion.div 
                className="mt-4 pt-4 border-t border-white/20 dark:border-white/10 space-y-3"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                {/* Mobile Login Button */}
                {showLoginButton && onLoginClick && (
                  <Button
                    onClick={() => {
                      onLoginClick();
                      setIsMenuOpen(false);
                    }}
                    className="w-full bg-gradient-to-r from-blue-500 to-green-500 text-white shadow-lg hover:from-blue-600 hover:to-green-600 transition-all duration-300 rounded-xl"
                  >
                    Staff Login
                  </Button>
                )}

                <Badge 
                  variant="destructive" 
                  className="w-full justify-center bg-red-500/20 text-red-600 dark:text-red-400 border border-red-500/30 animate-pulse"
                >
                  Emergency Hotline: 999
                </Badge>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </motion.header>
  );
}