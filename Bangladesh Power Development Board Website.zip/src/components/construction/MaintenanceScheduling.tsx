import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Calendar, Clock, Wrench, AlertTriangle, CheckCircle, 
  Settings, User, MapPin, FileText, Plus, Search, Filter,
  TrendingUp, BarChart3, Target, RefreshCw, Tool, X, Bell
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

interface MaintenanceTask {
  id: string;
  equipmentId: string;
  equipmentName: string;
  taskType: 'Preventive' | 'Corrective' | 'Emergency' | 'Inspection' | 'Calibration';
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Scheduled' | 'In Progress' | 'Completed' | 'Overdue' | 'Cancelled';
  scheduledDate: string;
  completedDate?: string;
  estimatedHours: number;
  actualHours?: number;
  description: string;
  location: string;
  projectId: string;
  projectName: string;
  assignedTechnician: string;
  supervisor: string;
  checklist: {
    id: string;
    task: string;
    completed: boolean;
    notes?: string;
  }[];
  partsRequired: {
    id: string;
    name: string;
    quantity: number;
    available: boolean;
    cost: number;
  }[];
  safetyRequirements: string[];
  completionNotes?: string;
  nextMaintenanceDate?: string;
  cost: number;
  downtime: number; // in hours
}

interface MaintenanceSchedule {
  id: string;
  equipmentId: string;
  equipmentName: string;
  maintenanceType: 'Daily' | 'Weekly' | 'Monthly' | 'Quarterly' | 'Annually' | 'Custom';
  frequency: number; // in days
  lastMaintenance: string;
  nextMaintenance: string;
  assignedTeam: string;
  estimatedDuration: number;
  priority: 'Low' | 'Medium' | 'High';
  active: boolean;
  createdBy: string;
  createdDate: string;
}

interface WorkOrder {
  id: string;
  requestedBy: string;
  requestDate: string;
  equipmentId: string;
  equipmentName: string;
  issueDescription: string;
  urgency: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Open' | 'Assigned' | 'In Progress' | 'Completed' | 'Closed';
  assignedTo?: string;
  assignedDate?: string;
  completedDate?: string;
  resolution?: string;
  cost: number;
  approver?: string;
  approvalDate?: string;
}

const mockMaintenanceTasks: MaintenanceTask[] = [
  {
    id: '1',
    equipmentId: 'EQ001',
    equipmentName: 'Tower Crane TC-7032',
    taskType: 'Preventive',
    priority: 'Medium',
    status: 'Scheduled',
    scheduledDate: '2024-09-05',
    estimatedHours: 8,
    description: 'Monthly preventive maintenance including lubrication, safety check, and component inspection',
    location: 'Payra Coal Power Plant - Main Site',
    projectId: '1',
    projectName: 'Payra Coal Power Plant Unit 2',
    assignedTechnician: 'Ahmed Rahman',
    supervisor: 'Chief Technician',
    checklist: [
      { id: '1', task: 'Check hydraulic oil level and quality', completed: false },
      { id: '2', task: 'Inspect wire ropes for wear and damage', completed: false },
      { id: '3', task: 'Test all safety systems', completed: false },
      { id: '4', task: 'Lubricate all moving parts', completed: false },
      { id: '5', task: 'Check electrical connections', completed: false }
    ],
    partsRequired: [
      { id: '1', name: 'Hydraulic Oil', quantity: 50, available: true, cost: 15000 },
      { id: '2', name: 'Grease', quantity: 10, available: true, cost: 5000 },
      { id: '3', name: 'Wire Rope (backup)', quantity: 1, available: false, cost: 85000 }
    ],
    safetyRequirements: ['Lock Out Tag Out (LOTO)', 'Fall Protection', 'Hard Hat and Safety Harness'],
    nextMaintenanceDate: '2024-10-05',
    cost: 25000,
    downtime: 4
  },
  {
    id: '2',
    equipmentId: 'EQ002',
    equipmentName: 'Mobile Generator Gen-450',
    taskType: 'Corrective',
    priority: 'High',
    status: 'In Progress',
    scheduledDate: '2024-08-28',
    estimatedHours: 12,
    actualHours: 8,
    description: 'Repair cooling system malfunction - replace radiator and coolant pump',
    location: 'Equipment Yard - Section B',
    projectId: '2',
    projectName: 'Dhaka-Cumilla Transmission',
    assignedTechnician: 'Nasir Ahmed',
    supervisor: 'Mechanical Supervisor',
    checklist: [
      { id: '1', task: 'Drain coolant system', completed: true, notes: 'Completed - found contaminated coolant' },
      { id: '2', task: 'Remove damaged radiator', completed: true },
      { id: '3', task: 'Install new radiator', completed: false },
      { id: '4', task: 'Replace coolant pump', completed: false },
      { id: '5', task: 'Refill and test cooling system', completed: false }
    ],
    partsRequired: [
      { id: '1', name: 'Radiator Assembly', quantity: 1, available: true, cost: 120000 },
      { id: '2', name: 'Coolant Pump', quantity: 1, available: true, cost: 45000 },
      { id: '3', name: 'Coolant Fluid', quantity: 20, available: true, cost: 8000 }
    ],
    safetyRequirements: ['Hot Surface Protection', 'Chemical Handling PPE', 'Eye Protection'],
    cost: 180000,
    downtime: 12
  },
  {
    id: '3',
    equipmentId: 'EQ003',
    equipmentName: 'Excavator EX-200',
    taskType: 'Inspection',
    priority: 'Low',
    status: 'Completed',
    scheduledDate: '2024-08-25',
    completedDate: '2024-08-25',
    estimatedHours: 4,
    actualHours: 3,
    description: '1000-hour service inspection and maintenance',
    location: 'Rooppur Nuclear Site - Area C',
    projectId: '3',
    projectName: 'Rooppur Nuclear Infrastructure',
    assignedTechnician: 'Golam Rahman',
    supervisor: 'Site Engineer',
    checklist: [
      { id: '1', task: 'Check engine oil and filters', completed: true, notes: 'Oil changed, filters replaced' },
      { id: '2', task: 'Inspect hydraulic system', completed: true, notes: 'All systems operating normally' },
      { id: '3', task: 'Check track tension and wear', completed: true, notes: 'Minor adjustment made' },
      { id: '4', task: 'Test all controls and safety features', completed: true, notes: 'All functions tested OK' }
    ],
    partsRequired: [
      { id: '1', name: 'Engine Oil', quantity: 25, available: true, cost: 12500 },
      { id: '2', name: 'Oil Filter', quantity: 2, available: true, cost: 3000 },
      { id: '3', name: 'Hydraulic Filter', quantity: 1, available: true, cost: 4500 }
    ],
    safetyRequirements: ['Standard PPE', 'Machine Lockout'],
    completionNotes: 'All systems checked and operating within specifications. Next service due at 1500 hours.',
    nextMaintenanceDate: '2024-11-25',
    cost: 22000,
    downtime: 3
  }
];

const mockMaintenanceSchedules: MaintenanceSchedule[] = [
  {
    id: '1',
    equipmentId: 'EQ001',
    equipmentName: 'Tower Crane TC-7032',
    maintenanceType: 'Monthly',
    frequency: 30,
    lastMaintenance: '2024-08-05',
    nextMaintenance: '2024-09-05',
    assignedTeam: 'Crane Maintenance Team',
    estimatedDuration: 8,
    priority: 'Medium',
    active: true,
    createdBy: 'Maintenance Manager',
    createdDate: '2024-01-15'
  },
  {
    id: '2',
    equipmentId: 'EQ002',
    equipmentName: 'Mobile Generator Gen-450',
    maintenanceType: 'Weekly',
    frequency: 7,
    lastMaintenance: '2024-08-26',
    nextMaintenance: '2024-09-02',
    assignedTeam: 'Generator Maintenance Team',
    estimatedDuration: 4,
    priority: 'High',
    active: true,
    createdBy: 'Electrical Supervisor',
    createdDate: '2024-02-01'
  }
];

const mockWorkOrders: WorkOrder[] = [
  {
    id: '1',
    requestedBy: 'Site Supervisor - Karim Ahmed',
    requestDate: '2024-08-27',
    equipmentId: 'EQ004',
    equipmentName: 'Welding Machine WM-500',
    issueDescription: 'Welding machine producing inconsistent arc, affecting work quality',
    urgency: 'Medium',
    status: 'Assigned',
    assignedTo: 'Electrical Technician - Rafiq Islam',
    assignedDate: '2024-08-27',
    cost: 15000,
    approver: 'Maintenance Manager'
  },
  {
    id: '2',
    requestedBy: 'Equipment Operator - Mohammad Hasan',
    requestDate: '2024-08-26',
    equipmentId: 'EQ005',
    equipmentName: 'Concrete Mixer CM-1000',
    issueDescription: 'Mixing drum making unusual noise, possible bearing issue',
    urgency: 'High',
    status: 'In Progress',
    assignedTo: 'Mechanical Technician - Ahmed Rahman',
    assignedDate: '2024-08-26',
    cost: 35000,
    approver: 'Project Manager',
    approvalDate: '2024-08-26'
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'Completed': case 'Closed': return 'bg-green-500';
    case 'In Progress': case 'Assigned': return 'bg-blue-500';
    case 'Scheduled': case 'Open': return 'bg-yellow-500';
    case 'Overdue': case 'Critical': return 'bg-red-500';
    case 'Cancelled': return 'bg-gray-500';
    default: return 'bg-gray-500';
  }
};

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case 'Critical': return 'destructive';
    case 'High': return 'destructive';
    case 'Medium': return 'default';
    case 'Low': return 'secondary';
    default: return 'secondary';
  }
};

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-BD', {
    style: 'currency',
    currency: 'BDT',
    notation: 'compact',
    maximumFractionDigits: 1
  }).format(amount);
};

export default function MaintenanceScheduling() {
  const [maintenanceTasks, setMaintenanceTasks] = useState<MaintenanceTask[]>(mockMaintenanceTasks);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(mockWorkOrders);
  const [schedules, setSchedules] = useState<MaintenanceSchedule[]>(mockMaintenanceSchedules);
  const [selectedTask, setSelectedTask] = useState<MaintenanceTask | null>(null);
  const [selectedWorkOrder, setSelectedWorkOrder] = useState<WorkOrder | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterPriority, setFilterPriority] = useState('all');

  const filteredTasks = maintenanceTasks.filter(task => {
    const matchesSearch = task.equipmentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         task.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         task.assignedTechnician.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || task.status === filterStatus;
    const matchesPriority = filterPriority === 'all' || task.priority === filterPriority;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const totalTasks = maintenanceTasks.length;
  const completedTasks = maintenanceTasks.filter(t => t.status === 'Completed').length;
  const overdueTasks = maintenanceTasks.filter(t => t.status === 'Overdue').length;
  const scheduledTasks = maintenanceTasks.filter(t => t.status === 'Scheduled').length;
  const totalCost = maintenanceTasks.reduce((sum, task) => sum + task.cost, 0);
  const avgDowntime = maintenanceTasks.reduce((sum, task) => sum + task.downtime, 0) / maintenanceTasks.length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
              Maintenance Scheduling & Work Orders
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Preventive maintenance scheduling and corrective work order management
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Calendar className="w-4 h-4 mr-2" />
              Schedule Maintenance
            </Button>
            <Button className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700">
              <Plus className="w-4 h-4 mr-2" />
              New Work Order
            </Button>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6">
          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Tasks</p>
                  <p className="text-2xl font-bold text-blue-600">{totalTasks}</p>
                </div>
                <Wrench className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Completed</p>
                  <p className="text-2xl font-bold text-green-600">{completedTasks}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Scheduled</p>
                  <p className="text-2xl font-bold text-yellow-600">{scheduledTasks}</p>
                </div>
                <Calendar className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Overdue</p>
                  <p className="text-2xl font-bold text-red-600">{overdueTasks}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-red-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Cost</p>
                  <p className="text-2xl font-bold text-purple-600">{formatCurrency(totalCost)}</p>
                </div>
                <BarChart3 className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Avg Downtime</p>
                  <p className="text-2xl font-bold text-orange-600">{avgDowntime.toFixed(1)}h</p>
                </div>
                <Clock className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="tasks" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="tasks">Maintenance Tasks</TabsTrigger>
            <TabsTrigger value="schedules">Schedules</TabsTrigger>
            <TabsTrigger value="workorders">Work Orders</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="tasks" className="space-y-6 mt-6">
            {/* Filters */}
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Search maintenance tasks..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-full md:w-48">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="Scheduled">Scheduled</SelectItem>
                      <SelectItem value="In Progress">In Progress</SelectItem>
                      <SelectItem value="Completed">Completed</SelectItem>
                      <SelectItem value="Overdue">Overdue</SelectItem>
                      <SelectItem value="Cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterPriority} onValueChange={setFilterPriority}>
                    <SelectTrigger className="w-full md:w-48">
                      <SelectValue placeholder="Filter by priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Priority</SelectItem>
                      <SelectItem value="Critical">Critical</SelectItem>
                      <SelectItem value="High">High</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="Low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Maintenance Tasks */}
            <div className="space-y-4">
              {filteredTasks.map((task, index) => (
                <motion.div
                  key={task.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card 
                    className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300 cursor-pointer"
                    onClick={() => setSelectedTask(task)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <Badge variant="outline">{task.taskType}</Badge>
                            <Badge variant={getPriorityColor(task.priority) as any}>{task.priority}</Badge>
                            <div className={`w-3 h-3 rounded-full ${getStatusColor(task.status)}`}></div>
                          </div>
                          <h3 className="font-semibold text-lg mb-1">{task.equipmentName}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{task.description}</p>
                          <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400 mb-2">
                            <div className="flex items-center gap-1">
                              <MapPin className="w-4 h-4" />
                              {task.location}
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {new Date(task.scheduledDate).toLocaleDateString()}
                            </div>
                            <div className="flex items-center gap-1">
                              <User className="w-4 h-4" />
                              {task.assignedTechnician}
                            </div>
                          </div>
                          <div className="flex items-center gap-4 text-sm">
                            <span className="text-gray-600 dark:text-gray-400">
                              Est. Hours: {task.estimatedHours}
                            </span>
                            {task.actualHours && (
                              <span className="text-gray-600 dark:text-gray-400">
                                Actual: {task.actualHours}h
                              </span>
                            )}
                            <span className="text-gray-600 dark:text-gray-400">
                              Cost: {formatCurrency(task.cost)}
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge variant={task.status === 'Completed' ? 'default' : task.status === 'In Progress' ? 'secondary' : 'outline'}>
                            {task.status}
                          </Badge>
                          <div className="mt-2">
                            <Progress 
                              value={task.checklist.filter(item => item.completed).length / task.checklist.length * 100} 
                              className="w-24 h-2" 
                            />
                            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                              {task.checklist.filter(item => item.completed).length}/{task.checklist.length} tasks
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="schedules" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {mockMaintenanceSchedules.map((schedule, index) => (
                <motion.div
                  key={schedule.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{schedule.equipmentName}</CardTitle>
                          <CardDescription>{schedule.maintenanceType} Maintenance</CardDescription>
                        </div>
                        <Badge variant={schedule.active ? 'default' : 'secondary'}>
                          {schedule.active ? 'Active' : 'Inactive'}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600 dark:text-gray-400">Frequency</p>
                          <p className="font-medium">Every {schedule.frequency} days</p>
                        </div>
                        <div>
                          <p className="text-gray-600 dark:text-gray-400">Duration</p>
                          <p className="font-medium">{schedule.estimatedDuration} hours</p>
                        </div>
                        <div>
                          <p className="text-gray-600 dark:text-gray-400">Last Maintenance</p>
                          <p className="font-medium">{new Date(schedule.lastMaintenance).toLocaleDateString()}</p>
                        </div>
                        <div>
                          <p className="text-gray-600 dark:text-gray-400">Next Maintenance</p>
                          <p className="font-medium">{new Date(schedule.nextMaintenance).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div>
                        <p className="text-gray-600 dark:text-gray-400 text-sm">Assigned Team</p>
                        <p className="font-medium">{schedule.assignedTeam}</p>
                      </div>
                      <div className="flex justify-between items-center">
                        <Badge variant={getPriorityColor(schedule.priority) as any}>
                          {schedule.priority} Priority
                        </Badge>
                        <Button variant="outline" size="sm">
                          <Settings className="w-4 h-4 mr-1" />
                          Configure
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="workorders" className="space-y-6 mt-6">
            <div className="space-y-4">
              {mockWorkOrders.map((workOrder, index) => (
                <motion.div
                  key={workOrder.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card 
                    className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300 cursor-pointer"
                    onClick={() => setSelectedWorkOrder(workOrder)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <Badge variant="outline">Work Order #{workOrder.id}</Badge>
                            <Badge variant={getPriorityColor(workOrder.urgency) as any}>{workOrder.urgency}</Badge>
                            <div className={`w-3 h-3 rounded-full ${getStatusColor(workOrder.status)}`}></div>
                          </div>
                          <h3 className="font-semibold text-lg mb-1">{workOrder.equipmentName}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{workOrder.issueDescription}</p>
                          <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                            <div className="flex items-center gap-1">
                              <User className="w-4 h-4" />
                              Requested by: {workOrder.requestedBy}
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {new Date(workOrder.requestDate).toLocaleDateString()}
                            </div>
                            {workOrder.assignedTo && (
                              <div className="flex items-center gap-1">
                                <Wrench className="w-4 h-4" />
                                Assigned to: {workOrder.assignedTo}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge variant={workOrder.status === 'Completed' ? 'default' : workOrder.status === 'In Progress' ? 'secondary' : 'outline'}>
                            {workOrder.status}
                          </Badge>
                          <p className="text-sm font-medium mt-2">{formatCurrency(workOrder.cost)}</p>
                          {workOrder.approvalDate && (
                            <p className="text-xs text-green-600">Approved</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Maintenance Trends</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-48 flex items-center justify-center text-gray-500">
                    <TrendingUp className="w-12 h-12 mr-4" />
                    <span>Maintenance trend analytics would be displayed here</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Equipment Reliability</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-48 flex items-center justify-center text-gray-500">
                    <Target className="w-12 h-12 mr-4" />
                    <span>Equipment reliability metrics would be displayed here</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Cost Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600 dark:text-gray-400">Preventive Maintenance</span>
                      <span className="font-semibold">{formatCurrency(125000)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600 dark:text-gray-400">Corrective Maintenance</span>
                      <span className="font-semibold">{formatCurrency(85000)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600 dark:text-gray-400">Emergency Repairs</span>
                      <span className="font-semibold">{formatCurrency(45000)}</span>
                    </div>
                    <div className="pt-2 border-t">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Total Cost</span>
                        <span className="font-bold text-lg">{formatCurrency(255000)}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Performance Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm">Scheduled Compliance</span>
                        <span className="text-sm">92%</span>
                      </div>
                      <Progress value={92} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm">On-Time Completion</span>
                        <span className="text-sm">85%</span>
                      </div>
                      <Progress value={85} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm">Equipment Uptime</span>
                        <span className="text-sm">96%</span>
                      </div>
                      <Progress value={96} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Maintenance Task Details Modal */}
        {selectedTask && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto backdrop-blur-sm bg-white/95 dark:bg-gray-900/95">
              <CardHeader className="flex flex-row items-start justify-between">
                <div>
                  <CardTitle className="text-2xl">{selectedTask.equipmentName}</CardTitle>
                  <CardDescription className="mt-2">{selectedTask.description}</CardDescription>
                </div>
                <Button 
                  variant="ghost" 
                  onClick={() => setSelectedTask(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="checklist" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="checklist">Checklist</TabsTrigger>
                    <TabsTrigger value="parts">Parts Required</TabsTrigger>
                    <TabsTrigger value="safety">Safety</TabsTrigger>
                    <TabsTrigger value="details">Details</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="checklist" className="space-y-4 mt-6">
                    {selectedTask.checklist.map((item) => (
                      <div key={item.id} className="flex items-start gap-3 p-3 border rounded-lg">
                        <CheckCircle className={`w-5 h-5 mt-0.5 ${item.completed ? 'text-green-500' : 'text-gray-300'}`} />
                        <div className="flex-1">
                          <p className={`font-medium ${item.completed ? 'line-through text-gray-500' : ''}`}>
                            {item.task}
                          </p>
                          {item.notes && (
                            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{item.notes}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="parts" className="space-y-4 mt-6">
                    {selectedTask.partsRequired.map((part) => (
                      <div key={part.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">{part.name}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Quantity: {part.quantity}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{formatCurrency(part.cost)}</p>
                          <Badge variant={part.available ? 'default' : 'destructive'}>
                            {part.available ? 'Available' : 'Not Available'}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="safety" className="space-y-4 mt-6">
                    <div className="space-y-3">
                      {selectedTask.safetyRequirements.map((requirement, index) => (
                        <div key={index} className="flex items-center gap-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                          <AlertTriangle className="w-5 h-5 text-yellow-600" />
                          <span className="font-medium">{requirement}</span>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="details" className="space-y-4 mt-6">
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Task Type:</span>
                          <Badge variant="outline">{selectedTask.taskType}</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Priority:</span>
                          <Badge variant={getPriorityColor(selectedTask.priority) as any}>{selectedTask.priority}</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Status:</span>
                          <Badge>{selectedTask.status}</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Location:</span>
                          <span className="font-medium">{selectedTask.location}</span>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Technician:</span>
                          <span className="font-medium">{selectedTask.assignedTechnician}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Supervisor:</span>
                          <span className="font-medium">{selectedTask.supervisor}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Est. Hours:</span>
                          <span className="font-medium">{selectedTask.estimatedHours}h</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Cost:</span>
                          <span className="font-medium">{formatCurrency(selectedTask.cost)}</span>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}