import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  BarChart3, PieChart, TrendingUp, TrendingDown, FileText, Download,
  Calendar, Filter, RefreshCw, Target, DollarSign, Clock, Users,
  Building2, Wrench, Package, Shield, AlertTriangle, CheckCircle, X
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

interface ReportMetrics {
  projects: {
    total: number;
    active: number;
    completed: number;
    delayed: number;
    totalBudget: number;
    totalSpent: number;
    avgProgress: number;
  };
  equipment: {
    total: number;
    operational: number;
    maintenance: number;
    utilization: number;
    totalValue: number;
    maintenanceCost: number;
  };
  materials: {
    totalItems: number;
    totalValue: number;
    lowStock: number;
    outOfStock: number;
    deliveryPerformance: number;
  };
  contractors: {
    total: number;
    active: number;
    avgRating: number;
    avgPerformance: number;
    totalContractValue: number;
    completionRate: number;
  };
  financial: {
    totalBudget: number;
    totalSpent: number;
    pendingPayments: number;
    costVariance: number;
    budgetUtilization: number;
  };
  safety: {
    totalIncidents: number;
    safetyScore: number;
    ltir: number;
    trainingHours: number;
    complianceRate: number;
  };
}

interface CustomReport {
  id: string;
  name: string;
  type: 'Project Summary' | 'Financial Analysis' | 'Equipment Status' | 'Safety Report' | 'Custom';
  frequency: 'Daily' | 'Weekly' | 'Monthly' | 'Quarterly' | 'On-Demand';
  lastGenerated: string;
  nextScheduled?: string;
  recipients: string[];
  format: 'PDF' | 'Excel' | 'Dashboard';
  status: 'Active' | 'Inactive';
  parameters: {
    dateRange: string;
    projects: string[];
    includeCharts: boolean;
    includeDetails: boolean;
  };
}

const mockMetrics: ReportMetrics = {
  projects: {
    total: 15,
    active: 8,
    completed: 5,
    delayed: 2,
    totalBudget: 45000000000,
    totalSpent: 32500000000,
    avgProgress: 72.3
  },
  equipment: {
    total: 156,
    operational: 145,
    maintenance: 8,
    utilization: 87.5,
    totalValue: 2850000000,
    maintenanceCost: 185000000
  },
  materials: {
    totalItems: 450,
    totalValue: 1250000000,
    lowStock: 25,
    outOfStock: 8,
    deliveryPerformance: 92.5
  },
  contractors: {
    total: 24,
    active: 18,
    avgRating: 4.2,
    avgPerformance: 88.7,
    totalContractValue: 38000000000,
    completionRate: 94.2
  },
  financial: {
    totalBudget: 45000000000,
    totalSpent: 32500000000,
    pendingPayments: 2850000000,
    costVariance: 5.2,
    budgetUtilization: 72.2
  },
  safety: {
    totalIncidents: 12,
    safetyScore: 94.5,
    ltir: 0.15,
    trainingHours: 12500,
    complianceRate: 96.8
  }
};

const mockReports: CustomReport[] = [
  {
    id: '1',
    name: 'Monthly Project Progress Report',
    type: 'Project Summary',
    frequency: 'Monthly',
    lastGenerated: '2024-08-01',
    nextScheduled: '2024-09-01',
    recipients: ['Project Director', 'CFO', 'Board of Directors'],
    format: 'PDF',
    status: 'Active',
    parameters: {
      dateRange: 'Last Month',
      projects: ['All Active'],
      includeCharts: true,
      includeDetails: true
    }
  },
  {
    id: '2',
    name: 'Weekly Safety Dashboard',
    type: 'Safety Report',
    frequency: 'Weekly',
    lastGenerated: '2024-08-26',
    nextScheduled: '2024-09-02',
    recipients: ['Safety Manager', 'Site Supervisors'],
    format: 'Dashboard',
    status: 'Active',
    parameters: {
      dateRange: 'Last Week',
      projects: ['All Active'],
      includeCharts: true,
      includeDetails: false
    }
  },
  {
    id: '3',
    name: 'Equipment Utilization Analysis',
    type: 'Equipment Status',
    frequency: 'Monthly',
    lastGenerated: '2024-08-01',
    nextScheduled: '2024-09-01',
    recipients: ['Equipment Manager', 'Maintenance Team'],
    format: 'Excel',
    status: 'Active',
    parameters: {
      dateRange: 'Last Month',
      projects: ['All'],
      includeCharts: true,
      includeDetails: true
    }
  }
];

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-BD', {
    style: 'currency',
    currency: 'BDT',
    notation: 'compact',
    maximumFractionDigits: 1
  }).format(amount);
};

const formatPercentage = (value: number) => {
  return `${value.toFixed(1)}%`;
};

export default function ReportingAnalytics() {
  const [selectedReport, setSelectedReport] = useState<CustomReport | null>(null);
  const [dateRange, setDateRange] = useState('last-month');
  const [reportType, setReportType] = useState('overview');
  const [isGenerating, setIsGenerating] = useState(false);

  const generateReport = async () => {
    setIsGenerating(true);
    // Simulate report generation
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsGenerating(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
              Reporting & Analytics Dashboard
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Comprehensive reporting and data analytics for construction management
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh Data
            </Button>
            <Button 
              className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700"
              onClick={generateReport}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <FileText className="w-4 h-4 mr-2" />
              )}
              Generate Report
            </Button>
          </div>
        </div>

        {/* Key Metrics Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Active Projects</p>
                  <p className="text-2xl font-bold text-blue-600">{mockMetrics.projects.active}</p>
                  <p className="text-xs text-green-600">
                    <TrendingUp className="w-3 h-3 inline mr-1" />
                    {formatPercentage(mockMetrics.projects.avgProgress)} avg progress
                  </p>
                </div>
                <Building2 className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Budget Utilization</p>
                  <p className="text-2xl font-bold text-green-600">{formatPercentage(mockMetrics.financial.budgetUtilization)}</p>
                  <p className="text-xs text-gray-600 dark:text-gray-400">
                    {formatCurrency(mockMetrics.financial.totalSpent)} spent
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Safety Score</p>
                  <p className="text-2xl font-bold text-purple-600">{formatPercentage(mockMetrics.safety.safetyScore)}</p>
                  <p className="text-xs text-green-600">
                    <CheckCircle className="w-3 h-3 inline mr-1" />
                    {mockMetrics.safety.totalIncidents} incidents YTD
                  </p>
                </div>
                <Shield className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Equipment Uptime</p>
                  <p className="text-2xl font-bold text-orange-600">{formatPercentage(mockMetrics.equipment.utilization)}</p>
                  <p className="text-xs text-gray-600 dark:text-gray-400">
                    {mockMetrics.equipment.operational}/{mockMetrics.equipment.total} operational
                  </p>
                </div>
                <Wrench className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="dashboard">Analytics Dashboard</TabsTrigger>
            <TabsTrigger value="reports">Custom Reports</TabsTrigger>
            <TabsTrigger value="kpi">KPI Monitoring</TabsTrigger>
            <TabsTrigger value="export">Data Export</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6 mt-6">
            {/* Date Range Selector */}
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-4 items-center">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-gray-500" />
                    <span className="text-sm font-medium">Date Range:</span>
                  </div>
                  <Select value={dateRange} onValueChange={setDateRange}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="last-week">Last Week</SelectItem>
                      <SelectItem value="last-month">Last Month</SelectItem>
                      <SelectItem value="last-quarter">Last Quarter</SelectItem>
                      <SelectItem value="last-year">Last Year</SelectItem>
                      <SelectItem value="custom">Custom Range</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="sm">
                    <Filter className="w-4 h-4 mr-2" />
                    Apply Filters
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Analytics Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Project Progress Trends</CardTitle>
                  <CardDescription>Monthly project completion and budget utilization</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    <BarChart3 className="w-16 h-16 mr-4" />
                    <div className="text-center">
                      <p className="font-medium">Project Progress Chart</p>
                      <p className="text-sm">Interactive chart would be displayed here</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Budget Allocation</CardTitle>
                  <CardDescription>Budget distribution across projects and categories</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    <PieChart className="w-16 h-16 mr-4" />
                    <div className="text-center">
                      <p className="font-medium">Budget Distribution</p>
                      <p className="text-sm">Pie chart would be displayed here</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Equipment Utilization</CardTitle>
                  <CardDescription>Equipment usage and maintenance metrics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm">Operational Equipment</span>
                        <span className="text-sm font-medium">
                          {mockMetrics.equipment.operational}/{mockMetrics.equipment.total}
                        </span>
                      </div>
                      <Progress 
                        value={(mockMetrics.equipment.operational / mockMetrics.equipment.total) * 100} 
                        className="h-2" 
                      />
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm">Average Utilization</span>
                        <span className="text-sm font-medium">{formatPercentage(mockMetrics.equipment.utilization)}</span>
                      </div>
                      <Progress value={mockMetrics.equipment.utilization} className="h-2" />
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-center text-sm">
                      <div>
                        <p className="text-gray-600 dark:text-gray-400">Total Value</p>
                        <p className="font-semibold">{formatCurrency(mockMetrics.equipment.totalValue)}</p>
                      </div>
                      <div>
                        <p className="text-gray-600 dark:text-gray-400">Maintenance Cost</p>
                        <p className="font-semibold">{formatCurrency(mockMetrics.equipment.maintenanceCost)}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Safety Metrics</CardTitle>
                  <CardDescription>Safety performance indicators and trends</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <Shield className="w-6 h-6 mx-auto mb-1 text-green-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Safety Score</p>
                        <p className="text-xl font-bold text-green-600">{formatPercentage(mockMetrics.safety.safetyScore)}</p>
                      </div>
                      <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                        <Clock className="w-6 h-6 mx-auto mb-1 text-blue-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">LTIR</p>
                        <p className="text-xl font-bold text-blue-600">{mockMetrics.safety.ltir}</p>
                      </div>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-600 dark:text-gray-400">Training Hours Completed</p>
                      <p className="text-2xl font-bold">{mockMetrics.safety.trainingHours.toLocaleString()}</p>
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm">Compliance Rate</span>
                        <span className="text-sm font-medium">{formatPercentage(mockMetrics.safety.complianceRate)}</span>
                      </div>
                      <Progress value={mockMetrics.safety.complianceRate} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="reports" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {mockReports.map((report, index) => (
                <motion.div
                  key={report.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card 
                    className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300 cursor-pointer"
                    onClick={() => setSelectedReport(report)}
                  >
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{report.name}</CardTitle>
                          <CardDescription>{report.type} • {report.frequency}</CardDescription>
                        </div>
                        <Badge variant={report.status === 'Active' ? 'default' : 'secondary'}>
                          {report.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Last Generated:</span>
                          <span className="font-medium">{new Date(report.lastGenerated).toLocaleDateString()}</span>
                        </div>
                        {report.nextScheduled && (
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Next Scheduled:</span>
                            <span className="font-medium">{new Date(report.nextScheduled).toLocaleDateString()}</span>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Format:</span>
                          <Badge variant="outline">{report.format}</Badge>
                        </div>
                      </div>
                      
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Recipients:</p>
                        <div className="flex flex-wrap gap-1">
                          {report.recipients.slice(0, 2).map((recipient, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {recipient}
                            </Badge>
                          ))}
                          {report.recipients.length > 2 && (
                            <Badge variant="secondary" className="text-xs">
                              +{report.recipients.length - 2} more
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div className="flex gap-2 pt-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Download className="w-4 h-4 mr-1" />
                          Download
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1">
                          <FileText className="w-4 h-4 mr-1" />
                          Generate
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="kpi" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Project KPIs */}
              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Building2 className="w-5 h-5" />
                    Project KPIs
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">On-Time Delivery</span>
                      <div className="flex items-center gap-2">
                        <Progress value={85} className="w-16 h-2" />
                        <span className="text-sm font-medium">85%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Budget Adherence</span>
                      <div className="flex items-center gap-2">
                        <Progress value={92} className="w-16 h-2" />
                        <span className="text-sm font-medium">92%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Quality Score</span>
                      <div className="flex items-center gap-2">
                        <Progress value={88} className="w-16 h-2" />
                        <span className="text-sm font-medium">88%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Financial KPIs */}
              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <DollarSign className="w-5 h-5" />
                    Financial KPIs
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Cost Performance Index</span>
                      <span className="text-sm font-medium text-green-600">1.05</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Schedule Performance Index</span>
                      <span className="text-sm font-medium text-yellow-600">0.98</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Return on Investment</span>
                      <span className="text-sm font-medium text-green-600">12.5%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Operational KPIs */}
              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    Operational KPIs
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Equipment Efficiency</span>
                      <div className="flex items-center gap-2">
                        <Progress value={87} className="w-16 h-2" />
                        <span className="text-sm font-medium">87%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Resource Utilization</span>
                      <div className="flex items-center gap-2">
                        <Progress value={91} className="w-16 h-2" />
                        <span className="text-sm font-medium">91%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Productivity Index</span>
                      <span className="text-sm font-medium text-green-600">1.15</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="export" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Quick Data Export</CardTitle>
                  <CardDescription>Export specific data sets for analysis</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <Building2 className="w-4 h-4 mr-2" />
                      Export Project Data
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <DollarSign className="w-4 h-4 mr-2" />
                      Export Financial Data
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Wrench className="w-4 h-4 mr-2" />
                      Export Equipment Data
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Shield className="w-4 h-4 mr-2" />
                      Export Safety Data
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Custom Export</CardTitle>
                  <CardDescription>Configure custom data exports</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select data type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="projects">Projects</SelectItem>
                        <SelectItem value="financial">Financial</SelectItem>
                        <SelectItem value="equipment">Equipment</SelectItem>
                        <SelectItem value="materials">Materials</SelectItem>
                        <SelectItem value="contractors">Contractors</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select format" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="excel">Excel (.xlsx)</SelectItem>
                        <SelectItem value="csv">CSV</SelectItem>
                        <SelectItem value="pdf">PDF Report</SelectItem>
                        <SelectItem value="json">JSON</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select date range" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="last-week">Last Week</SelectItem>
                        <SelectItem value="last-month">Last Month</SelectItem>
                        <SelectItem value="last-quarter">Last Quarter</SelectItem>
                        <SelectItem value="custom">Custom Range</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Button className="w-full">
                      <Download className="w-4 h-4 mr-2" />
                      Export Data
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Report Details Modal */}
        {selectedReport && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <Card className="w-full max-w-2xl backdrop-blur-sm bg-white/95 dark:bg-gray-900/95">
              <CardHeader className="flex flex-row items-start justify-between">
                <div>
                  <CardTitle className="text-xl">{selectedReport.name}</CardTitle>
                  <CardDescription className="mt-2">{selectedReport.type} • {selectedReport.frequency}</CardDescription>
                </div>
                <Button 
                  variant="ghost" 
                  onClick={() => setSelectedReport(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Status</label>
                    <div className="mt-1">
                      <Badge variant={selectedReport.status === 'Active' ? 'default' : 'secondary'}>
                        {selectedReport.status}
                      </Badge>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Format</label>
                    <div className="mt-1">
                      <Badge variant="outline">{selectedReport.format}</Badge>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Last Generated:</span>
                    <span className="font-medium">{new Date(selectedReport.lastGenerated).toLocaleDateString()}</span>
                  </div>
                  {selectedReport.nextScheduled && (
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Next Scheduled:</span>
                      <span className="font-medium">{new Date(selectedReport.nextScheduled).toLocaleDateString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Frequency:</span>
                    <span className="font-medium">{selectedReport.frequency}</span>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Recipients</label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {selectedReport.recipients.map((recipient, index) => (
                      <Badge key={index} variant="secondary">
                        {recipient}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Parameters</label>
                  <div className="mt-2 space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Date Range:</span>
                      <span className="font-medium">{selectedReport.parameters.dateRange}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Include Charts:</span>
                      <span className="font-medium">{selectedReport.parameters.includeCharts ? 'Yes' : 'No'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Include Details:</span>
                      <span className="font-medium">{selectedReport.parameters.includeDetails ? 'Yes' : 'No'}</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 pt-4 border-t">
                  <Button variant="outline" className="flex-1">
                    <Download className="w-4 h-4 mr-2" />
                    Download Latest
                  </Button>
                  <Button className="flex-1">
                    <FileText className="w-4 h-4 mr-2" />
                    Generate Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}