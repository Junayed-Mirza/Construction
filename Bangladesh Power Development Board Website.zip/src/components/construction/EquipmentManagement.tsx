import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Wrench, Calendar, AlertTriangle, CheckCircle, Clock, MapPin, 
  Settings, Plus, Search, Filter, Truck, Zap, Shield, 
  BarChart3, TrendingUp, FileText, User, Phone, DollarSign, X
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

interface Equipment {
  id: string;
  name: string;
  type: 'Crane' | 'Excavator' | 'Generator' | 'Truck' | 'Welder' | 'Compressor' | 'Transformer' | 'Other';
  model: string;
  serialNumber: string;
  status: 'Active' | 'Maintenance' | 'Idle' | 'Out of Service' | 'Repair';
  location: string;
  project: string;
  operator: string;
  condition: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  maintenanceSchedule: {
    lastMaintenance: string;
    nextMaintenance: string;
    type: 'Routine' | 'Preventive' | 'Emergency';
  };
  utilizationHours: number;
  totalHours: number;
  purchaseDate: string;
  warrantyExpiry: string;
  cost: number;
  vendor: string;
  specifications: {
    capacity: string;
    power: string;
    fuel: string;
    [key: string]: string;
  };
  maintenanceHistory: {
    date: string;
    type: string;
    description: string;
    cost: number;
    technician: string;
  }[];
}

const mockEquipment: Equipment[] = [
  {
    id: '1',
    name: 'Tower Crane TC-7032',
    type: 'Crane',
    model: 'Liebherr 630 EC-H 40',
    serialNumber: 'LH-2023-001',
    status: 'Active',
    location: 'Payra Coal Power Plant',
    project: 'Payra Coal Power Plant Unit 2',
    operator: 'Mohammad Hasan',
    condition: 'Good',
    maintenanceSchedule: {
      lastMaintenance: '2024-07-15',
      nextMaintenance: '2024-10-15',
      type: 'Routine'
    },
    utilizationHours: 2840,
    totalHours: 5200,
    purchaseDate: '2022-03-15',
    warrantyExpiry: '2025-03-15',
    cost: 850000,
    vendor: 'Liebherr Group',
    specifications: {
      capacity: '40 tons',
      power: '400 kW',
      fuel: 'Electric',
      height: '200m',
      reach: '70m'
    },
    maintenanceHistory: [
      {
        date: '2024-07-15',
        type: 'Routine Maintenance',
        description: 'General inspection, lubrication, and safety check',
        cost: 25000,
        technician: 'Ahmed Rahman'
      },
      {
        date: '2024-04-10',
        type: 'Repair',
        description: 'Hydraulic system repair',
        cost: 85000,
        technician: 'Karim Ahmed'
      }
    ]
  },
  {
    id: '2',
    name: 'Mobile Generator Gen-450',
    type: 'Generator',
    model: 'Caterpillar C18 ACERT',
    serialNumber: 'CAT-2023-045',
    status: 'Maintenance',
    location: 'Equipment Yard',
    project: 'Dhaka-Cumilla Transmission',
    operator: 'Rafiq Islam',
    condition: 'Fair',
    maintenanceSchedule: {
      lastMaintenance: '2024-08-20',
      nextMaintenance: '2024-09-05',
      type: 'Preventive'
    },
    utilizationHours: 1850,
    totalHours: 3200,
    purchaseDate: '2022-11-20',
    warrantyExpiry: '2024-11-20',
    cost: 450000,
    vendor: 'Caterpillar Inc.',
    specifications: {
      capacity: '450 kVA',
      power: '360 kW',
      fuel: 'Diesel',
      voltage: '400V',
      frequency: '50Hz'
    },
    maintenanceHistory: [
      {
        date: '2024-08-20',
        type: 'Preventive Maintenance',
        description: 'Engine overhaul and electrical system check',
        cost: 120000,
        technician: 'Nasir Ahmed'
      }
    ]
  },
  {
    id: '3',
    name: 'Excavator EX-200',
    type: 'Excavator',
    model: 'Komatsu PC200-8M0',
    serialNumber: 'KOM-2024-012',
    status: 'Active',
    location: 'Rooppur Nuclear Site',
    project: 'Rooppur Nuclear Infrastructure',
    operator: 'Shahid Khan',
    condition: 'Excellent',
    maintenanceSchedule: {
      lastMaintenance: '2024-08-01',
      nextMaintenance: '2024-11-01',
      type: 'Routine'
    },
    utilizationHours: 980,
    totalHours: 1200,
    purchaseDate: '2024-01-10',
    warrantyExpiry: '2027-01-10',
    cost: 380000,
    vendor: 'Komatsu Ltd.',
    specifications: {
      capacity: '20 tons',
      power: '123 kW',
      fuel: 'Diesel',
      bucket: '1.0 m³',
      reach: '9.9m'
    },
    maintenanceHistory: [
      {
        date: '2024-08-01',
        type: 'Routine Check',
        description: '500-hour service and inspection',
        cost: 15000,
        technician: 'Golam Rahman'
      }
    ]
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'Active': return 'bg-green-500';
    case 'Maintenance': return 'bg-yellow-500';
    case 'Idle': return 'bg-blue-500';
    case 'Out of Service': return 'bg-red-500';
    case 'Repair': return 'bg-orange-500';
    default: return 'bg-gray-500';
  }
};

const getConditionColor = (condition: string) => {
  switch (condition) {
    case 'Excellent': return 'default';
    case 'Good': return 'secondary';
    case 'Fair': return 'outline';
    case 'Poor': return 'destructive';
    default: return 'secondary';
  }
};

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-BD', {
    style: 'currency',
    currency: 'BDT',
    notation: 'compact',
    maximumFractionDigits: 1
  }).format(amount);
};

const getUtilizationPercentage = (utilized: number, total: number) => {
  return Math.round((utilized / total) * 100);
};

export default function EquipmentManagement() {
  const [equipment, setEquipment] = useState<Equipment[]>(mockEquipment);
  const [selectedEquipment, setSelectedEquipment] = useState<Equipment | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');

  const filteredEquipment = equipment.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.serialNumber.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || item.status === filterStatus;
    const matchesType = filterType === 'all' || item.type === filterType;
    return matchesSearch && matchesStatus && matchesType;
  });

  const totalEquipment = equipment.length;
  const activeEquipment = equipment.filter(e => e.status === 'Active').length;
  const maintenanceEquipment = equipment.filter(e => e.status === 'Maintenance' || e.status === 'Repair').length;
  const totalValue = equipment.reduce((sum, item) => sum + item.cost, 0);
  const avgUtilization = equipment.reduce((sum, item) => sum + getUtilizationPercentage(item.utilizationHours, item.totalHours), 0) / equipment.length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
              Equipment Management
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Track and manage construction equipment lifecycle
            </p>
          </div>
          <Button className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Equipment
          </Button>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Equipment</p>
                  <p className="text-2xl font-bold text-blue-600">{totalEquipment}</p>
                </div>
                <Wrench className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Active</p>
                  <p className="text-2xl font-bold text-green-600">{activeEquipment}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Maintenance</p>
                  <p className="text-2xl font-bold text-yellow-600">{maintenanceEquipment}</p>
                </div>
                <Settings className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Value</p>
                  <p className="text-2xl font-bold text-purple-600">{formatCurrency(totalValue)}</p>
                </div>
                <DollarSign className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Avg Utilization</p>
                  <p className="text-2xl font-bold text-orange-600">{avgUtilization.toFixed(1)}%</p>
                </div>
                <BarChart3 className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Search equipment..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Maintenance">Maintenance</SelectItem>
                  <SelectItem value="Idle">Idle</SelectItem>
                  <SelectItem value="Out of Service">Out of Service</SelectItem>
                  <SelectItem value="Repair">Repair</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Crane">Crane</SelectItem>
                  <SelectItem value="Excavator">Excavator</SelectItem>
                  <SelectItem value="Generator">Generator</SelectItem>
                  <SelectItem value="Truck">Truck</SelectItem>
                  <SelectItem value="Welder">Welder</SelectItem>
                  <SelectItem value="Compressor">Compressor</SelectItem>
                  <SelectItem value="Transformer">Transformer</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Equipment List */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredEquipment.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card 
                className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedEquipment(item)}
              >
                <CardHeader className="pb-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-1">{item.name}</CardTitle>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{item.model}</p>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline">{item.type}</Badge>
                        <Badge variant={getConditionColor(item.condition) as any}>{item.condition}</Badge>
                      </div>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${getStatusColor(item.status)}`}></div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {item.location}
                    </div>
                    <div className="flex items-center gap-1">
                      <User className="w-4 h-4" />
                      {item.operator}
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Utilization</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {getUtilizationPercentage(item.utilizationHours, item.totalHours)}%
                      </span>
                    </div>
                    <Progress value={getUtilizationPercentage(item.utilizationHours, item.totalHours)} className="h-2" />
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Hours</span>
                      <span className="font-medium">{item.utilizationHours.toLocaleString()} / {item.totalHours.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Next Maintenance</span>
                      <span className="font-medium">{new Date(item.maintenanceSchedule.nextMaintenance).toLocaleDateString()}</span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-gray-200 dark:border-gray-700">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {item.serialNumber}
                    </span>
                    <span className="text-sm font-medium text-blue-600">
                      {item.status}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Equipment Details Modal */}
        {selectedEquipment && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto backdrop-blur-sm bg-white/95 dark:bg-gray-900/95">
              <CardHeader className="flex flex-row items-start justify-between">
                <div>
                  <CardTitle className="text-2xl">{selectedEquipment.name}</CardTitle>
                  <CardDescription className="mt-2">{selectedEquipment.model} - {selectedEquipment.serialNumber}</CardDescription>
                </div>
                <Button 
                  variant="ghost" 
                  onClick={() => setSelectedEquipment(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="overview" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="specifications">Specifications</TabsTrigger>
                    <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
                    <TabsTrigger value="history">History</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="overview" className="space-y-6 mt-6">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                        <Calendar className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Purchase Date</p>
                        <p className="font-semibold">{new Date(selectedEquipment.purchaseDate).toLocaleDateString()}</p>
                      </div>
                      <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <Shield className="w-6 h-6 mx-auto mb-2 text-green-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Warranty</p>
                        <p className="font-semibold">{new Date(selectedEquipment.warrantyExpiry).toLocaleDateString()}</p>
                      </div>
                      <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                        <DollarSign className="w-6 h-6 mx-auto mb-2 text-purple-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Cost</p>
                        <p className="font-semibold">{formatCurrency(selectedEquipment.cost)}</p>
                      </div>
                      <div className="text-center p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                        <BarChart3 className="w-6 h-6 mx-auto mb-2 text-orange-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Utilization</p>
                        <p className="font-semibold">{getUtilizationPercentage(selectedEquipment.utilizationHours, selectedEquipment.totalHours)}%</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Equipment Details</h3>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Type:</span>
                            <span className="font-medium">{selectedEquipment.type}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Status:</span>
                            <Badge>{selectedEquipment.status}</Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Condition:</span>
                            <Badge variant={getConditionColor(selectedEquipment.condition) as any}>{selectedEquipment.condition}</Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Location:</span>
                            <span className="font-medium">{selectedEquipment.location}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Project:</span>
                            <span className="font-medium">{selectedEquipment.project}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Operations</h3>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Operator:</span>
                            <span className="font-medium">{selectedEquipment.operator}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Total Hours:</span>
                            <span className="font-medium">{selectedEquipment.totalHours.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Used Hours:</span>
                            <span className="font-medium">{selectedEquipment.utilizationHours.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Vendor:</span>
                            <span className="font-medium">{selectedEquipment.vendor}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="specifications" className="space-y-4 mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {Object.entries(selectedEquipment.specifications).map(([key, value]) => (
                        <div key={key} className="flex justify-between items-center p-4 border rounded-lg">
                          <span className="font-medium capitalize">{key}:</span>
                          <span className="text-gray-600 dark:text-gray-400">{value}</span>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="maintenance" className="space-y-4 mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                      <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                        <Calendar className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Last Maintenance</p>
                        <p className="font-semibold">{new Date(selectedEquipment.maintenanceSchedule.lastMaintenance).toLocaleDateString()}</p>
                      </div>
                      <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <Clock className="w-6 h-6 mx-auto mb-2 text-green-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Next Maintenance</p>
                        <p className="font-semibold">{new Date(selectedEquipment.maintenanceSchedule.nextMaintenance).toLocaleDateString()}</p>
                      </div>
                      <div className="text-center p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                        <Settings className="w-6 h-6 mx-auto mb-2 text-orange-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Type</p>
                        <p className="font-semibold">{selectedEquipment.maintenanceSchedule.type}</p>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="history" className="space-y-4 mt-6">
                    {selectedEquipment.maintenanceHistory.map((record, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium">{record.type}</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{record.description}</p>
                          </div>
                          <Badge variant="outline">{formatCurrency(record.cost)}</Badge>
                        </div>
                        <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400">
                          <span>Date: {new Date(record.date).toLocaleDateString()}</span>
                          <span>Technician: {record.technician}</span>
                        </div>
                      </div>
                    ))}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}