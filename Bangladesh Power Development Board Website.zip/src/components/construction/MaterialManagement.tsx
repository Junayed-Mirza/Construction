import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Package, TrendingDown, TrendingUp, AlertTriangle, CheckCircle, 
  Truck, Warehouse, DollarSign, Calendar, Search, Filter, Plus,
  BarChart3, PieChart, FileText, MapPin, Clock, User, X
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

interface Material {
  id: string;
  name: string;
  category: 'Steel' | 'Concrete' | 'Cable' | 'Pipe' | 'Equipment' | 'Chemical' | 'Safety' | 'Other';
  sku: string;
  currentStock: number;
  minStock: number;
  maxStock: number;
  unit: string;
  unitPrice: number;
  totalValue: number;
  location: string;
  supplier: string;
  lastDelivery: string;
  nextDelivery: string;
  quality: 'Grade A' | 'Grade B' | 'Standard' | 'Premium';
  status: 'In Stock' | 'Low Stock' | 'Out of Stock' | 'On Order' | 'Reserved';
  description: string;
  specifications: {
    material: string;
    grade: string;
    certification: string;
    [key: string]: string;
  };
  usage: {
    project: string;
    quantity: number;
    date: string;
    purpose: string;
  }[];
  deliveries: {
    date: string;
    quantity: number;
    supplier: string;
    batchNumber: string;
    quality: string;
    cost: number;
  }[];
}

const mockMaterials: Material[] = [
  {
    id: '1',
    name: 'Structural Steel Beam',
    category: 'Steel',
    sku: 'STL-BEAM-001',
    currentStock: 150,
    minStock: 50,
    maxStock: 300,
    unit: 'tons',
    unitPrice: 85000,
    totalValue: 12750000,
    location: 'Warehouse A - Bay 3',
    supplier: 'BSRM Steel Mills Ltd.',
    lastDelivery: '2024-08-15',
    nextDelivery: '2024-09-15',
    quality: 'Grade A',
    status: 'In Stock',
    description: 'High-grade structural steel beams for power plant construction',
    specifications: {
      material: 'Carbon Steel',
      grade: 'S355',
      certification: 'ASTM A992',
      length: '12m',
      weight: '500kg/unit'
    },
    usage: [
      {
        project: 'Payra Coal Power Plant Unit 2',
        quantity: 25,
        date: '2024-08-20',
        purpose: 'Turbine Hall Construction'
      },
      {
        project: 'Rooppur Nuclear Infrastructure',
        quantity: 15,
        date: '2024-08-18',
        purpose: 'Support Structure'
      }
    ],
    deliveries: [
      {
        date: '2024-08-15',
        quantity: 100,
        supplier: 'BSRM Steel Mills Ltd.',
        batchNumber: 'BSRM-2024-045',
        quality: 'Grade A',
        cost: 8500000
      },
      {
        date: '2024-07-10',
        quantity: 75,
        supplier: 'BSRM Steel Mills Ltd.',
        batchNumber: 'BSRM-2024-032',
        quality: 'Grade A',
        cost: 6375000
      }
    ]
  },
  {
    id: '2',
    name: 'High Voltage Cable',
    category: 'Cable',
    sku: 'CBL-HV-400',
    currentStock: 2500,
    minStock: 1000,
    maxStock: 5000,
    unit: 'meters',
    unitPrice: 1200,
    totalValue: 3000000,
    location: 'Cable Storage - Section B',
    supplier: 'Walton Hi-Tech Industries',
    lastDelivery: '2024-08-10',
    nextDelivery: '2024-09-20',
    quality: 'Premium',
    status: 'In Stock',
    description: '400kV high voltage transmission cable',
    specifications: {
      material: 'XLPE Insulated',
      grade: 'Premium',
      certification: 'IEC 60840',
      voltage: '400kV',
      conductor: 'Aluminum'
    },
    usage: [
      {
        project: 'Dhaka-Cumilla 400kV Transmission',
        quantity: 500,
        date: '2024-08-12',
        purpose: 'Main Transmission Line'
      }
    ],
    deliveries: [
      {
        date: '2024-08-10',
        quantity: 1000,
        supplier: 'Walton Hi-Tech Industries',
        batchNumber: 'WHI-2024-067',
        quality: 'Premium',
        cost: 1200000
      }
    ]
  },
  {
    id: '3',
    name: 'Ready Mix Concrete',
    category: 'Concrete',
    sku: 'CON-RMC-M35',
    currentStock: 25,
    minStock: 20,
    maxStock: 100,
    unit: 'cubic meters',
    unitPrice: 8500,
    totalValue: 212500,
    location: 'On-site Batching Plant',
    supplier: 'Bashundhara Cement',
    lastDelivery: '2024-08-25',
    nextDelivery: '2024-09-01',
    quality: 'Standard',
    status: 'Low Stock',
    description: 'M35 grade ready mix concrete for foundation work',
    specifications: {
      material: 'Portland Cement',
      grade: 'M35',
      certification: 'ASTM C150',
      strength: '35 MPa',
      slump: '75-100mm'
    },
    usage: [
      {
        project: 'Payra Coal Power Plant Unit 2',
        quantity: 50,
        date: '2024-08-22',
        purpose: 'Foundation Pour'
      }
    ],
    deliveries: [
      {
        date: '2024-08-25',
        quantity: 75,
        supplier: 'Bashundhara Cement',
        batchNumber: 'BC-2024-089',
        quality: 'Standard',
        cost: 637500
      }
    ]
  },
  {
    id: '4',
    name: 'Safety Helmets',
    category: 'Safety',
    sku: 'SFT-HLM-001',
    currentStock: 5,
    minStock: 50,
    maxStock: 200,
    unit: 'pieces',
    unitPrice: 850,
    totalValue: 4250,
    location: 'Safety Equipment Store',
    supplier: 'Medico Safety Products',
    lastDelivery: '2024-07-30',
    nextDelivery: '2024-09-05',
    quality: 'Standard',
    status: 'Out of Stock',
    description: 'Industrial safety helmets with chin strap',
    specifications: {
      material: 'HDPE',
      grade: 'Industrial',
      certification: 'ANSI Z89.1',
      color: 'Yellow',
      weight: '350g'
    },
    usage: [
      {
        project: 'All Active Projects',
        quantity: 45,
        date: '2024-08-15',
        purpose: 'Worker Safety Equipment'
      }
    ],
    deliveries: [
      {
        date: '2024-07-30',
        quantity: 50,
        supplier: 'Medico Safety Products',
        batchNumber: 'MSP-2024-156',
        quality: 'Standard',
        cost: 42500
      }
    ]
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'In Stock': return 'bg-green-500';
    case 'Low Stock': return 'bg-yellow-500';
    case 'Out of Stock': return 'bg-red-500';
    case 'On Order': return 'bg-blue-500';
    case 'Reserved': return 'bg-purple-500';
    default: return 'bg-gray-500';
  }
};

const getStatusBadgeVariant = (status: string) => {
  switch (status) {
    case 'In Stock': return 'default';
    case 'Low Stock': return 'secondary';
    case 'Out of Stock': return 'destructive';
    case 'On Order': return 'outline';
    case 'Reserved': return 'secondary';
    default: return 'secondary';
  }
};

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-BD', {
    style: 'currency',
    currency: 'BDT',
    notation: 'compact',
    maximumFractionDigits: 1
  }).format(amount);
};

const getStockLevel = (current: number, min: number, max: number) => {
  return Math.round((current / max) * 100);
};

export default function MaterialManagement() {
  const [materials, setMaterials] = useState<Material[]>(mockMaterials);
  const [selectedMaterial, setSelectedMaterial] = useState<Material | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');

  const filteredMaterials = materials.filter(material => {
    const matchesSearch = material.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.supplier.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || material.status === filterStatus;
    const matchesCategory = filterCategory === 'all' || material.category === filterCategory;
    return matchesSearch && matchesStatus && matchesCategory;
  });

  const totalMaterials = materials.length;
  const totalValue = materials.reduce((sum, material) => sum + material.totalValue, 0);
  const lowStockItems = materials.filter(m => m.currentStock <= m.minStock).length;
  const outOfStockItems = materials.filter(m => m.status === 'Out of Stock').length;
  const avgStockLevel = materials.reduce((sum, material) => sum + getStockLevel(material.currentStock, material.minStock, material.maxStock), 0) / materials.length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
              Material & Inventory Management
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Track and manage construction materials and supplies
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Truck className="w-4 h-4 mr-2" />
              New Delivery
            </Button>
            <Button className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Material
            </Button>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Materials</p>
                  <p className="text-2xl font-bold text-blue-600">{totalMaterials}</p>
                </div>
                <Package className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Value</p>
                  <p className="text-2xl font-bold text-green-600">{formatCurrency(totalValue)}</p>
                </div>
                <DollarSign className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Low Stock</p>
                  <p className="text-2xl font-bold text-yellow-600">{lowStockItems}</p>
                </div>
                <TrendingDown className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Out of Stock</p>
                  <p className="text-2xl font-bold text-red-600">{outOfStockItems}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-red-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Avg Stock Level</p>
                  <p className="text-2xl font-bold text-purple-600">{avgStockLevel.toFixed(1)}%</p>
                </div>
                <BarChart3 className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Search materials..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="In Stock">In Stock</SelectItem>
                  <SelectItem value="Low Stock">Low Stock</SelectItem>
                  <SelectItem value="Out of Stock">Out of Stock</SelectItem>
                  <SelectItem value="On Order">On Order</SelectItem>
                  <SelectItem value="Reserved">Reserved</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Steel">Steel</SelectItem>
                  <SelectItem value="Concrete">Concrete</SelectItem>
                  <SelectItem value="Cable">Cable</SelectItem>
                  <SelectItem value="Pipe">Pipe</SelectItem>
                  <SelectItem value="Equipment">Equipment</SelectItem>
                  <SelectItem value="Chemical">Chemical</SelectItem>
                  <SelectItem value="Safety">Safety</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Materials List */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredMaterials.map((material, index) => (
            <motion.div
              key={material.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card 
                className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedMaterial(material)}
              >
                <CardHeader className="pb-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-1">{material.name}</CardTitle>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{material.sku}</p>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline">{material.category}</Badge>
                        <Badge variant={getStatusBadgeVariant(material.status) as any}>{material.status}</Badge>
                      </div>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${getStatusColor(material.status)}`}></div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center gap-1">
                      <Warehouse className="w-4 h-4" />
                      {material.location}
                    </div>
                    <div className="flex items-center gap-1">
                      <Truck className="w-4 h-4" />
                      {material.supplier}
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Stock Level</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {material.currentStock} / {material.maxStock} {material.unit}
                      </span>
                    </div>
                    <Progress value={getStockLevel(material.currentStock, material.minStock, material.maxStock)} className="h-2" />
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Unit Price</span>
                      <span className="font-medium">{formatCurrency(material.unitPrice)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Total Value</span>
                      <span className="font-medium">{formatCurrency(material.totalValue)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Next Delivery</span>
                      <span className="font-medium">{new Date(material.nextDelivery).toLocaleDateString()}</span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-gray-200 dark:border-gray-700">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      Quality: {material.quality}
                    </span>
                    <span className="text-sm font-medium">
                      {material.currentStock} {material.unit}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Material Details Modal */}
        {selectedMaterial && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <Card className="w-full max-w-5xl max-h-[90vh] overflow-y-auto backdrop-blur-sm bg-white/95 dark:bg-gray-900/95">
              <CardHeader className="flex flex-row items-start justify-between">
                <div>
                  <CardTitle className="text-2xl">{selectedMaterial.name}</CardTitle>
                  <CardDescription className="mt-2">{selectedMaterial.description}</CardDescription>
                </div>
                <Button 
                  variant="ghost" 
                  onClick={() => setSelectedMaterial(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="overview" className="w-full">
                  <TabsList className="grid w-full grid-cols-5">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="specifications">Specifications</TabsTrigger>
                    <TabsTrigger value="usage">Usage</TabsTrigger>
                    <TabsTrigger value="deliveries">Deliveries</TabsTrigger>
                    <TabsTrigger value="analytics">Analytics</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="overview" className="space-y-6 mt-6">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                        <Package className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Current Stock</p>
                        <p className="font-semibold">{selectedMaterial.currentStock} {selectedMaterial.unit}</p>
                      </div>
                      <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <DollarSign className="w-6 h-6 mx-auto mb-2 text-green-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Total Value</p>
                        <p className="font-semibold">{formatCurrency(selectedMaterial.totalValue)}</p>
                      </div>
                      <div className="text-center p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                        <AlertTriangle className="w-6 h-6 mx-auto mb-2 text-yellow-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Min Stock</p>
                        <p className="font-semibold">{selectedMaterial.minStock} {selectedMaterial.unit}</p>
                      </div>
                      <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                        <TrendingUp className="w-6 h-6 mx-auto mb-2 text-purple-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Max Stock</p>
                        <p className="font-semibold">{selectedMaterial.maxStock} {selectedMaterial.unit}</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Material Details</h3>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">SKU:</span>
                            <span className="font-medium">{selectedMaterial.sku}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Category:</span>
                            <Badge>{selectedMaterial.category}</Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Status:</span>
                            <Badge variant={getStatusBadgeVariant(selectedMaterial.status) as any}>{selectedMaterial.status}</Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Quality:</span>
                            <span className="font-medium">{selectedMaterial.quality}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Location:</span>
                            <span className="font-medium">{selectedMaterial.location}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Supply Information</h3>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Supplier:</span>
                            <span className="font-medium">{selectedMaterial.supplier}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Unit Price:</span>
                            <span className="font-medium">{formatCurrency(selectedMaterial.unitPrice)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Last Delivery:</span>
                            <span className="font-medium">{new Date(selectedMaterial.lastDelivery).toLocaleDateString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Next Delivery:</span>
                            <span className="font-medium">{new Date(selectedMaterial.nextDelivery).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="specifications" className="space-y-4 mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {Object.entries(selectedMaterial.specifications).map(([key, value]) => (
                        <div key={key} className="flex justify-between items-center p-4 border rounded-lg">
                          <span className="font-medium capitalize">{key}:</span>
                          <span className="text-gray-600 dark:text-gray-400">{value}</span>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="usage" className="space-y-4 mt-6">
                    {selectedMaterial.usage.map((usage, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium">{usage.project}</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{usage.purpose}</p>
                          </div>
                          <Badge variant="outline">{usage.quantity} {selectedMaterial.unit}</Badge>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Date: {new Date(usage.date).toLocaleDateString()}
                        </p>
                      </div>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="deliveries" className="space-y-4 mt-6">
                    {selectedMaterial.deliveries.map((delivery, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium">Delivery #{delivery.batchNumber}</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{delivery.supplier}</p>
                          </div>
                          <div className="text-right">
                            <Badge variant="outline">{delivery.quantity} {selectedMaterial.unit}</Badge>
                            <p className="text-sm font-medium mt-1">{formatCurrency(delivery.cost)}</p>
                          </div>
                        </div>
                        <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400">
                          <span>Date: {new Date(delivery.date).toLocaleDateString()}</span>
                          <span>Quality: {delivery.quality}</span>
                        </div>
                      </div>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="analytics" className="space-y-6 mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Stock Trend</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="h-32 flex items-center justify-center text-gray-500">
                            <BarChart3 className="w-8 h-8 mr-2" />
                            Stock analytics would be displayed here
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Usage Pattern</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="h-32 flex items-center justify-center text-gray-500">
                            <PieChart className="w-8 h-8 mr-2" />
                            Usage analytics would be displayed here
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}