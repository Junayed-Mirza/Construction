import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  FileText, FolderOpen, Upload, Download, Share2, Eye, Edit,
  Trash2, Lock, Unlock, Calendar, User, Search, Filter, Plus,
  CheckCircle, Clock, AlertTriangle, Star, Archive, Tag, X
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

interface Document {
  id: string;
  name: string;
  type: 'Drawing' | 'Specification' | 'Contract' | 'Report' | 'Certificate' | 'Manual' | 'Photo' | 'Video';
  category: 'Technical' | 'Legal' | 'Financial' | 'Safety' | 'Quality' | 'Environmental' | 'Procurement';
  projectId: string;
  projectName: string;
  version: string;
  size: number;
  format: string;
  uploadedBy: string;
  uploadDate: string;
  lastModified: string;
  status: 'Draft' | 'Under Review' | 'Approved' | 'Archived' | 'Obsolete';
  accessLevel: 'Public' | 'Internal' | 'Confidential' | 'Restricted';
  tags: string[];
  description: string;
  location: string;
  reviewers: string[];
  approvers: string[];
  checkoutBy?: string;
  checkoutDate?: string;
  relatedDocuments: string[];
  revisionHistory: {
    version: string;
    date: string;
    author: string;
    changes: string;
  }[];
}

interface Folder {
  id: string;
  name: string;
  parentId?: string;
  projectId: string;
  projectName: string;
  type: 'Project' | 'Category' | 'Department' | 'Archive';
  documentCount: number;
  totalSize: number;
  permissions: string[];
  createdBy: string;
  createdDate: string;
  description: string;
}

const mockDocuments: Document[] = [
  {
    id: '1',
    name: 'Turbine Installation Drawing - Rev C',
    type: 'Drawing',
    category: 'Technical',
    projectId: '1',
    projectName: 'Payra Coal Power Plant Unit 2',
    version: 'C',
    size: 15728640, // 15 MB
    format: 'PDF',
    uploadedBy: 'Eng. Rahman Ahmed',
    uploadDate: '2024-08-25',
    lastModified: '2024-08-25',
    status: 'Approved',
    accessLevel: 'Internal',
    tags: ['turbine', 'installation', 'mechanical'],
    description: 'Detailed installation drawing for steam turbine assembly',
    location: '/Projects/Payra/Technical/Drawings/',
    reviewers: ['Chief Engineer', 'Project Manager'],
    approvers: ['Design Manager'],
    relatedDocuments: ['2', '3'],
    revisionHistory: [
      {
        version: 'A',
        date: '2024-06-15',
        author: 'Design Team',
        changes: 'Initial release'
      },
      {
        version: 'B',
        date: '2024-07-20',
        author: 'Eng. Rahman Ahmed',
        changes: 'Updated dimensions and tolerances'
      },
      {
        version: 'C',
        date: '2024-08-25',
        author: 'Eng. Rahman Ahmed',
        changes: 'Added safety specifications'
      }
    ]
  },
  {
    id: '2',
    name: 'Safety Protocol Manual',
    type: 'Manual',
    category: 'Safety',
    projectId: '1',
    projectName: 'Payra Coal Power Plant Unit 2',
    version: '2.1',
    size: 5242880, // 5 MB
    format: 'PDF',
    uploadedBy: 'Safety Officer - Ahmed Rahman',
    uploadDate: '2024-08-20',
    lastModified: '2024-08-23',
    status: 'Under Review',
    accessLevel: 'Public',
    tags: ['safety', 'protocol', 'manual', 'procedures'],
    description: 'Comprehensive safety procedures and protocols for construction site',
    location: '/Projects/Payra/Safety/',
    reviewers: ['HSE Manager', 'Site Manager'],
    approvers: ['Project Director'],
    relatedDocuments: ['1'],
    revisionHistory: [
      {
        version: '1.0',
        date: '2024-05-10',
        author: 'HSE Team',
        changes: 'Initial version'
      },
      {
        version: '2.0',
        date: '2024-07-15',
        author: 'Safety Officer',
        changes: 'Updated emergency procedures'
      },
      {
        version: '2.1',
        date: '2024-08-20',
        author: 'Safety Officer',
        changes: 'Added COVID-19 protocols'
      }
    ]
  },
  {
    id: '3',
    name: 'Environmental Impact Assessment',
    type: 'Report',
    category: 'Environmental',
    projectId: '2',
    projectName: 'Dhaka-Cumilla 400kV Transmission',
    version: '1.0',
    size: 25165824, // 24 MB
    format: 'PDF',
    uploadedBy: 'Environmental Consultant',
    uploadDate: '2024-08-15',
    lastModified: '2024-08-15',
    status: 'Approved',
    accessLevel: 'Confidential',
    tags: ['environment', 'impact', 'assessment', 'compliance'],
    description: 'Detailed environmental impact assessment for transmission line project',
    location: '/Projects/Transmission/Environmental/',
    reviewers: ['Environmental Manager', 'Regulatory Affairs'],
    approvers: ['Project Manager', 'Environmental Authority'],
    relatedDocuments: [],
    revisionHistory: [
      {
        version: '1.0',
        date: '2024-08-15',
        author: 'Environmental Team',
        changes: 'Final approved version'
      }
    ]
  },
  {
    id: '4',
    name: 'Contractor Performance Certificate',
    type: 'Certificate',
    category: 'Quality',
    projectId: '3',
    projectName: 'Rooppur Nuclear Infrastructure',
    version: '1.0',
    size: 2097152, // 2 MB
    format: 'PDF',
    uploadedBy: 'Quality Manager',
    uploadDate: '2024-08-10',
    lastModified: '2024-08-10',
    status: 'Approved',
    accessLevel: 'Internal',
    tags: ['certificate', 'contractor', 'performance', 'quality'],
    description: 'Performance certificate for main contractor work quality',
    location: '/Projects/Rooppur/Quality/Certificates/',
    reviewers: ['QA Manager'],
    approvers: ['Project Director'],
    relatedDocuments: [],
    revisionHistory: [
      {
        version: '1.0',
        date: '2024-08-10',
        author: 'QA Team',
        changes: 'Initial certificate issuance'
      }
    ]
  }
];

const mockFolders: Folder[] = [
  {
    id: '1',
    name: 'Payra Coal Power Plant Unit 2',
    projectId: '1',
    projectName: 'Payra Coal Power Plant Unit 2',
    type: 'Project',
    documentCount: 156,
    totalSize: 2147483648, // 2 GB
    permissions: ['read', 'write', 'delete'],
    createdBy: 'Project Manager',
    createdDate: '2023-01-15',
    description: 'All documents related to Payra Coal Power Plant Unit 2 construction'
  },
  {
    id: '2',
    name: 'Technical Drawings',
    parentId: '1',
    projectId: '1',
    projectName: 'Payra Coal Power Plant Unit 2',
    type: 'Category',
    documentCount: 45,
    totalSize: 524288000, // 500 MB
    permissions: ['read', 'write'],
    createdBy: 'Chief Engineer',
    createdDate: '2023-02-01',
    description: 'Technical drawings and engineering documents'
  },
  {
    id: '3',
    name: 'Safety Documentation',
    parentId: '1',
    projectId: '1',
    projectName: 'Payra Coal Power Plant Unit 2',
    type: 'Category',
    documentCount: 28,
    totalSize: 104857600, // 100 MB
    permissions: ['read'],
    createdBy: 'Safety Officer',
    createdDate: '2023-02-01',
    description: 'Safety protocols, procedures, and incident reports'
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'Approved': return 'bg-green-500';
    case 'Under Review': return 'bg-yellow-500';
    case 'Draft': return 'bg-blue-500';
    case 'Archived': return 'bg-gray-500';
    case 'Obsolete': return 'bg-red-500';
    default: return 'bg-gray-500';
  }
};

const getAccessLevelColor = (level: string) => {
  switch (level) {
    case 'Public': return 'default';
    case 'Internal': return 'secondary';
    case 'Confidential': return 'destructive';
    case 'Restricted': return 'outline';
    default: return 'secondary';
  }
};

const formatFileSize = (bytes: number) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export default function DocumentManagement() {
  const [documents, setDocuments] = useState<Document[]>(mockDocuments);
  const [folders, setFolders] = useState<Folder[]>(mockFolders);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [currentFolder, setCurrentFolder] = useState<string>('root');
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doc.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase())) ||
                         doc.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || doc.type === filterType;
    const matchesStatus = filterStatus === 'all' || doc.status === filterStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  const totalDocuments = documents.length;
  const totalSize = documents.reduce((sum, doc) => sum + doc.size, 0);
  const pendingReviews = documents.filter(d => d.status === 'Under Review').length;
  const approvedDocs = documents.filter(d => d.status === 'Approved').length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
              Document Management System
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Centralized document storage, version control, and collaboration
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <FolderOpen className="w-4 h-4 mr-2" />
              New Folder
            </Button>
            <Button className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700">
              <Upload className="w-4 h-4 mr-2" />
              Upload Document
            </Button>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Documents</p>
                  <p className="text-2xl font-bold text-blue-600">{totalDocuments}</p>
                </div>
                <FileText className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Storage Used</p>
                  <p className="text-2xl font-bold text-green-600">{formatFileSize(totalSize)}</p>
                </div>
                <Archive className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Pending Reviews</p>
                  <p className="text-2xl font-bold text-yellow-600">{pendingReviews}</p>
                </div>
                <Clock className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Approved</p>
                  <p className="text-2xl font-bold text-purple-600">{approvedDocs}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Search documents..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />
              </div>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Drawing">Drawing</SelectItem>
                  <SelectItem value="Specification">Specification</SelectItem>
                  <SelectItem value="Contract">Contract</SelectItem>
                  <SelectItem value="Report">Report</SelectItem>
                  <SelectItem value="Certificate">Certificate</SelectItem>
                  <SelectItem value="Manual">Manual</SelectItem>
                  <SelectItem value="Photo">Photo</SelectItem>
                  <SelectItem value="Video">Video</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Draft">Draft</SelectItem>
                  <SelectItem value="Under Review">Under Review</SelectItem>
                  <SelectItem value="Approved">Approved</SelectItem>
                  <SelectItem value="Archived">Archived</SelectItem>
                  <SelectItem value="Obsolete">Obsolete</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Documents List */}
        <div className="space-y-4">
          {filteredDocuments.map((document, index) => (
            <motion.div
              key={document.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card 
                className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedDocument(document)}
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 flex-1">
                      <FileText className="w-8 h-8 text-blue-600" />
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold text-lg">{document.name}</h3>
                          <Badge variant="outline">{document.type}</Badge>
                          <Badge variant={getAccessLevelColor(document.accessLevel) as any}>{document.accessLevel}</Badge>
                          <div className={`w-3 h-3 rounded-full ${getStatusColor(document.status)}`}></div>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400 mb-2">
                          <span>{document.projectName}</span>
                          <span>•</span>
                          <span>v{document.version}</span>
                          <span>•</span>
                          <span>{formatFileSize(document.size)}</span>
                          <span>•</span>
                          <span>{document.format}</span>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{document.description}</p>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {document.tags.slice(0, 3).map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {document.tags.length > 3 && (
                            <Badge variant="secondary" className="text-xs">
                              +{document.tags.length - 3} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end space-y-2">
                      <Badge variant={document.status === 'Approved' ? 'default' : document.status === 'Under Review' ? 'secondary' : 'outline'}>
                        {document.status}
                      </Badge>
                      <div className="text-right text-sm text-gray-600 dark:text-gray-400">
                        <p>Modified: {new Date(document.lastModified).toLocaleDateString()}</p>
                        <p>By: {document.uploadedBy}</p>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Download className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Document Details Modal */}
        {selectedDocument && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto backdrop-blur-sm bg-white/95 dark:bg-gray-900/95">
              <CardHeader className="flex flex-row items-start justify-between">
                <div>
                  <CardTitle className="text-2xl">{selectedDocument.name}</CardTitle>
                  <CardDescription className="mt-2">{selectedDocument.description}</CardDescription>
                </div>
                <Button 
                  variant="ghost" 
                  onClick={() => setSelectedDocument(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="details" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="details">Details</TabsTrigger>
                    <TabsTrigger value="history">Version History</TabsTrigger>
                    <TabsTrigger value="permissions">Permissions</TabsTrigger>
                    <TabsTrigger value="related">Related Docs</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="details" className="space-y-6 mt-6">
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-2">Document Information</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Type:</span>
                              <Badge variant="outline">{selectedDocument.type}</Badge>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Category:</span>
                              <span className="font-medium">{selectedDocument.category}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Version:</span>
                              <span className="font-medium">{selectedDocument.version}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Size:</span>
                              <span className="font-medium">{formatFileSize(selectedDocument.size)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Format:</span>
                              <span className="font-medium">{selectedDocument.format}</span>
                            </div>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">Tags</h4>
                          <div className="flex flex-wrap gap-2">
                            {selectedDocument.tags.map((tag, index) => (
                              <Badge key={index} variant="secondary">
                                <Tag className="w-3 h-3 mr-1" />
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-2">Project & Location</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Project:</span>
                              <span className="font-medium">{selectedDocument.projectName}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Location:</span>
                              <span className="font-medium">{selectedDocument.location}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Access Level:</span>
                              <Badge variant={getAccessLevelColor(selectedDocument.accessLevel) as any}>
                                {selectedDocument.accessLevel}
                              </Badge>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Status:</span>
                              <Badge variant={selectedDocument.status === 'Approved' ? 'default' : 'secondary'}>
                                {selectedDocument.status}
                              </Badge>
                            </div>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">Dates</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Uploaded:</span>
                              <span className="font-medium">{new Date(selectedDocument.uploadDate).toLocaleDateString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Modified:</span>
                              <span className="font-medium">{new Date(selectedDocument.lastModified).toLocaleDateString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Uploaded By:</span>
                              <span className="font-medium">{selectedDocument.uploadedBy}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="history" className="space-y-4 mt-6">
                    {selectedDocument.revisionHistory.map((revision, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium">Version {revision.version}</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{revision.changes}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm text-gray-600 dark:text-gray-400">{revision.author}</p>
                            <p className="text-xs text-gray-500">{new Date(revision.date).toLocaleDateString()}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="permissions" className="space-y-4 mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-semibold mb-2">Reviewers</h4>
                        <div className="space-y-2">
                          {selectedDocument.reviewers.map((reviewer, index) => (
                            <div key={index} className="flex items-center gap-2 p-2 border rounded">
                              <User className="w-4 h-4 text-gray-500" />
                              <span className="text-sm">{reviewer}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold mb-2">Approvers</h4>
                        <div className="space-y-2">
                          {selectedDocument.approvers.map((approver, index) => (
                            <div key={index} className="flex items-center gap-2 p-2 border rounded">
                              <CheckCircle className="w-4 h-4 text-green-500" />
                              <span className="text-sm">{approver}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="related" className="space-y-4 mt-6">
                    <div className="text-center p-8 text-gray-500">
                      <FileText className="w-12 h-12 mx-auto mb-4" />
                      <p>Related documents would be displayed here</p>
                      <p className="text-sm">Documents linked to: {selectedDocument.relatedDocuments.join(', ')}</p>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}