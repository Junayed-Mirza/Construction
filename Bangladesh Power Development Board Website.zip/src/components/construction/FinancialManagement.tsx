import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  DollarSign, TrendingUp, TrendingDown, AlertTriangle, CheckCircle, 
  Calendar, CreditCard, Wallet, PieChart, BarChart3, Calculator,
  FileText, Plus, Search, Filter, Download, Upload, RefreshCw, Clock, X
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

interface FinancialRecord {
  id: string;
  projectId: string;
  projectName: string;
  category: 'Budget' | 'Expense' | 'Payment' | 'Invoice' | 'Advance' | 'Retention';
  type: 'Material' | 'Labor' | 'Equipment' | 'Contractor' | 'Overhead' | 'Other';
  amount: number;
  currency: 'BDT' | 'USD' | 'EUR';
  date: string;
  description: string;
  status: 'Pending' | 'Approved' | 'Paid' | 'Cancelled' | 'Overdue';
  vendor: string;
  invoiceNumber?: string;
  approvedBy?: string;
  paymentMethod?: 'Bank Transfer' | 'Cheque' | 'Cash' | 'LC';
  dueDate?: string;
}

interface Budget {
  id: string;
  projectId: string;
  projectName: string;
  totalBudget: number;
  allocatedBudget: number;
  spentAmount: number;
  remainingBudget: number;
  utilization: number;
  categories: {
    material: { allocated: number; spent: number };
    labor: { allocated: number; spent: number };
    equipment: { allocated: number; spent: number };
    contractor: { allocated: number; spent: number };
    overhead: { allocated: number; spent: number };
  };
  milestones: {
    id: string;
    name: string;
    allocatedAmount: number;
    spentAmount: number;
    status: 'Not Started' | 'In Progress' | 'Completed';
  }[];
}

const mockFinancialRecords: FinancialRecord[] = [
  {
    id: '1',
    projectId: '1',
    projectName: 'Payra Coal Power Plant Unit 2',
    category: 'Payment',
    type: 'Contractor',
    amount: 250000000,
    currency: 'BDT',
    date: '2024-08-25',
    description: 'Monthly progress payment for construction milestone',
    status: 'Approved',
    vendor: 'China National Machinery Import & Export Corporation',
    invoiceNumber: 'CMEC-INV-2024-089',
    approvedBy: 'CFO - Finance Division',
    paymentMethod: 'Bank Transfer',
    dueDate: '2024-09-05'
  },
  {
    id: '2',
    projectId: '2',
    projectName: 'Dhaka-Cumilla 400kV Transmission',
    category: 'Expense',
    type: 'Material',
    amount: 12500000,
    currency: 'BDT',
    date: '2024-08-20',
    description: 'High voltage cables procurement',
    status: 'Paid',
    vendor: 'Walton Hi-Tech Industries',
    invoiceNumber: 'WHI-INV-2024-067',
    approvedBy: 'Project Manager',
    paymentMethod: 'Bank Transfer'
  },
  {
    id: '3',
    projectId: '3',
    projectName: 'Rooppur Nuclear Infrastructure',
    category: 'Invoice',
    type: 'Equipment',
    amount: 85000000,
    currency: 'USD',
    date: '2024-08-15',
    description: 'Specialized nuclear equipment delivery',
    status: 'Pending',
    vendor: 'Rosatom State Corporation',
    invoiceNumber: 'ROSATOM-INV-2024-045',
    dueDate: '2024-09-15'
  },
  {
    id: '4',
    projectId: '1',
    projectName: 'Payra Coal Power Plant Unit 2',
    category: 'Expense',
    type: 'Labor',
    amount: 8500000,
    currency: 'BDT',
    date: '2024-08-18',
    description: 'Monthly labor costs - August 2024',
    status: 'Approved',
    vendor: 'Local Labor Contractors',
    paymentMethod: 'Bank Transfer'
  },
  {
    id: '5',
    projectId: '2',
    projectName: 'Dhaka-Cumilla 400kV Transmission',
    category: 'Advance',
    type: 'Contractor',
    amount: 45000000,
    currency: 'BDT',
    date: '2024-08-10',
    description: 'Advance payment for material procurement',
    status: 'Paid',
    vendor: 'Power Grid Company of Bangladesh Ltd.',
    invoiceNumber: 'PGCB-ADV-2024-023',
    approvedBy: 'Finance Director',
    paymentMethod: 'Bank Transfer'
  }
];

const mockBudgets: Budget[] = [
  {
    id: '1',
    projectId: '1',
    projectName: 'Payra Coal Power Plant Unit 2',
    totalBudget: 2500000000,
    allocatedBudget: 2500000000,
    spentAmount: 1700000000,
    remainingBudget: 800000000,
    utilization: 68,
    categories: {
      material: { allocated: 800000000, spent: 520000000 },
      labor: { allocated: 400000000, spent: 280000000 },
      equipment: { allocated: 600000000, spent: 450000000 },
      contractor: { allocated: 500000000, spent: 350000000 },
      overhead: { allocated: 200000000, spent: 100000000 }
    },
    milestones: [
      { id: '1', name: 'Foundation Complete', allocatedAmount: 500000000, spentAmount: 500000000, status: 'Completed' },
      { id: '2', name: 'Structural Work', allocatedAmount: 800000000, spentAmount: 650000000, status: 'In Progress' },
      { id: '3', name: 'Equipment Installation', allocatedAmount: 700000000, spentAmount: 350000000, status: 'In Progress' },
      { id: '4', name: 'Commissioning', allocatedAmount: 500000000, spentAmount: 200000000, status: 'Not Started' }
    ]
  },
  {
    id: '2',
    projectId: '2',
    projectName: 'Dhaka-Cumilla 400kV Transmission',
    totalBudget: 850000000,
    allocatedBudget: 850000000,
    spentAmount: 382500000,
    remainingBudget: 467500000,
    utilization: 45,
    categories: {
      material: { allocated: 300000000, spent: 180000000 },
      labor: { allocated: 150000000, spent: 68000000 },
      equipment: { allocated: 200000000, spent: 85000000 },
      contractor: { allocated: 150000000, spent: 35000000 },
      overhead: { allocated: 50000000, spent: 14500000 }
    },
    milestones: [
      { id: '1', name: 'Land Acquisition', allocatedAmount: 100000000, spentAmount: 100000000, status: 'Completed' },
      { id: '2', name: 'Foundation & Towers', allocatedAmount: 350000000, spentAmount: 200000000, status: 'In Progress' },
      { id: '3', name: 'Cable Installation', allocatedAmount: 250000000, spentAmount: 82500000, status: 'In Progress' },
      { id: '4', name: 'Testing & Commissioning', allocatedAmount: 150000000, spentAmount: 0, status: 'Not Started' }
    ]
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'Paid': case 'Approved': return 'bg-green-500';
    case 'Pending': return 'bg-yellow-500';
    case 'Overdue': case 'Cancelled': return 'bg-red-500';
    default: return 'bg-gray-500';
  }
};

const getStatusBadgeVariant = (status: string) => {
  switch (status) {
    case 'Paid': case 'Approved': return 'default';
    case 'Pending': return 'secondary';
    case 'Overdue': case 'Cancelled': return 'destructive';
    default: return 'secondary';
  }
};

const formatCurrency = (amount: number, currency: string = 'BDT') => {
  const currencyConfig = {
    'BDT': { symbol: '৳', notation: 'compact' as const },
    'USD': { symbol: '$', notation: 'compact' as const },
    'EUR': { symbol: '€', notation: 'compact' as const }
  };

  const config = currencyConfig[currency as keyof typeof currencyConfig] || currencyConfig['BDT'];

  return new Intl.NumberFormat('en-BD', {
    style: 'currency',
    currency: currency,
    notation: config.notation,
    maximumFractionDigits: 1
  }).format(amount);
};

export default function FinancialManagement() {
  const [financialRecords, setFinancialRecords] = useState<FinancialRecord[]>(mockFinancialRecords);
  const [budgets, setBudgets] = useState<Budget[]>(mockBudgets);
  const [selectedRecord, setSelectedRecord] = useState<FinancialRecord | null>(null);
  const [selectedBudget, setSelectedBudget] = useState<Budget | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [activeTab, setActiveTab] = useState('overview');

  const filteredRecords = financialRecords.filter(record => {
    const matchesSearch = record.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         record.projectName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         record.vendor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || record.status === filterStatus;
    const matchesCategory = filterCategory === 'all' || record.category === filterCategory;
    return matchesSearch && matchesStatus && matchesCategory;
  });

  // Calculate totals
  const totalBudget = budgets.reduce((sum, budget) => sum + budget.totalBudget, 0);
  const totalSpent = budgets.reduce((sum, budget) => sum + budget.spentAmount, 0);
  const totalRemaining = budgets.reduce((sum, budget) => sum + budget.remainingBudget, 0);
  const avgUtilization = budgets.reduce((sum, budget) => sum + budget.utilization, 0) / budgets.length;

  const pendingPayments = financialRecords.filter(r => r.status === 'Pending' && (r.category === 'Payment' || r.category === 'Invoice')).length;
  const overduePayments = financialRecords.filter(r => r.status === 'Overdue').length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
              Financial Management
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Comprehensive financial tracking and budget management
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </Button>
            <Button variant="outline">
              <Upload className="w-4 h-4 mr-2" />
              Import Data
            </Button>
            <Button className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700">
              <Plus className="w-4 h-4 mr-2" />
              New Transaction
            </Button>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6">
          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Budget</p>
                  <p className="text-2xl font-bold text-blue-600">{formatCurrency(totalBudget)}</p>
                </div>
                <Wallet className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Spent</p>
                  <p className="text-2xl font-bold text-green-600">{formatCurrency(totalSpent)}</p>
                </div>
                <TrendingDown className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Remaining</p>
                  <p className="text-2xl font-bold text-purple-600">{formatCurrency(totalRemaining)}</p>
                </div>
                <Calculator className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Utilization</p>
                  <p className="text-2xl font-bold text-orange-600">{avgUtilization.toFixed(1)}%</p>
                </div>
                <PieChart className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Pending</p>
                  <p className="text-2xl font-bold text-yellow-600">{pendingPayments}</p>
                </div>
                <Clock className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Overdue</p>
                  <p className="text-2xl font-bold text-red-600">{overduePayments}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-red-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Financial Overview</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="budgets">Budget Management</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6 mt-6">
            {/* Budget Overview Cards */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {budgets.map((budget) => (
                <Card key={budget.id} className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                  <CardHeader>
                    <CardTitle className="text-lg">{budget.projectName}</CardTitle>
                    <CardDescription>Budget utilization and breakdown</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Total</p>
                        <p className="font-semibold">{formatCurrency(budget.totalBudget)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Spent</p>
                        <p className="font-semibold text-green-600">{formatCurrency(budget.spentAmount)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Remaining</p>
                        <p className="font-semibold text-blue-600">{formatCurrency(budget.remainingBudget)}</p>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium">Budget Utilization</span>
                        <span className="text-sm text-gray-600 dark:text-gray-400">{budget.utilization}%</span>
                      </div>
                      <Progress value={budget.utilization} className="h-3" />
                    </div>

                    <div className="space-y-2">
                      {Object.entries(budget.categories).map(([category, data]) => (
                        <div key={category} className="flex justify-between text-sm">
                          <span className="capitalize text-gray-600 dark:text-gray-400">{category}:</span>
                          <span className="font-medium">
                            {formatCurrency(data.spent)} / {formatCurrency(data.allocated)}
                          </span>
                        </div>
                      ))}
                    </div>

                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => setSelectedBudget(budget)}
                    >
                      View Details
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="transactions" className="space-y-6 mt-6">
            {/* Filters */}
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Search transactions..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-full md:w-48">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="Pending">Pending</SelectItem>
                      <SelectItem value="Approved">Approved</SelectItem>
                      <SelectItem value="Paid">Paid</SelectItem>
                      <SelectItem value="Cancelled">Cancelled</SelectItem>
                      <SelectItem value="Overdue">Overdue</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger className="w-full md:w-48">
                      <SelectValue placeholder="Filter by category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="Budget">Budget</SelectItem>
                      <SelectItem value="Expense">Expense</SelectItem>
                      <SelectItem value="Payment">Payment</SelectItem>
                      <SelectItem value="Invoice">Invoice</SelectItem>
                      <SelectItem value="Advance">Advance</SelectItem>
                      <SelectItem value="Retention">Retention</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Transactions List */}
            <div className="space-y-4">
              {filteredRecords.map((record, index) => (
                <motion.div
                  key={record.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card 
                    className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300 cursor-pointer"
                    onClick={() => setSelectedRecord(record)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <Badge variant="outline">{record.category}</Badge>
                            <Badge variant={getStatusBadgeVariant(record.status) as any}>{record.status}</Badge>
                            <div className={`w-3 h-3 rounded-full ${getStatusColor(record.status)}`}></div>
                          </div>
                          <h3 className="font-semibold text-lg">{record.description}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{record.projectName} • {record.vendor}</p>
                          {record.invoiceNumber && (
                            <p className="text-sm text-gray-500 dark:text-gray-500">Invoice: {record.invoiceNumber}</p>
                          )}
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-green-600">
                            {formatCurrency(record.amount, record.currency)}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {new Date(record.date).toLocaleDateString()}
                          </p>
                          {record.dueDate && (
                            <p className="text-sm text-yellow-600">
                              Due: {new Date(record.dueDate).toLocaleDateString()}
                            </p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="budgets" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 gap-6">
              {budgets.map((budget) => (
                <Card key={budget.id} className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                  <CardHeader>
                    <CardTitle className="text-xl">{budget.projectName}</CardTitle>
                    <CardDescription>Detailed budget breakdown and milestone tracking</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Budget Summary */}
                    <div className="grid grid-cols-4 gap-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                      <div className="text-center">
                        <p className="text-sm text-gray-600 dark:text-gray-400">Total Budget</p>
                        <p className="text-lg font-bold">{formatCurrency(budget.totalBudget)}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600 dark:text-gray-400">Spent</p>
                        <p className="text-lg font-bold text-green-600">{formatCurrency(budget.spentAmount)}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600 dark:text-gray-400">Remaining</p>
                        <p className="text-lg font-bold text-blue-600">{formatCurrency(budget.remainingBudget)}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600 dark:text-gray-400">Utilization</p>
                        <p className="text-lg font-bold text-purple-600">{budget.utilization}%</p>
                      </div>
                    </div>

                    {/* Category Breakdown */}
                    <div>
                      <h4 className="font-semibold mb-4">Category Breakdown</h4>
                      <div className="space-y-3">
                        {Object.entries(budget.categories).map(([category, data]) => {
                          const utilization = (data.spent / data.allocated) * 100;
                          return (
                            <div key={category} className="space-y-2">
                              <div className="flex justify-between items-center">
                                <span className="capitalize font-medium">{category}</span>
                                <span className="text-sm text-gray-600 dark:text-gray-400">
                                  {formatCurrency(data.spent)} / {formatCurrency(data.allocated)} ({utilization.toFixed(1)}%)
                                </span>
                              </div>
                              <Progress value={utilization} className="h-2" />
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Milestones */}
                    <div>
                      <h4 className="font-semibold mb-4">Milestone Progress</h4>
                      <div className="space-y-3">
                        {budget.milestones.map((milestone) => {
                          const utilization = milestone.allocatedAmount > 0 ? (milestone.spentAmount / milestone.allocatedAmount) * 100 : 0;
                          return (
                            <div key={milestone.id} className="p-4 border rounded-lg">
                              <div className="flex justify-between items-start mb-2">
                                <div>
                                  <p className="font-medium">{milestone.name}</p>
                                  <Badge variant={milestone.status === 'Completed' ? 'default' : milestone.status === 'In Progress' ? 'secondary' : 'outline'}>
                                    {milestone.status}
                                  </Badge>
                                </div>
                                <div className="text-right">
                                  <p className="font-semibold">{formatCurrency(milestone.spentAmount)}</p>
                                  <p className="text-sm text-gray-600 dark:text-gray-400">of {formatCurrency(milestone.allocatedAmount)}</p>
                                </div>
                              </div>
                              <Progress value={utilization} className="h-2" />
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Expense Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-48 flex items-center justify-center text-gray-500">
                    <BarChart3 className="w-12 h-12 mr-4" />
                    <span>Expense analytics chart would be displayed here</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Budget Utilization by Category</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-48 flex items-center justify-center text-gray-500">
                    <PieChart className="w-12 h-12 mr-4" />
                    <span>Budget utilization chart would be displayed here</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Cash Flow</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-48 flex items-center justify-center text-gray-500">
                    <TrendingUp className="w-12 h-12 mr-4" />
                    <span>Cash flow analytics would be displayed here</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Payment Status Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-48 flex items-center justify-center text-gray-500">
                    <PieChart className="w-12 h-12 mr-4" />
                    <span>Payment status distribution would be displayed here</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Transaction Details Modal */}
        {selectedRecord && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <Card className="w-full max-w-2xl backdrop-blur-sm bg-white/95 dark:bg-gray-900/95">
              <CardHeader className="flex flex-row items-start justify-between">
                <div>
                  <CardTitle className="text-xl">Transaction Details</CardTitle>
                  <CardDescription className="mt-2">{selectedRecord.description}</CardDescription>
                </div>
                <Button 
                  variant="ghost" 
                  onClick={() => setSelectedRecord(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Amount</label>
                    <p className="text-2xl font-bold text-green-600">{formatCurrency(selectedRecord.amount, selectedRecord.currency)}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Status</label>
                    <div className="mt-1">
                      <Badge variant={getStatusBadgeVariant(selectedRecord.status) as any}>{selectedRecord.status}</Badge>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Project:</span>
                    <span className="font-medium">{selectedRecord.projectName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Category:</span>
                    <Badge variant="outline">{selectedRecord.category}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Type:</span>
                    <span className="font-medium">{selectedRecord.type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Vendor:</span>
                    <span className="font-medium">{selectedRecord.vendor}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Date:</span>
                    <span className="font-medium">{new Date(selectedRecord.date).toLocaleDateString()}</span>
                  </div>
                  {selectedRecord.invoiceNumber && (
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Invoice:</span>
                      <span className="font-medium">{selectedRecord.invoiceNumber}</span>
                    </div>
                  )}
                  {selectedRecord.approvedBy && (
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Approved By:</span>
                      <span className="font-medium">{selectedRecord.approvedBy}</span>
                    </div>
                  )}
                  {selectedRecord.paymentMethod && (
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Payment Method:</span>
                      <span className="font-medium">{selectedRecord.paymentMethod}</span>
                    </div>
                  )}
                  {selectedRecord.dueDate && (
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Due Date:</span>
                      <span className="font-medium">{new Date(selectedRecord.dueDate).toLocaleDateString()}</span>
                    </div>
                  )}
                </div>

                <div className="flex gap-2 pt-4 border-t">
                  <Button variant="outline" className="flex-1">
                    <FileText className="w-4 h-4 mr-2" />
                    View Documents
                  </Button>
                  <Button variant="outline" className="flex-1">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Update Status
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}