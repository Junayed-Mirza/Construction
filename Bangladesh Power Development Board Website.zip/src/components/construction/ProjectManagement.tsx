import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Building2, Calendar, DollarSign, Users, AlertTriangle, CheckCircle, 
  Clock, TrendingUp, FileText, Settings, Plus, Search, Filter,
  BarChart3, PieChart, Activity, MapPin, Wrench, ShieldCheck, X
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

interface Project {
  id: string;
  name: string;
  type: 'Power Plant' | 'Transmission Line' | 'Distribution' | 'Substation' | 'Maintenance';
  status: 'Planning' | 'In Progress' | 'On Hold' | 'Completed' | 'Delayed';
  progress: number;
  budget: number;
  spent: number;
  startDate: string;
  endDate: string;
  location: string;
  contractor: string;
  manager: string;
  team: number;
  priority: 'High' | 'Medium' | 'Low';
  description: string;
  milestones: {
    id: string;
    name: string;
    date: string;
    status: 'Completed' | 'In Progress' | 'Pending';
  }[];
  risks: {
    id: string;
    description: string;
    severity: 'High' | 'Medium' | 'Low';
    status: 'Open' | 'Mitigated' | 'Resolved';
  }[];
}

const mockProjects: Project[] = [
  {
    id: '1',
    name: 'Payra Coal Power Plant Unit 2',
    type: 'Power Plant',
    status: 'In Progress',
    progress: 68,
    budget: 2500000000,
    spent: 1700000000,
    startDate: '2023-01-15',
    endDate: '2025-06-30',
    location: 'Payra, Patuakhali',
    contractor: 'China National Machinery Import & Export Corporation',
    manager: 'Eng. Rahman Ahmed',
    team: 150,
    priority: 'High',
    description: 'Construction of second unit of Payra Coal Power Plant with 660MW capacity',
    milestones: [
      { id: '1', name: 'Foundation Complete', date: '2023-08-15', status: 'Completed' },
      { id: '2', name: 'Structural Steel Installation', date: '2024-02-28', status: 'Completed' },
      { id: '3', name: 'Boiler Installation', date: '2024-08-15', status: 'In Progress' },
      { id: '4', name: 'Turbine Installation', date: '2024-12-30', status: 'Pending' }
    ],
    risks: [
      { id: '1', description: 'Weather delays during monsoon', severity: 'Medium', status: 'Mitigated' },
      { id: '2', description: 'Equipment delivery delays', severity: 'High', status: 'Open' }
    ]
  },
  {
    id: '2',
    name: 'Dhaka-Cumilla 400kV Transmission Line',
    type: 'Transmission Line',
    status: 'In Progress',
    progress: 45,
    budget: 850000000,
    spent: 382500000,
    startDate: '2023-06-01',
    endDate: '2024-12-15',
    location: 'Dhaka to Cumilla',
    contractor: 'Power Grid Company of Bangladesh',
    manager: 'Eng. Fatima Khan',
    team: 75,
    priority: 'High',
    description: '400kV transmission line construction for improved power transmission',
    milestones: [
      { id: '1', name: 'Land Acquisition', date: '2023-09-30', status: 'Completed' },
      { id: '2', name: 'Foundation Work', date: '2024-03-15', status: 'In Progress' },
      { id: '3', name: 'Tower Installation', date: '2024-08-30', status: 'Pending' }
    ],
    risks: [
      { id: '1', description: 'Land acquisition disputes', severity: 'Medium', status: 'Resolved' },
      { id: '2', description: 'Environmental clearance delays', severity: 'Low', status: 'Mitigated' }
    ]
  },
  {
    id: '3',
    name: 'Rooppur Nuclear Power Plant Infrastructure',
    type: 'Power Plant',
    status: 'In Progress',
    progress: 78,
    budget: 12000000000,
    spent: 9360000000,
    startDate: '2020-11-30',
    endDate: '2024-11-30',
    location: 'Rooppur, Pabna',
    contractor: 'Rosatom State Corporation',
    manager: 'Eng. Dr. Shafiqul Islam',
    team: 300,
    priority: 'High',
    description: 'Infrastructure development for Rooppur Nuclear Power Plant',
    milestones: [
      { id: '1', name: 'Site Preparation', date: '2021-06-30', status: 'Completed' },
      { id: '2', name: 'Reactor Building', date: '2023-12-31', status: 'Completed' },
      { id: '3', name: 'Turbine Hall Construction', date: '2024-06-30', status: 'In Progress' },
      { id: '4', name: 'Safety Systems Installation', date: '2024-09-30', status: 'Pending' }
    ],
    risks: [
      { id: '1', description: 'Regulatory approval delays', severity: 'High', status: 'Mitigated' },
      { id: '2', description: 'Specialized equipment delivery', severity: 'Medium', status: 'Open' }
    ]
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'Completed': return 'bg-green-500';
    case 'In Progress': return 'bg-blue-500';
    case 'On Hold': return 'bg-yellow-500';
    case 'Delayed': return 'bg-red-500';
    case 'Planning': return 'bg-gray-500';
    default: return 'bg-gray-500';
  }
};

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case 'High': return 'destructive';
    case 'Medium': return 'default';
    case 'Low': return 'secondary';
    default: return 'default';
  }
};

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-BD', {
    style: 'currency',
    currency: 'BDT',
    notation: 'compact',
    maximumFractionDigits: 1
  }).format(amount);
};

export default function ProjectManagement() {
  const [projects, setProjects] = useState<Project[]>(mockProjects);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');

  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.contractor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || project.status === filterStatus;
    const matchesType = filterType === 'all' || project.type === filterType;
    return matchesSearch && matchesStatus && matchesType;
  });

  const totalBudget = projects.reduce((sum, project) => sum + project.budget, 0);
  const totalSpent = projects.reduce((sum, project) => sum + project.spent, 0);
  const avgProgress = projects.reduce((sum, project) => sum + project.progress, 0) / projects.length;
  const activeProjects = projects.filter(p => p.status === 'In Progress').length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
              Project Management
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Comprehensive construction project tracking and management
            </p>
          </div>
          <Button className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700">
            <Plus className="w-4 h-4 mr-2" />
            New Project
          </Button>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Budget</p>
                  <p className="text-2xl font-bold text-green-600">{formatCurrency(totalBudget)}</p>
                </div>
                <DollarSign className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Spent</p>
                  <p className="text-2xl font-bold text-blue-600">{formatCurrency(totalSpent)}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Active Projects</p>
                  <p className="text-2xl font-bold text-purple-600">{activeProjects}</p>
                </div>
                <Building2 className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Avg Progress</p>
                  <p className="text-2xl font-bold text-orange-600">{avgProgress.toFixed(1)}%</p>
                </div>
                <Activity className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Search projects..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Planning">Planning</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="On Hold">On Hold</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                  <SelectItem value="Delayed">Delayed</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Power Plant">Power Plant</SelectItem>
                  <SelectItem value="Transmission Line">Transmission Line</SelectItem>
                  <SelectItem value="Distribution">Distribution</SelectItem>
                  <SelectItem value="Substation">Substation</SelectItem>
                  <SelectItem value="Maintenance">Maintenance</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Projects List */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card 
                className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedProject(project)}
              >
                <CardHeader className="pb-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-2">{project.name}</CardTitle>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline">{project.type}</Badge>
                        <Badge variant={getPriorityColor(project.priority) as any}>{project.priority}</Badge>
                      </div>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${getStatusColor(project.status)}`}></div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {project.location}
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {project.team} members
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Progress</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">{project.progress}%</span>
                    </div>
                    <Progress value={project.progress} className="h-2" />
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600 dark:text-gray-400">Budget</p>
                      <p className="font-semibold">{formatCurrency(project.budget)}</p>
                    </div>
                    <div>
                      <p className="text-gray-600 dark:text-gray-400">Spent</p>
                      <p className="font-semibold">{formatCurrency(project.spent)}</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-gray-200 dark:border-gray-700">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {project.manager}
                    </span>
                    <span className="text-sm font-medium text-blue-600">
                      {project.status}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Project Details Modal would go here */}
        {selectedProject && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto backdrop-blur-sm bg-white/95 dark:bg-gray-900/95">
              <CardHeader className="flex flex-row items-start justify-between">
                <div>
                  <CardTitle className="text-2xl">{selectedProject.name}</CardTitle>
                  <CardDescription className="mt-2">{selectedProject.description}</CardDescription>
                </div>
                <Button 
                  variant="ghost" 
                  onClick={() => setSelectedProject(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="overview" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="milestones">Milestones</TabsTrigger>
                    <TabsTrigger value="risks">Risks</TabsTrigger>
                    <TabsTrigger value="team">Team</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="overview" className="space-y-6 mt-6">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                        <Calendar className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Start Date</p>
                        <p className="font-semibold">{new Date(selectedProject.startDate).toLocaleDateString()}</p>
                      </div>
                      <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <Clock className="w-6 h-6 mx-auto mb-2 text-green-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">End Date</p>
                        <p className="font-semibold">{new Date(selectedProject.endDate).toLocaleDateString()}</p>
                      </div>
                      <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                        <DollarSign className="w-6 h-6 mx-auto mb-2 text-purple-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Budget</p>
                        <p className="font-semibold">{formatCurrency(selectedProject.budget)}</p>
                      </div>
                      <div className="text-center p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                        <TrendingUp className="w-6 h-6 mx-auto mb-2 text-orange-600" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">Progress</p>
                        <p className="font-semibold">{selectedProject.progress}%</p>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="milestones" className="space-y-4 mt-6">
                    {selectedProject.milestones.map((milestone) => (
                      <div key={milestone.id} className="flex items-center gap-4 p-4 border rounded-lg">
                        <div className={`w-3 h-3 rounded-full ${getStatusColor(milestone.status)}`}></div>
                        <div className="flex-1">
                          <p className="font-medium">{milestone.name}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            Due: {new Date(milestone.date).toLocaleDateString()}
                          </p>
                        </div>
                        <Badge variant={milestone.status === 'Completed' ? 'default' : 'secondary'}>
                          {milestone.status}
                        </Badge>
                      </div>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="risks" className="space-y-4 mt-6">
                    {selectedProject.risks.map((risk) => (
                      <div key={risk.id} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <p className="font-medium">{risk.description}</p>
                          <Badge variant={risk.severity === 'High' ? 'destructive' : risk.severity === 'Medium' ? 'default' : 'secondary'}>
                            {risk.severity}
                          </Badge>
                        </div>
                        <Badge variant={risk.status === 'Resolved' ? 'default' : 'secondary'}>
                          {risk.status}
                        </Badge>
                      </div>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="team" className="space-y-4 mt-6">
                    <div className="text-center p-8">
                      <Users className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                      <p className="text-lg font-medium">Project Manager: {selectedProject.manager}</p>
                      <p className="text-gray-600 dark:text-gray-400">Team Size: {selectedProject.team} members</p>
                      <p className="text-gray-600 dark:text-gray-400 mt-2">Contractor: {selectedProject.contractor}</p>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}