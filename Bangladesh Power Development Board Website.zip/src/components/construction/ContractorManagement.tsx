import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Users, Star, TrendingUp, TrendingDown, Award, AlertTriangle, 
  CheckCircle, Clock, DollarSign, FileText, Phone, Mail, MapPin,
  Calendar, Building2, Plus, Search, Filter, BarChart3, Shield, X
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

interface Contractor {
  id: string;
  name: string;
  type: 'General Contractor' | 'Electrical' | 'Mechanical' | 'Civil' | 'Specialized' | 'Consultant';
  registrationNumber: string;
  license: string;
  status: 'Active' | 'Under Review' | 'Suspended' | 'Blacklisted' | 'Prequalified';
  rating: number;
  totalProjects: number;
  completedProjects: number;
  ongoingProjects: number;
  totalContractValue: number;
  contact: {
    email: string;
    phone: string;
    address: string;
    website?: string;
    contactPerson: string;
    designation: string;
  };
  capabilities: string[];
  certifications: {
    name: string;
    issuedBy: string;
    validUntil: string;
    status: 'Valid' | 'Expired' | 'Pending Renewal';
  }[];
  projects: {
    id: string;
    name: string;
    value: number;
    status: 'Completed' | 'Ongoing' | 'Delayed' | 'Cancelled';
    startDate: string;
    endDate: string;
    performance: number;
  }[];
  performance: {
    qualityScore: number;
    timeScore: number;
    costScore: number;
    safetyScore: number;
    overallScore: number;
  };
  financials: {
    totalPaid: number;
    pendingPayments: number;
    retentionMoney: number;
    advanceGiven: number;
  };
  history: {
    date: string;
    event: string;
    description: string;
    impact: 'Positive' | 'Negative' | 'Neutral';
  }[];
}

const mockContractors: Contractor[] = [
  {
    id: '1',
    name: 'China National Machinery Import & Export Corporation',
    type: 'General Contractor',
    registrationNumber: 'CMEC-BD-001',
    license: 'BSTI-2024-GC-001',
    status: 'Active',
    rating: 4.5,
    totalProjects: 15,
    completedProjects: 12,
    ongoingProjects: 3,
    totalContractValue: 15000000000,
    contact: {
      email: 'bd.office@cmec.com',
      phone: '+880-2-9876543',
      address: 'Gulshan-2, Dhaka, Bangladesh',
      website: 'www.cmec.com',
      contactPerson: 'Mr. Liu Wei',
      designation: 'Project Director'
    },
    capabilities: [
      'Coal Power Plant Construction',
      'Heavy Machinery Installation',
      'EPC Contracts',
      'Technology Transfer',
      'Project Management'
    ],
    certifications: [
      {
        name: 'ISO 9001:2015 Quality Management',
        issuedBy: 'ISO Certification Body',
        validUntil: '2025-08-15',
        status: 'Valid'
      },
      {
        name: 'OHSAS 18001 Safety Management',
        issuedBy: 'BSI Group',
        validUntil: '2024-12-31',
        status: 'Valid'
      },
      {
        name: 'Environmental Management ISO 14001',
        issuedBy: 'ISO Certification Body',
        validUntil: '2025-06-20',
        status: 'Valid'
      }
    ],
    projects: [
      {
        id: '1',
        name: 'Payra Coal Power Plant Unit 1',
        value: 8500000000,
        status: 'Completed',
        startDate: '2020-01-15',
        endDate: '2023-12-30',
        performance: 92
      },
      {
        id: '2',
        name: 'Payra Coal Power Plant Unit 2',
        value: 6500000000,
        status: 'Ongoing',
        startDate: '2023-01-15',
        endDate: '2025-06-30',
        performance: 88
      }
    ],
    performance: {
      qualityScore: 92,
      timeScore: 88,
      costScore: 85,
      safetyScore: 95,
      overallScore: 90
    },
    financials: {
      totalPaid: 12000000000,
      pendingPayments: 1500000000,
      retentionMoney: 850000000,
      advanceGiven: 2000000000
    },
    history: [
      {
        date: '2024-08-15',
        event: 'Performance Review',
        description: 'Quarterly performance review completed with excellent ratings',
        impact: 'Positive'
      },
      {
        date: '2024-07-20',
        event: 'Safety Incident',
        description: 'Minor safety incident reported and resolved',
        impact: 'Negative'
      },
      {
        date: '2024-06-10',
        event: 'Contract Amendment',
        description: 'Contract scope extended for additional equipment installation',
        impact: 'Neutral'
      }
    ]
  },
  {
    id: '2',
    name: 'Power Grid Company of Bangladesh Ltd.',
    type: 'Electrical',
    registrationNumber: 'PGCB-2024-001',
    license: 'BSTI-2024-EL-001',
    status: 'Active',
    rating: 4.2,
    totalProjects: 25,
    completedProjects: 20,
    ongoingProjects: 5,
    totalContractValue: 8500000000,
    contact: {
      email: 'info@pgcb.gov.bd',
      phone: '+880-2-9113825',
      address: 'WASA Bhaban, Motijheel, Dhaka',
      website: 'www.pgcb.gov.bd',
      contactPerson: 'Eng. Rashida Khatun',
      designation: 'Chief Engineer'
    },
    capabilities: [
      'Transmission Line Construction',
      'Substation Installation',
      'Grid Integration',
      'Electrical Testing',
      'Maintenance Services'
    ],
    certifications: [
      {
        name: 'Electrical Contractor License',
        issuedBy: 'Department of Electrical Inspection',
        validUntil: '2025-12-31',
        status: 'Valid'
      },
      {
        name: 'Grid Code Compliance',
        issuedBy: 'Bangladesh Energy Regulatory Commission',
        validUntil: '2024-10-15',
        status: 'Pending Renewal'
      }
    ],
    projects: [
      {
        id: '3',
        name: 'Dhaka-Cumilla 400kV Transmission',
        value: 850000000,
        status: 'Ongoing',
        startDate: '2023-06-01',
        endDate: '2024-12-15',
        performance: 85
      },
      {
        id: '4',
        name: 'Chittagong Grid Expansion',
        value: 1200000000,
        status: 'Completed',
        startDate: '2022-03-01',
        endDate: '2023-08-30',
        performance: 90
      }
    ],
    performance: {
      qualityScore: 88,
      timeScore: 82,
      costScore: 90,
      safetyScore: 92,
      overallScore: 88
    },
    financials: {
      totalPaid: 6500000000,
      pendingPayments: 850000000,
      retentionMoney: 425000000,
      advanceGiven: 1200000000
    },
    history: [
      {
        date: '2024-08-20',
        event: 'Project Milestone',
        description: 'Successfully completed major transmission line installation',
        impact: 'Positive'
      },
      {
        date: '2024-07-15',
        event: 'Certification Renewal',
        description: 'Grid Code Compliance certificate pending renewal',
        impact: 'Neutral'
      }
    ]
  },
  {
    id: '3',
    name: 'Rosatom State Corporation',
    type: 'Specialized',
    registrationNumber: 'ROSATOM-BD-001',
    license: 'BAEC-2024-NUC-001',
    status: 'Active',
    rating: 4.8,
    totalProjects: 3,
    completedProjects: 1,
    ongoingProjects: 2,
    totalContractValue: 25000000000,
    contact: {
      email: 'bangladesh@rosatom.ru',
      phone: '+880-2-8876543',
      address: 'Diplomatic Zone, Gulshan, Dhaka',
      website: 'www.rosatom.ru',
      contactPerson: 'Dr. Sergey Volkov',
      designation: 'Project Director'
    },
    capabilities: [
      'Nuclear Power Plant Construction',
      'Nuclear Technology Transfer',
      'Reactor Installation',
      'Nuclear Safety Systems',
      'Commissioning Services'
    ],
    certifications: [
      {
        name: 'Nuclear Facility Construction License',
        issuedBy: 'Bangladesh Atomic Energy Commission',
        validUntil: '2030-12-31',
        status: 'Valid'
      },
      {
        name: 'International Nuclear Safety Standards',
        issuedBy: 'International Atomic Energy Agency',
        validUntil: '2026-08-15',
        status: 'Valid'
      }
    ],
    projects: [
      {
        id: '5',
        name: 'Rooppur Nuclear Power Plant Unit 1',
        value: 12000000000,
        status: 'Ongoing',
        startDate: '2020-11-30',
        endDate: '2024-11-30',
        performance: 95
      },
      {
        id: '6',
        name: 'Rooppur Nuclear Power Plant Unit 2',
        value: 13000000000,
        status: 'Ongoing',
        startDate: '2021-07-01',
        endDate: '2025-07-01',
        performance: 93
      }
    ],
    performance: {
      qualityScore: 98,
      timeScore: 95,
      costScore: 92,
      safetyScore: 99,
      overallScore: 96
    },
    financials: {
      totalPaid: 18000000000,
      pendingPayments: 3500000000,
      retentionMoney: 2500000000,
      advanceGiven: 5000000000
    },
    history: [
      {
        date: '2024-08-25',
        event: 'Safety Inspection',
        description: 'International safety inspection completed with excellent results',
        impact: 'Positive'
      },
      {
        date: '2024-07-10',
        event: 'Technology Transfer',
        description: 'Successful knowledge transfer to Bangladeshi engineers',
        impact: 'Positive'
      }
    ]
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'Active': return 'bg-green-500';
    case 'Under Review': return 'bg-yellow-500';
    case 'Suspended': return 'bg-orange-500';
    case 'Blacklisted': return 'bg-red-500';
    case 'Prequalified': return 'bg-blue-500';
    default: return 'bg-gray-500';
  }
};

const getStatusBadgeVariant = (status: string) => {
  switch (status) {
    case 'Active': return 'default';
    case 'Under Review': return 'secondary';
    case 'Suspended': return 'destructive';
    case 'Blacklisted': return 'destructive';
    case 'Prequalified': return 'outline';
    default: return 'secondary';
  }
};

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-BD', {
    style: 'currency',
    currency: 'BDT',
    notation: 'compact',
    maximumFractionDigits: 1
  }).format(amount);
};

const getRatingStars = (rating: number) => {
  const stars = [];
  for (let i = 1; i <= 5; i++) {
    stars.push(
      <Star
        key={i}
        className={`w-4 h-4 ${i <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
      />
    );
  }
  return stars;
};

export default function ContractorManagement() {
  const [contractors, setContractors] = useState<Contractor[]>(mockContractors);
  const [selectedContractor, setSelectedContractor] = useState<Contractor | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');

  const filteredContractors = contractors.filter(contractor => {
    const matchesSearch = contractor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         contractor.registrationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         contractor.contact.contactPerson.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || contractor.status === filterStatus;
    const matchesType = filterType === 'all' || contractor.type === filterType;
    return matchesSearch && matchesStatus && matchesType;
  });

  const totalContractors = contractors.length;
  const activeContractors = contractors.filter(c => c.status === 'Active').length;
  const totalContractValue = contractors.reduce((sum, contractor) => sum + contractor.totalContractValue, 0);
  const avgRating = contractors.reduce((sum, contractor) => sum + contractor.rating, 0) / contractors.length;
  const avgPerformance = contractors.reduce((sum, contractor) => sum + contractor.performance.overallScore, 0) / contractors.length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
              Contractor Management
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Manage contractor relationships and performance tracking
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <FileText className="w-4 h-4 mr-2" />
              Generate Report
            </Button>
            <Button className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Contractor
            </Button>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Contractors</p>
                  <p className="text-2xl font-bold text-blue-600">{totalContractors}</p>
                </div>
                <Users className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Active</p>
                  <p className="text-2xl font-bold text-green-600">{activeContractors}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Value</p>
                  <p className="text-2xl font-bold text-purple-600">{formatCurrency(totalContractValue)}</p>
                </div>
                <DollarSign className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Avg Rating</p>
                  <p className="text-2xl font-bold text-yellow-600">{avgRating.toFixed(1)}</p>
                </div>
                <Star className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Avg Performance</p>
                  <p className="text-2xl font-bold text-orange-600">{avgPerformance.toFixed(1)}%</p>
                </div>
                <TrendingUp className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Search contractors..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Under Review">Under Review</SelectItem>
                  <SelectItem value="Suspended">Suspended</SelectItem>
                  <SelectItem value="Blacklisted">Blacklisted</SelectItem>
                  <SelectItem value="Prequalified">Prequalified</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="General Contractor">General Contractor</SelectItem>
                  <SelectItem value="Electrical">Electrical</SelectItem>
                  <SelectItem value="Mechanical">Mechanical</SelectItem>
                  <SelectItem value="Civil">Civil</SelectItem>
                  <SelectItem value="Specialized">Specialized</SelectItem>
                  <SelectItem value="Consultant">Consultant</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Contractors List */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredContractors.map((contractor, index) => (
            <motion.div
              key={contractor.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card 
                className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedContractor(contractor)}
              >
                <CardHeader className="pb-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-1">{contractor.name}</CardTitle>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{contractor.registrationNumber}</p>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline">{contractor.type}</Badge>
                        <Badge variant={getStatusBadgeVariant(contractor.status) as any}>{contractor.status}</Badge>
                      </div>
                      <div className="flex items-center gap-1">
                        {getRatingStars(contractor.rating)}
                        <span className="text-sm text-gray-600 dark:text-gray-400 ml-2">
                          ({contractor.rating}/5)
                        </span>
                      </div>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${getStatusColor(contractor.status)}`}></div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center gap-1">
                      <Building2 className="w-4 h-4" />
                      {contractor.totalProjects} projects ({contractor.ongoingProjects} ongoing)
                    </div>
                    <div className="flex items-center gap-1">
                      <Phone className="w-4 h-4" />
                      {contractor.contact.contactPerson}
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Overall Performance</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {contractor.performance.overallScore}%
                      </span>
                    </div>
                    <Progress value={contractor.performance.overallScore} className="h-2" />
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600 dark:text-gray-400">Contract Value</p>
                      <p className="font-semibold">{formatCurrency(contractor.totalContractValue)}</p>
                    </div>
                    <div>
                      <p className="text-gray-600 dark:text-gray-400">Completed</p>
                      <p className="font-semibold">{contractor.completedProjects}/{contractor.totalProjects}</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-gray-200 dark:border-gray-700">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {contractor.license}
                    </span>
                    <div className="flex items-center gap-1">
                      <Award className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-600">
                        {contractor.certifications.filter(c => c.status === 'Valid').length} Certs
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Contractor Details Modal */}
        {selectedContractor && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <Card className="w-full max-w-6xl max-h-[90vh] overflow-y-auto backdrop-blur-sm bg-white/95 dark:bg-gray-900/95">
              <CardHeader className="flex flex-row items-start justify-between">
                <div>
                  <CardTitle className="text-2xl">{selectedContractor.name}</CardTitle>
                  <CardDescription className="mt-2 flex items-center gap-4">
                    <span>{selectedContractor.type}</span>
                    <div className="flex items-center gap-1">
                      {getRatingStars(selectedContractor.rating)}
                      <span className="ml-2">({selectedContractor.rating}/5)</span>
                    </div>
                  </CardDescription>
                </div>
                <Button 
                  variant="ghost" 
                  onClick={() => setSelectedContractor(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="overview" className="w-full">
                  <TabsList className="grid w-full grid-cols-6">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="performance">Performance</TabsTrigger>
                    <TabsTrigger value="projects">Projects</TabsTrigger>
                    <TabsTrigger value="financials">Financials</TabsTrigger>
                    <TabsTrigger value="certifications">Certifications</TabsTrigger>
                    <TabsTrigger value="history">History</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="overview" className="space-y-6 mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Contact Information</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div className="flex items-center gap-3">
                            <Mail className="w-4 h-4 text-gray-500" />
                            <span>{selectedContractor.contact.email}</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <Phone className="w-4 h-4 text-gray-500" />
                            <span>{selectedContractor.contact.phone}</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <MapPin className="w-4 h-4 text-gray-500" />
                            <span>{selectedContractor.contact.address}</span>
                          </div>
                          <div className="pt-2 border-t">
                            <p className="font-medium">{selectedContractor.contact.contactPerson}</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{selectedContractor.contact.designation}</p>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Registration Details</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Registration:</span>
                            <span className="font-medium">{selectedContractor.registrationNumber}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">License:</span>
                            <span className="font-medium">{selectedContractor.license}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Status:</span>
                            <Badge variant={getStatusBadgeVariant(selectedContractor.status) as any}>
                              {selectedContractor.status}
                            </Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600 dark:text-gray-400">Type:</span>
                            <span className="font-medium">{selectedContractor.type}</span>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Capabilities</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex flex-wrap gap-2">
                          {selectedContractor.capabilities.map((capability, index) => (
                            <Badge key={index} variant="secondary">{capability}</Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                  
                  <TabsContent value="performance" className="space-y-6 mt-6">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                      <Card>
                        <CardContent className="p-4 text-center">
                          <CheckCircle className="w-8 h-8 mx-auto mb-2 text-green-600" />
                          <p className="text-sm text-gray-600 dark:text-gray-400">Quality Score</p>
                          <p className="text-2xl font-bold text-green-600">{selectedContractor.performance.qualityScore}%</p>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardContent className="p-4 text-center">
                          <Clock className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                          <p className="text-sm text-gray-600 dark:text-gray-400">Time Score</p>
                          <p className="text-2xl font-bold text-blue-600">{selectedContractor.performance.timeScore}%</p>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardContent className="p-4 text-center">
                          <DollarSign className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                          <p className="text-sm text-gray-600 dark:text-gray-400">Cost Score</p>
                          <p className="text-2xl font-bold text-purple-600">{selectedContractor.performance.costScore}%</p>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardContent className="p-4 text-center">
                          <Shield className="w-8 h-8 mx-auto mb-2 text-orange-600" />
                          <p className="text-sm text-gray-600 dark:text-gray-400">Safety Score</p>
                          <p className="text-2xl font-bold text-orange-600">{selectedContractor.performance.safetyScore}%</p>
                        </CardContent>
                      </Card>
                    </div>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Overall Performance: {selectedContractor.performance.overallScore}%</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <Progress value={selectedContractor.performance.overallScore} className="h-4" />
                      </CardContent>
                    </Card>
                  </TabsContent>
                  
                  <TabsContent value="projects" className="space-y-4 mt-6">
                    {selectedContractor.projects.map((project) => (
                      <Card key={project.id}>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <p className="font-medium">{project.name}</p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {new Date(project.startDate).toLocaleDateString()} - {new Date(project.endDate).toLocaleDateString()}
                              </p>
                            </div>
                            <div className="text-right">
                              <Badge variant={project.status === 'Completed' ? 'default' : project.status === 'Ongoing' ? 'secondary' : 'destructive'}>
                                {project.status}
                              </Badge>
                              <p className="text-sm font-medium mt-1">{formatCurrency(project.value)}</p>
                            </div>
                          </div>
                          <div className="mt-3">
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-sm">Performance</span>
                              <span className="text-sm">{project.performance}%</span>
                            </div>
                            <Progress value={project.performance} className="h-2" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="financials" className="space-y-4 mt-6">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                      <Card>
                        <CardContent className="p-4 text-center">
                          <CheckCircle className="w-8 h-8 mx-auto mb-2 text-green-600" />
                          <p className="text-sm text-gray-600 dark:text-gray-400">Total Paid</p>
                          <p className="text-lg font-bold text-green-600">{formatCurrency(selectedContractor.financials.totalPaid)}</p>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardContent className="p-4 text-center">
                          <Clock className="w-8 h-8 mx-auto mb-2 text-yellow-600" />
                          <p className="text-sm text-gray-600 dark:text-gray-400">Pending</p>
                          <p className="text-lg font-bold text-yellow-600">{formatCurrency(selectedContractor.financials.pendingPayments)}</p>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardContent className="p-4 text-center">
                          <Shield className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                          <p className="text-sm text-gray-600 dark:text-gray-400">Retention</p>
                          <p className="text-lg font-bold text-blue-600">{formatCurrency(selectedContractor.financials.retentionMoney)}</p>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardContent className="p-4 text-center">
                          <TrendingUp className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                          <p className="text-sm text-gray-600 dark:text-gray-400">Advance</p>
                          <p className="text-lg font-bold text-purple-600">{formatCurrency(selectedContractor.financials.advanceGiven)}</p>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="certifications" className="space-y-4 mt-6">
                    {selectedContractor.certifications.map((cert, index) => (
                      <Card key={index}>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-medium">{cert.name}</p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">Issued by: {cert.issuedBy}</p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">Valid until: {new Date(cert.validUntil).toLocaleDateString()}</p>
                            </div>
                            <Badge variant={cert.status === 'Valid' ? 'default' : cert.status === 'Expired' ? 'destructive' : 'secondary'}>
                              {cert.status}
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="history" className="space-y-4 mt-6">
                    {selectedContractor.history.map((event, index) => (
                      <Card key={index}>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <p className="font-medium">{event.event}</p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">{event.description}</p>
                            </div>
                            <div className="text-right">
                              <Badge variant={event.impact === 'Positive' ? 'default' : event.impact === 'Negative' ? 'destructive' : 'secondary'}>
                                {event.impact}
                              </Badge>
                              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{new Date(event.date).toLocaleDateString()}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}