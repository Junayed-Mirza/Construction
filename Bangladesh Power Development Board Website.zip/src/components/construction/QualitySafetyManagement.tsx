import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Shield, CheckCircle, AlertTriangle, XCircle, Eye, FileText,
  HardHat, Heart, Users, Calendar, Clock, MapPin, Camera,
  TrendingUp, TrendingDown, BarChart3, Target, Plus, Search, Filter, X, Badge
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

interface SafetyIncident {
  id: string;
  projectId: string;
  projectName: string;
  type: 'Near Miss' | 'Minor Injury' | 'Major Injury' | 'Property Damage' | 'Environmental';
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  description: string;
  location: string;
  date: string;
  time: string;
  reportedBy: string;
  involvedPersons: string[];
  immediateAction: string;
  rootCause: string;
  correctiveAction: string;
  status: 'Reported' | 'Under Investigation' | 'Action Taken' | 'Closed';
  daysLostTime: number;
  cost: number;
}

interface QualityInspection {
  id: string;
  projectId: string;
  projectName: string;
  type: 'Material' | 'Workmanship' | 'Safety' | 'Environmental' | 'Compliance';
  category: 'Foundation' | 'Structure' | 'Equipment' | 'Electrical' | 'Mechanical' | 'Civil';
  inspectorName: string;
  inspectionDate: string;
  location: string;
  checklist: {
    id: string;
    item: string;
    status: 'Pass' | 'Fail' | 'N/A';
    notes: string;
  }[];
  overallRating: 'Excellent' | 'Good' | 'Satisfactory' | 'Needs Improvement' | 'Unsatisfactory';
  score: number;
  deficiencies: {
    id: string;
    description: string;
    severity: 'Low' | 'Medium' | 'High';
    correctionRequired: string;
    dueDate: string;
    status: 'Open' | 'In Progress' | 'Resolved';
  }[];
  photos: string[];
  nextInspection: string;
}

interface SafetyMetrics {
  totalHours: number;
  lostTimeIncidents: number;
  recordableCases: number;
  nearMisses: number;
  safetyTrainingHours: number;
  ltir: number; // Lost Time Incident Rate
  trir: number; // Total Recordable Incident Rate
  safetyScore: number;
}

interface Certification {
  id: string;
  name: string;
  type: 'Quality' | 'Safety' | 'Environmental' | 'Regulatory';
  issuedBy: string;
  issueDate: string;
  expiryDate: string;
  status: 'Valid' | 'Expired' | 'Pending Renewal';
  projectId: string;
  projectName: string;
}

const mockIncidents: SafetyIncident[] = [
  {
    id: '1',
    projectId: '1',
    projectName: 'Payra Coal Power Plant Unit 2',
    type: 'Near Miss',
    severity: 'Medium',
    description: 'Worker almost struck by falling debris during crane operation',
    location: 'Turbine Hall - Section A',
    date: '2024-08-20',
    time: '14:30',
    reportedBy: 'Safety Officer - Ahmed Rahman',
    involvedPersons: ['Mohammad Hasan - Crane Operator', 'Karim Ahmed - Ground Worker'],
    immediateAction: 'Work stopped, area secured, safety briefing conducted',
    rootCause: 'Inadequate communication during crane operations',
    correctiveAction: 'Enhanced radio communication protocol implemented',
    status: 'Closed',
    daysLostTime: 0,
    cost: 0
  },
  {
    id: '2',
    projectId: '2',
    projectName: 'Dhaka-Cumilla 400kV Transmission',
    type: 'Minor Injury',
    severity: 'Low',
    description: 'Worker sustained minor cut on hand while handling cable',
    location: 'Tower Site 45',
    date: '2024-08-18',
    time: '10:15',
    reportedBy: 'Site Supervisor - Rafiq Islam',
    involvedPersons: ['Shahid Khan - Electrician'],
    immediateAction: 'First aid provided, worker sent to medical facility',
    rootCause: 'Worker not wearing proper cut-resistant gloves',
    correctiveAction: 'Mandatory PPE check before work starts',
    status: 'Action Taken',
    daysLostTime: 0,
    cost: 5000
  },
  {
    id: '3',
    projectId: '3',
    projectName: 'Rooppur Nuclear Infrastructure',
    type: 'Environmental',
    severity: 'High',
    description: 'Minor chemical spill during equipment installation',
    location: 'Reactor Building - Level 2',
    date: '2024-08-15',
    time: '16:45',
    reportedBy: 'Environmental Officer - Dr. Fatima Khan',
    involvedPersons: ['Installation Team - 4 members'],
    immediateAction: 'Area evacuated, spill contained and cleaned',
    rootCause: 'Equipment malfunction during chemical transfer',
    correctiveAction: 'Equipment inspection schedule enhanced',
    status: 'Under Investigation',
    daysLostTime: 0,
    cost: 25000
  }
];

const mockInspections: QualityInspection[] = [
  {
    id: '1',
    projectId: '1',
    projectName: 'Payra Coal Power Plant Unit 2',
    type: 'Safety',
    category: 'Structure',
    inspectorName: 'Eng. Dr. Rahman Ahmed',
    inspectionDate: '2024-08-25',
    location: 'Boiler Assembly Area',
    checklist: [
      { id: '1', item: 'Safety barriers properly installed', status: 'Pass', notes: 'All barriers in place and secure' },
      { id: '2', item: 'Workers wearing proper PPE', status: 'Pass', notes: 'All workers compliant' },
      { id: '3', item: 'Fire extinguishers accessible', status: 'Pass', notes: 'Fire safety equipment properly positioned' },
      { id: '4', item: 'Emergency exits clearly marked', status: 'Fail', notes: 'Exit sign damaged in Section B' },
      { id: '5', item: 'First aid station operational', status: 'Pass', notes: 'Fully stocked and accessible' }
    ],
    overallRating: 'Good',
    score: 85,
    deficiencies: [
      {
        id: '1',
        description: 'Replace damaged emergency exit sign in Section B',
        severity: 'Medium',
        correctionRequired: 'Install new illuminated exit sign',
        dueDate: '2024-09-01',
        status: 'In Progress'
      }
    ],
    photos: ['photo1.jpg', 'photo2.jpg'],
    nextInspection: '2024-09-25'
  },
  {
    id: '2',
    projectId: '2',
    projectName: 'Dhaka-Cumilla 400kV Transmission',
    type: 'Quality',
    category: 'Electrical',
    inspectorName: 'Eng. Rashida Khatun',
    inspectionDate: '2024-08-22',
    location: 'Substation Construction Site',
    checklist: [
      { id: '1', item: 'Cable insulation integrity', status: 'Pass', notes: 'All insulation tests passed' },
      { id: '2', item: 'Grounding system installation', status: 'Pass', notes: 'Proper grounding verified' },
      { id: '3', item: 'Equipment installation alignment', status: 'Pass', notes: 'Within specified tolerances' },
      { id: '4', item: 'Safety interlocks functional', status: 'Pass', notes: 'All interlocks tested and operational' },
      { id: '5', item: 'Documentation completeness', status: 'Pass', notes: 'All required documents available' }
    ],
    overallRating: 'Excellent',
    score: 95,
    deficiencies: [],
    photos: ['elec1.jpg', 'elec2.jpg', 'elec3.jpg'],
    nextInspection: '2024-09-22'
  }
];

const mockSafetyMetrics: SafetyMetrics = {
  totalHours: 1250000,
  lostTimeIncidents: 2,
  recordableCases: 5,
  nearMisses: 15,
  safetyTrainingHours: 8500,
  ltir: 0.16,
  trir: 0.40,
  safetyScore: 92
};

const mockCertifications: Certification[] = [
  {
    id: '1',
    name: 'ISO 45001 Occupational Health & Safety',
    type: 'Safety',
    issuedBy: 'British Standards Institution',
    issueDate: '2023-06-15',
    expiryDate: '2026-06-15',
    status: 'Valid',
    projectId: '1',
    projectName: 'Payra Coal Power Plant Unit 2'
  },
  {
    id: '2',
    name: 'ISO 14001 Environmental Management',
    type: 'Environmental',
    issuedBy: 'SGS Bangladesh Limited',
    issueDate: '2023-08-20',
    expiryDate: '2026-08-20',
    status: 'Valid',
    projectId: '3',
    projectName: 'Rooppur Nuclear Infrastructure'
  },
  {
    id: '3',
    name: 'Nuclear Safety License',
    type: 'Regulatory',
    issuedBy: 'Bangladesh Atomic Energy Commission',
    issueDate: '2024-01-10',
    expiryDate: '2024-12-31',
    status: 'Pending Renewal',
    projectId: '3',
    projectName: 'Rooppur Nuclear Infrastructure'
  }
];

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case 'Low': return 'bg-green-500';
    case 'Medium': return 'bg-yellow-500';
    case 'High': return 'bg-orange-500';
    case 'Critical': return 'bg-red-500';
    default: return 'bg-gray-500';
  }
};

const getSeverityBadgeVariant = (severity: string) => {
  switch (severity) {
    case 'Low': return 'default';
    case 'Medium': return 'secondary';
    case 'High': return 'destructive';
    case 'Critical': return 'destructive';
    default: return 'secondary';
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case 'Pass': case 'Closed': case 'Resolved': case 'Valid': return 'bg-green-500';
    case 'Fail': case 'Open': case 'Expired': return 'bg-red-500';
    case 'In Progress': case 'Under Investigation': case 'Pending Renewal': return 'bg-yellow-500';
    case 'N/A': return 'bg-gray-500';
    default: return 'bg-gray-500';
  }
};

const getRatingScore = (rating: string) => {
  switch (rating) {
    case 'Excellent': return 90;
    case 'Good': return 80;
    case 'Satisfactory': return 70;
    case 'Needs Improvement': return 60;
    case 'Unsatisfactory': return 40;
    default: return 0;
  }
};

export default function QualitySafetyManagement() {
  const [incidents, setIncidents] = useState<SafetyIncident[]>(mockIncidents);
  const [inspections, setInspections] = useState<QualityInspection[]>(mockInspections);
  const [certifications, setCertifications] = useState<Certification[]>(mockCertifications);
  const [selectedIncident, setSelectedIncident] = useState<SafetyIncident | null>(null);
  const [selectedInspection, setSelectedInspection] = useState<QualityInspection | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  const filteredIncidents = incidents.filter(incident => {
    const matchesSearch = incident.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         incident.projectName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         incident.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || incident.type === filterType;
    const matchesStatus = filterStatus === 'all' || incident.status === filterStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  const filteredInspections = inspections.filter(inspection => {
    const matchesSearch = inspection.projectName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         inspection.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         inspection.inspectorName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || inspection.type === filterType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
              Quality Control & Safety Management
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Comprehensive safety monitoring and quality assurance
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <FileText className="w-4 h-4 mr-2" />
              Safety Report
            </Button>
            <Button className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700">
              <Plus className="w-4 h-4 mr-2" />
              New Inspection
            </Button>
          </div>
        </div>

        {/* Safety Metrics Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Safety Score</p>
                  <p className="text-2xl font-bold text-green-600">{mockSafetyMetrics.safetyScore}%</p>
                </div>
                <Shield className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">LTIR</p>
                  <p className="text-2xl font-bold text-blue-600">{mockSafetyMetrics.ltir}</p>
                </div>
                <TrendingDown className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Near Misses</p>
                  <p className="text-2xl font-bold text-yellow-600">{mockSafetyMetrics.nearMisses}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Training Hours</p>
                  <p className="text-2xl font-bold text-purple-600">{mockSafetyMetrics.safetyTrainingHours.toLocaleString()}</p>
                </div>
                <Users className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="safety" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="safety">Safety Incidents</TabsTrigger>
            <TabsTrigger value="quality">Quality Inspections</TabsTrigger>
            <TabsTrigger value="certifications">Certifications</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="safety" className="space-y-6 mt-6">
            {/* Filters */}
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Search incidents..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-full md:w-48">
                      <SelectValue placeholder="Filter by type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="Near Miss">Near Miss</SelectItem>
                      <SelectItem value="Minor Injury">Minor Injury</SelectItem>
                      <SelectItem value="Major Injury">Major Injury</SelectItem>
                      <SelectItem value="Property Damage">Property Damage</SelectItem>
                      <SelectItem value="Environmental">Environmental</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-full md:w-48">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="Reported">Reported</SelectItem>
                      <SelectItem value="Under Investigation">Under Investigation</SelectItem>
                      <SelectItem value="Action Taken">Action Taken</SelectItem>
                      <SelectItem value="Closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Incidents List */}
            <div className="space-y-4">
              {filteredIncidents.map((incident, index) => (
                <motion.div
                  key={incident.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card 
                    className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300 cursor-pointer"
                    onClick={() => setSelectedIncident(incident)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <Badge variant="outline">{incident.type}</Badge>
                            <Badge variant={getSeverityBadgeVariant(incident.severity) as any}>{incident.severity}</Badge>
                            <div className={`w-3 h-3 rounded-full ${getSeverityColor(incident.severity)}`}></div>
                          </div>
                          <h3 className="font-semibold text-lg mb-1">{incident.description}</h3>
                          <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400 mb-2">
                            <div className="flex items-center gap-1">
                              <MapPin className="w-4 h-4" />
                              {incident.location}
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {new Date(incident.date).toLocaleDateString()}
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {incident.time}
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{incident.projectName}</p>
                        </div>
                        <div className="text-right">
                          <Badge variant={incident.status === 'Closed' ? 'default' : 'secondary'}>
                            {incident.status}
                          </Badge>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                            {incident.reportedBy}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="quality" className="space-y-6 mt-6">
            {/* Quality Inspections */}
            <div className="space-y-4">
              {filteredInspections.map((inspection, index) => (
                <motion.div
                  key={inspection.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card 
                    className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300 cursor-pointer"
                    onClick={() => setSelectedInspection(inspection)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <Badge variant="outline">{inspection.type}</Badge>
                            <Badge variant="secondary">{inspection.category}</Badge>
                            <Badge variant={inspection.overallRating === 'Excellent' ? 'default' : 'secondary'}>
                              {inspection.overallRating}
                            </Badge>
                          </div>
                          <h3 className="font-semibold text-lg mb-1">{inspection.projectName}</h3>
                          <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400 mb-2">
                            <div className="flex items-center gap-1">
                              <MapPin className="w-4 h-4" />
                              {inspection.location}
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {new Date(inspection.inspectionDate).toLocaleDateString()}
                            </div>
                            <div className="flex items-center gap-1">
                              <Eye className="w-4 h-4" />
                              {inspection.inspectorName}
                            </div>
                          </div>
                          <div className="mt-3">
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-sm">Quality Score</span>
                              <span className="text-sm">{inspection.score}%</span>
                            </div>
                            <Progress value={inspection.score} className="h-2" />
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-green-600">{inspection.score}%</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {inspection.deficiencies.length} deficiencies
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="certifications" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {mockCertifications.map((cert, index) => (
                <motion.div
                  key={cert.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{cert.name}</CardTitle>
                          <CardDescription>{cert.projectName}</CardDescription>
                        </div>
                        <Badge variant={cert.status === 'Valid' ? 'default' : cert.status === 'Expired' ? 'destructive' : 'secondary'}>
                          {cert.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Type:</span>
                        <Badge variant="outline">{cert.type}</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Issued By:</span>
                        <span className="font-medium">{cert.issuedBy}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Issue Date:</span>
                        <span className="font-medium">{new Date(cert.issueDate).toLocaleDateString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Expiry Date:</span>
                        <span className="font-medium">{new Date(cert.expiryDate).toLocaleDateString()}</span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Safety Trend Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-48 flex items-center justify-center text-gray-500">
                    <TrendingUp className="w-12 h-12 mr-4" />
                    <span>Safety trend charts would be displayed here</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Quality Score Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-48 flex items-center justify-center text-gray-500">
                    <BarChart3 className="w-12 h-12 mr-4" />
                    <span>Quality distribution charts would be displayed here</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Incident Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {['Near Miss', 'Minor Injury', 'Major Injury', 'Property Damage', 'Environmental'].map((type, index) => {
                      const count = incidents.filter(i => i.type === type).length;
                      const percentage = (count / incidents.length) * 100;
                      return (
                        <div key={type} className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span>{type}</span>
                            <span>{count} ({percentage.toFixed(1)}%)</span>
                          </div>
                          <Progress value={percentage} className="h-2" />
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-white/20 dark:border-gray-700/30">
                <CardHeader>
                  <CardTitle className="text-lg">Compliance Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <CheckCircle className="w-8 h-8 mx-auto mb-2 text-green-600" />
                      <p className="text-sm text-gray-600 dark:text-gray-400">Compliant</p>
                      <p className="text-xl font-bold text-green-600">
                        {mockCertifications.filter(c => c.status === 'Valid').length}
                      </p>
                    </div>
                    <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
                      <AlertTriangle className="w-8 h-8 mx-auto mb-2 text-red-600" />
                      <p className="text-sm text-gray-600 dark:text-gray-400">Non-Compliant</p>
                      <p className="text-xl font-bold text-red-600">
                        {mockCertifications.filter(c => c.status !== 'Valid').length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Incident Details Modal */}
        {selectedIncident && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto backdrop-blur-sm bg-white/95 dark:bg-gray-900/95">
              <CardHeader className="flex flex-row items-start justify-between">
                <div>
                  <CardTitle className="text-2xl">Safety Incident Details</CardTitle>
                  <CardDescription className="mt-2">{selectedIncident.description}</CardDescription>
                </div>
                <Button 
                  variant="ghost" 
                  onClick={() => setSelectedIncident(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                    <AlertTriangle className="w-6 h-6 mx-auto mb-2 text-yellow-600" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">Type</p>
                    <p className="font-semibold">{selectedIncident.type}</p>
                  </div>
                  <div className="text-center p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                    <Target className="w-6 h-6 mx-auto mb-2 text-red-600" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">Severity</p>
                    <p className="font-semibold">{selectedIncident.severity}</p>
                  </div>
                  <div className="text-center p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                    <Clock className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">Lost Time</p>
                    <p className="font-semibold">{selectedIncident.daysLostTime} days</p>
                  </div>
                  <div className="text-center p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                    <CheckCircle className="w-6 h-6 mx-auto mb-2 text-green-600" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">Status</p>
                    <p className="font-semibold">{selectedIncident.status}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Incident Information</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Project:</span>
                          <span className="font-medium">{selectedIncident.projectName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Location:</span>
                          <span className="font-medium">{selectedIncident.location}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Date:</span>
                          <span className="font-medium">{new Date(selectedIncident.date).toLocaleDateString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Time:</span>
                          <span className="font-medium">{selectedIncident.time}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Reported By:</span>
                          <span className="font-medium">{selectedIncident.reportedBy}</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Involved Persons</h4>
                      <div className="space-y-1">
                        {selectedIncident.involvedPersons.map((person, index) => (
                          <p key={index} className="text-sm text-gray-600 dark:text-gray-400">• {person}</p>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Immediate Action</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{selectedIncident.immediateAction}</p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Root Cause</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{selectedIncident.rootCause}</p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Corrective Action</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{selectedIncident.correctiveAction}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Inspection Details Modal */}
        {selectedInspection && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <Card className="w-full max-w-5xl max-h-[90vh] overflow-y-auto backdrop-blur-sm bg-white/95 dark:bg-gray-900/95">
              <CardHeader className="flex flex-row items-start justify-between">
                <div>
                  <CardTitle className="text-2xl">Quality Inspection Details</CardTitle>
                  <CardDescription className="mt-2">{selectedInspection.projectName} - {selectedInspection.location}</CardDescription>
                </div>
                <Button 
                  variant="ghost" 
                  onClick={() => setSelectedInspection(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <Eye className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">Inspector</p>
                    <p className="font-semibold">{selectedInspection.inspectorName}</p>
                  </div>
                  <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <Target className="w-6 h-6 mx-auto mb-2 text-green-600" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">Score</p>
                    <p className="font-semibold">{selectedInspection.score}%</p>
                  </div>
                  <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <Badge className="w-6 h-6 mx-auto mb-2 text-purple-600" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">Rating</p>
                    <p className="font-semibold">{selectedInspection.overallRating}</p>
                  </div>
                  <div className="text-center p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                    <AlertTriangle className="w-6 h-6 mx-auto mb-2 text-orange-600" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">Deficiencies</p>
                    <p className="font-semibold">{selectedInspection.deficiencies.length}</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-4">Inspection Checklist</h4>
                  <div className="space-y-2">
                    {selectedInspection.checklist.map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <p className="font-medium">{item.item}</p>
                          {item.notes && (
                            <p className="text-sm text-gray-600 dark:text-gray-400">{item.notes}</p>
                          )}
                        </div>
                        <Badge variant={item.status === 'Pass' ? 'default' : item.status === 'Fail' ? 'destructive' : 'secondary'}>
                          {item.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>

                {selectedInspection.deficiencies.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-4">Deficiencies</h4>
                    <div className="space-y-3">
                      {selectedInspection.deficiencies.map((deficiency) => (
                        <div key={deficiency.id} className="p-4 border rounded-lg">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <p className="font-medium">{deficiency.description}</p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">{deficiency.correctionRequired}</p>
                            </div>
                            <div className="text-right">
                              <Badge variant={deficiency.severity === 'High' ? 'destructive' : 'secondary'}>
                                {deficiency.severity}
                              </Badge>
                              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                                Due: {new Date(deficiency.dueDate).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                          <Badge variant={deficiency.status === 'Resolved' ? 'default' : 'secondary'}>
                            {deficiency.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400">
                  <span>Inspection Date: {new Date(selectedInspection.inspectionDate).toLocaleDateString()}</span>
                  <span>Next Inspection: {new Date(selectedInspection.nextInspection).toLocaleDateString()}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}