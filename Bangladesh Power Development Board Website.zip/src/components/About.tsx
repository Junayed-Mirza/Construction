import React from 'react';
import { motion } from 'motion/react';
import { 
  History, Target, Eye, Users, Award, Globe, 
  Lightbulb, Shield, Heart, TrendingUp, Zap,
  Calendar, MapPin, Building
} from 'lucide-react';
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";

export default function About() {
  const glassStyle = {
    background: 'rgba(255, 255, 255, 0.1)',
    backdropFilter: 'blur(20px)',
    border: '1px solid rgba(255, 255, 255, 0.2)',
  };

  const milestones = [
    { year: '1972', event: 'BPDB Establishment', description: 'Founded as the national power utility' },
    { year: '1982', event: 'Rural Electrification', description: 'Launched nationwide rural electrification program' },
    { year: '1995', event: 'Private Sector Entry', description: 'Opened power sector to private investment' },
    { year: '2009', event: 'Vision 2021', description: 'Launched ambitious power development plan' },
    { year: '2017', event: 'Rooppur Nuclear', description: 'Started construction of first nuclear plant' },
    { year: '2023', event: 'Digital Transformation', description: 'Implemented smart grid technologies' }
  ];

  const values = [
    {
      icon: Shield,
      title: 'Reliability',
      description: 'Ensuring consistent and dependable power supply',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Heart,
      title: 'Service',
      description: 'Committed to serving our communities with excellence',
      color: 'from-red-500 to-pink-500'
    },
    {
      icon: Lightbulb,
      title: 'Innovation',
      description: 'Embracing new technologies for sustainable energy',
      color: 'from-yellow-500 to-orange-500'
    },
    {
      icon: Globe,
      title: 'Sustainability',
      description: 'Building an environmentally responsible energy future',
      color: 'from-green-500 to-emerald-500'
    }
  ];

  const leadership = [
    {
      name: 'Eng. Md. Habibur Rahman',
      position: 'Chairman',
      department: 'Board of Directors',
      experience: '25+ years',
      image: 'chairman'
    },
    {
      name: 'Dr. Md. Moinul Islam',
      position: 'Managing Director',
      department: 'Executive Management',
      experience: '22+ years',
      image: 'md'
    },
    {
      name: 'Eng. Shamima Nasrin',
      position: 'Director (Generation)',
      department: 'Power Generation',
      experience: '20+ years',
      image: 'director-gen'
    },
    {
      name: 'Md. Rafiqul Islam',
      position: 'Director (Distribution)',
      department: 'Power Distribution',
      experience: '18+ years',
      image: 'director-dist'
    }
  ];

  const achievements = [
    { metric: '98.5%', label: 'Population Coverage', icon: Users },
    { metric: '50+ Years', label: 'Service Excellence', icon: Award },
    { metric: '35M+', label: 'Customers Served', icon: Globe },
    { metric: '99.2%', label: 'Grid Reliability', icon: Zap }
  ];

  return (
    <section className="pt-32 pb-16 lg:pb-24 px-4 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <Badge className="mb-4 bg-blue-500/20 text-blue-600 dark:text-blue-400 border border-blue-500/30">
            About BPDB
          </Badge>
          <h1 className="text-4xl lg:text-6xl font-bold mb-6">
            Powering Bangladesh
            <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent"> Since 1972</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            Bangladesh Power Development Board is the pioneering force behind the nation's power sector, 
            dedicated to providing reliable, sustainable, and affordable electricity to all corners of Bangladesh.
          </p>
        </motion.div>

        {/* Mission & Vision */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid lg:grid-cols-2 gap-8 mb-16"
        >
          <Card className="p-8 border-0 shadow-xl relative overflow-hidden" style={glassStyle}>
            <motion.div
              className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10"
              animate={{ opacity: [0.1, 0.2, 0.1] }}
              transition={{ duration: 3, repeat: Infinity }}
            />
            <div className="relative z-10">
              <motion.div
                className="inline-flex p-4 rounded-xl bg-gradient-to-br from-blue-500 to-purple-500 text-white mb-6"
                animate={{ rotate: [0, 5, -5, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
              >
                <Target className="w-8 h-8" />
              </motion.div>
              <h3 className="text-2xl font-bold mb-4">Our Mission</h3>
              <p className="text-muted-foreground leading-relaxed">
                To ensure reliable, affordable, and sustainable electricity supply to all citizens of Bangladesh, 
                fostering economic growth and improving quality of life through innovative power solutions and 
                excellent customer service.
              </p>
            </div>
          </Card>

          <Card className="p-8 border-0 shadow-xl relative overflow-hidden" style={glassStyle}>
            <motion.div
              className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-blue-500/10"
              animate={{ opacity: [0.1, 0.2, 0.1] }}
              transition={{ duration: 3, repeat: Infinity, delay: 1 }}
            />
            <div className="relative z-10">
              <motion.div
                className="inline-flex p-4 rounded-xl bg-gradient-to-br from-green-500 to-blue-500 text-white mb-6"
                animate={{ rotate: [0, -5, 5, 0] }}
                transition={{ duration: 4, repeat: Infinity, delay: 2 }}
              >
                <Eye className="w-8 h-8" />
              </motion.div>
              <h3 className="text-2xl font-bold mb-4">Our Vision</h3>
              <p className="text-muted-foreground leading-relaxed">
                To be the leading power utility in South Asia, recognized for excellence in service delivery, 
                technological innovation, and environmental stewardship, contributing to a prosperous and 
                sustainable Bangladesh.
              </p>
            </div>
          </Card>
        </motion.div>

        {/* Core Values */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mb-16"
        >
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold mb-4">Our Core Values</h3>
            <p className="text-muted-foreground">
              The principles that guide our work and define our culture
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05, rotateY: 5 }}
                className="group"
              >
                <Card className="p-6 text-center border-0 shadow-lg h-full" style={glassStyle}>
                  <motion.div
                    className={`inline-flex p-4 rounded-xl bg-gradient-to-br ${value.color} text-white mb-4`}
                    animate={{
                      rotate: [0, 10, -10, 0],
                    }}
                    transition={{
                      duration: 5,
                      repeat: Infinity,
                      delay: index * 0.5,
                    }}
                  >
                    <value.icon className="w-6 h-6" />
                  </motion.div>
                  <h4 className="font-bold mb-2">{value.title}</h4>
                  <p className="text-sm text-muted-foreground">{value.description}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold mb-4">Our Journey</h3>
            <p className="text-muted-foreground">
              Major milestones in Bangladesh's power sector development
            </p>
          </div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-blue-500 via-purple-500 to-green-500 rounded-full" />
            
            {milestones.map((milestone, index) => (
              <motion.div
                key={milestone.year}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.2 }}
                className={`relative flex items-center mb-8 ${
                  index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                }`}
              >
                <div className={`w-5/12 ${index % 2 === 0 ? 'text-right pr-8' : 'text-left pl-8'}`}>
                  <Card className="p-6 border-0 shadow-lg" style={glassStyle}>
                    <Badge className="mb-2 bg-blue-500/20 text-blue-600 border border-blue-500/30">
                      {milestone.year}
                    </Badge>
                    <h4 className="font-bold mb-2">{milestone.event}</h4>
                    <p className="text-sm text-muted-foreground">{milestone.description}</p>
                  </Card>
                </div>
                
                {/* Timeline Dot */}
                <motion.div
                  className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-blue-500 rounded-full border-4 border-background z-10"
                  animate={{
                    scale: [1, 1.2, 1],
                    boxShadow: [
                      '0 0 0 0 rgba(59, 130, 246, 0.7)',
                      '0 0 0 10px rgba(59, 130, 246, 0)',
                      '0 0 0 0 rgba(59, 130, 246, 0)',
                    ],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: index * 0.3,
                  }}
                />
                
                <div className="w-5/12" />
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Leadership */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold mb-4">Leadership Team</h3>
            <p className="text-muted-foreground">
              Experienced professionals leading Bangladesh's power sector transformation
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {leadership.map((leader, index) => (
              <motion.div
                key={leader.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="group"
              >
                <Card className="p-6 text-center border-0 shadow-lg" style={glassStyle}>
                  <motion.div
                    className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-blue-500 to-green-500 flex items-center justify-center text-white text-2xl font-bold"
                    whileHover={{ rotate: 10 }}
                  >
                    {leader.name.split(' ').map(n => n[0]).join('')}
                  </motion.div>
                  <h4 className="font-bold mb-1">{leader.name}</h4>
                  <p className="text-sm text-blue-600 dark:text-blue-400 mb-1">{leader.position}</p>
                  <p className="text-xs text-muted-foreground mb-2">{leader.department}</p>
                  <Badge variant="outline" className="text-xs">
                    {leader.experience}
                  </Badge>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Achievements */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1 }}
        >
          <Card className="p-8 lg:p-12 border-0 shadow-2xl" style={glassStyle}>
            <div className="text-center mb-8">
              <h3 className="text-3xl font-bold mb-4">Our Achievements</h3>
              <p className="text-muted-foreground">
                Milestones that reflect our commitment to excellence
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {achievements.map((achievement, index) => (
                <motion.div
                  key={achievement.label}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center"
                >
                  <motion.div
                    className="inline-flex p-4 rounded-full bg-gradient-to-br from-blue-500 to-green-500 text-white mb-4"
                    animate={{
                      scale: [1, 1.1, 1],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: index * 0.5,
                    }}
                  >
                    <achievement.icon className="w-6 h-6" />
                  </motion.div>
                  <motion.h4 
                    className="text-3xl font-bold mb-2 bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent"
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 2, repeat: Infinity, delay: index * 0.3 }}
                  >
                    {achievement.metric}
                  </motion.h4>
                  <p className="text-muted-foreground">{achievement.label}</p>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}