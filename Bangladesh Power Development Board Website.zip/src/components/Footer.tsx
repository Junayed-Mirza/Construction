import React from 'react';
import { motion } from 'motion/react';
import { 
  Zap, MapPin, Phone, Mail, Globe, Facebook, 
  Twitter, Linkedin, Youtube, Instagram, ArrowUp,
  Building, Users, FileText, Shield, ChevronRight,
  Calendar, Clock, Award, Heart
} from 'lucide-react';
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";

interface FooterProps {
  setActiveSection: (section: string) => void;
}

export default function Footer({ setActiveSection }: FooterProps) {
  const glassStyle = {
    background: 'rgba(0, 0, 0, 0.3)',
    backdropFilter: 'blur(20px)',
    border: '1px solid rgba(255, 255, 255, 0.1)',
  };

  const quickLinks = [
    { label: 'About BPDB', action: () => setActiveSection('about') },
    { label: 'Our Services', action: () => setActiveSection('services') },
    { label: 'Projects', action: () => setActiveSection('projects') },
    { label: 'News & Updates', action: () => setActiveSection('news') },
    { label: 'Contact Us', action: () => setActiveSection('contact') },
    { label: 'Career Opportunities', action: () => console.log('Career') },
  ];

  const customerServices = [
    { label: 'Bill Payment', link: '#' },
    { label: 'New Connection', link: '#' },
    { label: 'Load Management', link: '#' },
    { label: 'Outage Reports', link: '#' },
    { label: 'Customer Portal', link: '#' },
    { label: 'Mobile App', link: '#' },
  ];

  const corporateInfo = [
    { label: 'Annual Reports', link: '#' },
    { label: 'Financial Statements', link: '#' },
    { label: 'Procurement', link: '#' },
    { label: 'Tenders', link: '#' },
    { label: 'Policies', link: '#' },
    { label: 'RTI Act', link: '#' },
  ];

  const socialLinks = [
    { icon: Facebook, label: 'Facebook', link: '#', color: 'hover:text-blue-500' },
    { icon: Twitter, label: 'Twitter', link: '#', color: 'hover:text-sky-500' },
    { icon: Linkedin, label: 'LinkedIn', link: '#', color: 'hover:text-blue-600' },
    { icon: Youtube, label: 'YouTube', link: '#', color: 'hover:text-red-500' },
    { icon: Instagram, label: 'Instagram', link: '#', color: 'hover:text-pink-500' },
  ];

  const achievements = [
    { icon: Users, label: '35M+ Customers', value: '35M+' },
    { icon: Award, label: 'Years of Service', value: '50+' },
    { icon: Zap, label: 'Power Generation', value: '12.5K MW' },
    { icon: Globe, label: 'Coverage', value: '98.5%' },
  ];

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background to-slate-900 dark:from-background dark:to-slate-950">
        <div className="absolute inset-0 opacity-20">
          {/* Floating Particles */}
          {Array.from({ length: 20 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-blue-500/30 rounded-full"
              initial={{
                x: Math.random() * window.innerWidth,
                y: Math.random() * 200,
              }}
              animate={{
                y: [null, -50, null],
                opacity: [0.3, 0.8, 0.3],
              }}
              transition={{
                duration: 4 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
              }}
            />
          ))}
        </div>
      </div>

      <div className="relative z-10">
        {/* Main Footer Content */}
        <div className="px-4 lg:px-8 pt-16 pb-8">
          <div className="max-w-7xl mx-auto">
            {/* Footer Header */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <div className="flex items-center justify-center space-x-3 mb-4">
                <motion.div 
                  className="relative"
                  animate={{ 
                    rotate: [0, 360],
                  }}
                  transition={{ 
                    duration: 20,
                    repeat: Infinity,
                    ease: "linear"
                  }}
                >
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-green-500 rounded-xl flex items-center justify-center shadow-xl">
                    <Zap className="w-8 h-8 text-white" />
                  </div>
                </motion.div>
                <div className="text-left">
                  <h3 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-green-400 bg-clip-text text-transparent">
                    BPDB
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Power Development Board
                  </p>
                </div>
              </div>
              <p className="text-muted-foreground max-w-3xl mx-auto">
                Powering Bangladesh's future with reliable, sustainable, and innovative energy solutions since 1972
              </p>
            </motion.div>

            {/* Achievements Banner */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="mb-12"
            >
              <div 
                className="rounded-2xl p-8 shadow-xl"
                style={glassStyle}
              >
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center">
                  {achievements.map((achievement, index) => (
                    <motion.div
                      key={achievement.label}
                      initial={{ opacity: 0, scale: 0.8 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      className="space-y-2"
                    >
                      <motion.div
                        className="inline-flex p-3 rounded-full bg-gradient-to-br from-blue-500 to-green-500 text-white"
                        animate={{
                          scale: [1, 1.1, 1],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          delay: index * 0.5,
                        }}
                      >
                        <achievement.icon className="w-5 h-5" />
                      </motion.div>
                      <div>
                        <motion.p 
                          className="text-xl font-bold text-blue-400"
                          animate={{ scale: [1, 1.05, 1] }}
                          transition={{ duration: 2, repeat: Infinity, delay: index * 0.3 }}
                        >
                          {achievement.value}
                        </motion.p>
                        <p className="text-xs text-muted-foreground">{achievement.label}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Footer Links Grid */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12"
            >
              {/* Quick Links */}
              <div>
                <h4 className="text-lg font-bold mb-4 text-blue-400">Quick Links</h4>
                <ul className="space-y-2">
                  {quickLinks.map((link, index) => (
                    <motion.li
                      key={link.label}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                    >
                      <button
                        onClick={link.action}
                        className="flex items-center text-muted-foreground hover:text-blue-400 transition-colors duration-300 group"
                      >
                        <motion.div
                          animate={{ x: [0, 5, 0] }}
                          transition={{ duration: 2, repeat: Infinity, delay: index * 0.2 }}
                          className="opacity-0 group-hover:opacity-100"
                        >
                          <ChevronRight className="w-4 h-4 mr-1" />
                        </motion.div>
                        <span className="group-hover:translate-x-1 transition-transform duration-300">
                          {link.label}
                        </span>
                      </button>
                    </motion.li>
                  ))}
                </ul>
              </div>

              {/* Customer Services */}
              <div>
                <h4 className="text-lg font-bold mb-4 text-green-400">Customer Services</h4>
                <ul className="space-y-2">
                  {customerServices.map((service, index) => (
                    <motion.li
                      key={service.label}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                    >
                      <a
                        href={service.link}
                        className="flex items-center text-muted-foreground hover:text-green-400 transition-colors duration-300 group"
                      >
                        <motion.div
                          animate={{ x: [0, 5, 0] }}
                          transition={{ duration: 2, repeat: Infinity, delay: index * 0.2 }}
                          className="opacity-0 group-hover:opacity-100"
                        >
                          <ChevronRight className="w-4 h-4 mr-1" />
                        </motion.div>
                        <span className="group-hover:translate-x-1 transition-transform duration-300">
                          {service.label}
                        </span>
                      </a>
                    </motion.li>
                  ))}
                </ul>
              </div>

              {/* Corporate Info */}
              <div>
                <h4 className="text-lg font-bold mb-4 text-purple-400">Corporate</h4>
                <ul className="space-y-2">
                  {corporateInfo.map((info, index) => (
                    <motion.li
                      key={info.label}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                    >
                      <a
                        href={info.link}
                        className="flex items-center text-muted-foreground hover:text-purple-400 transition-colors duration-300 group"
                      >
                        <motion.div
                          animate={{ x: [0, 5, 0] }}
                          transition={{ duration: 2, repeat: Infinity, delay: index * 0.2 }}
                          className="opacity-0 group-hover:opacity-100"
                        >
                          <ChevronRight className="w-4 h-4 mr-1" />
                        </motion.div>
                        <span className="group-hover:translate-x-1 transition-transform duration-300">
                          {info.label}
                        </span>
                      </a>
                    </motion.li>
                  ))}
                </ul>
              </div>

              {/* Contact Info */}
              <div>
                <h4 className="text-lg font-bold mb-4 text-orange-400">Contact Info</h4>
                <div className="space-y-3">
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    className="flex items-start space-x-3"
                  >
                    <MapPin className="w-5 h-5 text-orange-400 mt-0.5" />
                    <div>
                      <p className="text-sm text-muted-foreground">
                        WASA Bhaban (15th Floor)<br />
                        Kawran Bazar, Dhaka-1215<br />
                        Bangladesh
                      </p>
                    </div>
                  </motion.div>
                  
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                    className="flex items-center space-x-3"
                  >
                    <Phone className="w-5 h-5 text-orange-400" />
                    <div>
                      <p className="text-sm text-muted-foreground">
                        Hotline: 16123<br />
                        Emergency: 999
                      </p>
                    </div>
                  </motion.div>
                  
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="flex items-center space-x-3"
                  >
                    <Mail className="w-5 h-5 text-orange-400" />
                    <p className="text-sm text-muted-foreground">
                      info@bpdb.gov.bd
                    </p>
                  </motion.div>
                  
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="flex items-center space-x-3"
                  >
                    <Globe className="w-5 h-5 text-orange-400" />
                    <p className="text-sm text-muted-foreground">
                      www.bpdb.gov.bd
                    </p>
                  </motion.div>
                </div>
              </div>
            </motion.div>

            {/* Social Media Links */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="text-center mb-8"
            >
              <h4 className="text-lg font-bold mb-6">Connect With Us</h4>
              <div className="flex justify-center space-x-4">
                {socialLinks.map((social, index) => (
                  <motion.a
                    key={social.label}
                    href={social.link}
                    initial={{ opacity: 0, scale: 0 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.2, rotate: 5 }}
                    whileTap={{ scale: 0.9 }}
                    className={`p-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 text-muted-foreground ${social.color} transition-all duration-300 hover:bg-white/20`}
                  >
                    <social.icon className="w-5 h-5" />
                  </motion.a>
                ))}
              </div>
            </motion.div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10">
          <div className="px-4 lg:px-8 py-6">
            <div className="max-w-7xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.8 }}
                className="flex flex-col lg:flex-row items-center justify-between gap-4"
              >
                <div className="flex flex-col lg:flex-row items-center gap-4 text-sm text-muted-foreground">
                  <p>
                    © 2024 Bangladesh Power Development Board. All rights reserved.
                  </p>
                  <div className="flex items-center gap-4">
                    <a href="#" className="hover:text-blue-400 transition-colors">Privacy Policy</a>
                    <Separator orientation="vertical" className="h-4" />
                    <a href="#" className="hover:text-blue-400 transition-colors">Terms of Service</a>
                    <Separator orientation="vertical" className="h-4" />
                    <a href="#" className="hover:text-blue-400 transition-colors">Accessibility</a>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <Badge className="bg-green-500/20 text-green-400 border border-green-500/30">
                    <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse" />
                    System Online
                  </Badge>
                  
                  <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                    <Button
                      onClick={scrollToTop}
                      size="icon"
                      variant="outline"
                      className="rounded-full bg-white/10 border-white/20 hover:bg-white/20"
                    >
                      <ArrowUp className="w-4 h-4" />
                    </Button>
                  </motion.div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}