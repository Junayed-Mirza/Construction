import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MapPin, Calendar, TrendingUp, Users, Zap, 
  Factory, Wind, Sun, Waves, Fuel, ChevronRight,
  Eye, ExternalLink, Clock, DollarSign
} from 'lucide-react';
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

interface ProjectsProps {
  expanded?: boolean;
}

export default function Projects({ expanded = false }: ProjectsProps) {
  const [selectedProject, setSelectedProject] = useState<number | null>(null);

  const glassStyle = {
    background: 'rgba(255, 255, 255, 0.1)',
    backdropFilter: 'blur(20px)',
    border: '1px solid rgba(255, 255, 255, 0.2)',
  };

  const ongoingProjects = [
    {
      id: 1,
      title: 'Rooppur Nuclear Power Plant',
      description: 'Bangladesh\'s first nuclear power plant with 2400 MW capacity',
      location: 'Pabna, Bangladesh',
      capacity: '2400 MW',
      progress: 85,
      investment: '$12.65 Billion',
      completion: '2024',
      type: 'Nuclear',
      icon: Factory,
      color: 'from-red-500 to-pink-500',
      status: 'Under Construction',
      image: 'nuclear-plant'
    },
    {
      id: 2,
      title: 'Payra Coal Power Plant',
      description: 'Ultra-modern coal-fired power plant with advanced emission controls',
      location: 'Patuakhali, Bangladesh',
      capacity: '1320 MW',
      progress: 95,
      investment: '$1.8 Billion',
      completion: '2024',
      type: 'Coal',
      icon: Factory,
      color: 'from-gray-500 to-slate-600',
      status: 'Near Completion',
      image: 'coal-plant'
    },
    {
      id: 3,
      title: 'Matarbari Coal Power Plant',
      description: 'High-efficiency supercritical coal power plant',
      location: 'Cox\'s Bazar, Bangladesh',
      capacity: '1200 MW',
      progress: 70,
      investment: '$4.5 Billion',
      completion: '2025',
      type: 'Coal',
      icon: Factory,
      color: 'from-orange-500 to-red-500',
      status: 'Under Construction',
      image: 'coal-plant-2'
    },
    {
      id: 4,
      title: 'Solar Park Initiative',
      description: 'Distributed solar power generation across rural Bangladesh',
      location: 'Multiple Locations',
      capacity: '500 MW',
      progress: 60,
      investment: '$750 Million',
      completion: '2025',
      type: 'Solar',
      icon: Sun,
      color: 'from-yellow-400 to-orange-500',
      status: 'In Progress',
      image: 'solar-park'
    },
    {
      id: 5,
      title: 'Wind Power Development',
      description: 'Coastal wind farms for sustainable energy generation',
      location: 'Coastal Areas',
      capacity: '200 MW',
      progress: 40,
      investment: '$300 Million',
      completion: '2026',
      type: 'Wind',
      icon: Wind,
      color: 'from-cyan-400 to-blue-500',
      status: 'Early Stage',
      image: 'wind-farm'
    },
    {
      id: 6,
      title: 'LNG-based Power Plants',
      description: 'Clean and efficient natural gas power generation',
      location: 'Chittagong & Dhaka',
      capacity: '800 MW',
      progress: 80,
      investment: '$1.2 Billion',
      completion: '2024',
      type: 'Gas',
      icon: Fuel,
      color: 'from-blue-500 to-indigo-500',
      status: 'Under Construction',
      image: 'gas-plant'
    }
  ];

  const completedProjects = [
    {
      title: 'Bibiyana Power Plant',
      capacity: '400 MW',
      year: '2023',
      type: 'Gas',
      location: 'Habiganj',
      icon: Fuel
    },
    {
      title: 'Bhola Solar Park',
      capacity: '50 MW',
      year: '2023',
      type: 'Solar',
      location: 'Bhola',
      icon: Sun
    },
    {
      title: 'Rampal Power Station',
      capacity: '1320 MW',
      year: '2022',
      type: 'Coal',
      location: 'Bagerhat',
      icon: Factory
    },
    {
      title: 'Meghnaghat Power Station',
      capacity: '450 MW',
      year: '2022',
      type: 'Gas',
      location: 'Narayanganj',
      icon: Fuel
    }
  ];

  const plannedProjects = [
    {
      title: 'Rooppur Unit 3 & 4',
      capacity: '2400 MW',
      year: '2028',
      type: 'Nuclear',
      location: 'Pabna',
      icon: Factory
    },
    {
      title: 'Offshore Wind Farm',
      capacity: '500 MW',
      year: '2027',
      type: 'Wind',
      location: 'Bay of Bengal',
      icon: Wind
    },
    {
      title: 'Floating Solar Project',
      capacity: '300 MW',
      year: '2026',
      type: 'Solar',
      location: 'Kaptai Lake',
      icon: Sun
    }
  ];

  return (
    <section className={`${expanded ? 'pt-32' : 'py-16'} lg:py-24 px-4 lg:px-8`}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Badge className="mb-4 bg-purple-500/20 text-purple-600 dark:text-purple-400 border border-purple-500/30">
            Our Projects
          </Badge>
          <h2 className="text-3xl lg:text-5xl font-bold mb-4">
            Power Infrastructure
            <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent"> Development</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Transforming Bangladesh's energy landscape through cutting-edge power generation projects
          </p>
        </motion.div>

        {/* Project Categories */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Tabs defaultValue="ongoing" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-white/10 dark:bg-white/5 backdrop-blur-md mb-8">
              <TabsTrigger value="ongoing">Ongoing Projects</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
              <TabsTrigger value="planned">Planned</TabsTrigger>
            </TabsList>

            <TabsContent value="ongoing">
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {ongoingProjects.map((project, index) => (
                  <motion.div
                    key={project.id}
                    initial={{ opacity: 0, y: 20, scale: 0.95 }}
                    whileInView={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ 
                      delay: index * 0.1, 
                      duration: 0.6,
                      type: "spring",
                      stiffness: 100
                    }}
                    whileHover={{ 
                      scale: 1.02,
                      transition: { duration: 0.3 }
                    }}
                    className="group cursor-pointer"
                    onClick={() => setSelectedProject(selectedProject === project.id ? null : project.id)}
                  >
                    <Card 
                      className="p-6 h-full border-0 shadow-xl relative overflow-hidden"
                      style={glassStyle}
                    >
                      {/* Background Gradient */}
                      <motion.div
                        className={`absolute inset-0 bg-gradient-to-br ${project.color} opacity-10 group-hover:opacity-20 transition-opacity duration-300`}
                        animate={{
                          scale: [1, 1.05, 1],
                        }}
                        transition={{
                          duration: 4,
                          repeat: Infinity,
                          delay: index * 0.5,
                        }}
                      />

                      {/* Status Badge */}
                      <Badge 
                        variant="outline" 
                        className={`absolute top-4 right-4 text-xs ${
                          project.progress > 80 ? 'bg-green-500/20 text-green-600 border-green-500/30' :
                          project.progress > 50 ? 'bg-yellow-500/20 text-yellow-600 border-yellow-500/30' :
                          'bg-blue-500/20 text-blue-600 border-blue-500/30'
                        }`}
                      >
                        {project.status}
                      </Badge>

                      {/* Icon */}
                      <motion.div
                        className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${project.color} text-white mb-4 shadow-lg relative z-10`}
                        animate={{
                          rotate: [0, 3, -3, 0],
                        }}
                        transition={{
                          duration: 6,
                          repeat: Infinity,
                          delay: index * 0.3,
                        }}
                      >
                        <project.icon className="w-6 h-6" />
                      </motion.div>

                      {/* Content */}
                      <div className="relative z-10">
                        <h3 className="text-lg font-bold mb-2 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-purple-600 group-hover:to-blue-600 group-hover:bg-clip-text transition-all duration-300">
                          {project.title}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                          {project.description}
                        </p>

                        {/* Key Info */}
                        <div className="space-y-2 mb-4">
                          <div className="flex items-center text-sm">
                            <MapPin className="w-4 h-4 mr-2 text-blue-500" />
                            {project.location}
                          </div>
                          <div className="flex items-center text-sm">
                            <Zap className="w-4 h-4 mr-2 text-yellow-500" />
                            {project.capacity}
                          </div>
                          <div className="flex items-center text-sm">
                            <Calendar className="w-4 h-4 mr-2 text-green-500" />
                            Expected: {project.completion}
                          </div>
                        </div>

                        {/* Progress */}
                        <div className="mb-4">
                          <div className="flex justify-between text-sm mb-2">
                            <span>Progress</span>
                            <span className="font-medium">{project.progress}%</span>
                          </div>
                          <Progress value={project.progress} className="h-2" />
                        </div>

                        {/* Investment */}
                        <div className="flex items-center justify-between text-sm mb-4">
                          <span className="text-muted-foreground">Investment:</span>
                          <span className="font-bold text-green-600">{project.investment}</span>
                        </div>

                        {/* Expand Button */}
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full group-hover:bg-white/20 transition-all duration-300 rounded-lg"
                        >
                          {selectedProject === project.id ? 'Show Less' : 'View Details'}
                          <motion.div
                            animate={{ rotate: selectedProject === project.id ? 90 : 0 }}
                            transition={{ duration: 0.3 }}
                          >
                            <ChevronRight className="ml-2 w-4 h-4" />
                          </motion.div>
                        </Button>

                        {/* Expanded Details */}
                        <AnimatePresence>
                          {selectedProject === project.id && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.3 }}
                              className="mt-4 pt-4 border-t border-white/20"
                            >
                              <div className="space-y-3 text-sm">
                                <div className="flex items-center justify-between">
                                  <span>Type:</span>
                                  <Badge variant="outline" className="text-xs">
                                    {project.type}
                                  </Badge>
                                </div>
                                <div className="flex items-center justify-between">
                                  <span>Timeline:</span>
                                  <span>2020 - {project.completion}</span>
                                </div>
                                <div className="flex gap-2 mt-4">
                                  <Button size="sm" variant="outline" className="flex-1">
                                    <Eye className="w-4 h-4 mr-1" />
                                    View
                                  </Button>
                                  <Button size="sm" variant="outline" className="flex-1">
                                    <ExternalLink className="w-4 h-4 mr-1" />
                                    Details
                                  </Button>
                                </div>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="completed">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {completedProjects.map((project, index) => (
                  <motion.div
                    key={project.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.05 }}
                    className="group"
                  >
                    <Card 
                      className="p-4 border-0 shadow-lg"
                      style={glassStyle}
                    >
                      <motion.div
                        className="inline-flex p-3 rounded-lg bg-gradient-to-br from-green-500 to-emerald-500 text-white mb-3"
                        whileHover={{ rotate: 10 }}
                      >
                        <project.icon className="w-5 h-5" />
                      </motion.div>
                      <h4 className="font-bold mb-2 text-sm">{project.title}</h4>
                      <div className="space-y-1 text-xs text-muted-foreground">
                        <div>{project.capacity}</div>
                        <div>{project.location}</div>
                        <div>Completed: {project.year}</div>
                      </div>
                      <Badge variant="outline" className="mt-2 text-xs bg-green-500/20 text-green-600 border-green-500/30">
                        Operational
                      </Badge>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="planned">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {plannedProjects.map((project, index) => (
                  <motion.div
                    key={project.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.05 }}
                    className="group"
                  >
                    <Card 
                      className="p-6 border-0 shadow-lg"
                      style={glassStyle}
                    >
                      <motion.div
                        className="inline-flex p-3 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-500 text-white mb-4"
                        whileHover={{ rotate: 10 }}
                      >
                        <project.icon className="w-6 h-6" />
                      </motion.div>
                      <h4 className="font-bold mb-2">{project.title}</h4>
                      <div className="space-y-2 text-sm text-muted-foreground">
                        <div className="flex justify-between">
                          <span>Capacity:</span>
                          <span className="font-medium">{project.capacity}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Location:</span>
                          <span className="font-medium">{project.location}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Expected:</span>
                          <span className="font-medium">{project.year}</span>
                        </div>
                      </div>
                      <Badge variant="outline" className="mt-3 text-xs bg-blue-500/20 text-blue-600 border-blue-500/30">
                        Planned
                      </Badge>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>

        {/* Summary Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-16"
        >
          <Card 
            className="p-8 border-0 shadow-2xl"
            style={glassStyle}
          >
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-center">
              <div>
                <motion.h3 
                  className="text-3xl font-bold mb-2 text-blue-600"
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  12,500 MW
                </motion.h3>
                <p className="text-muted-foreground">Total Capacity</p>
              </div>
              <div>
                <motion.h3 
                  className="text-3xl font-bold mb-2 text-green-600"
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
                >
                  45+
                </motion.h3>
                <p className="text-muted-foreground">Active Projects</p>
              </div>
              <div>
                <motion.h3 
                  className="text-3xl font-bold mb-2 text-purple-600"
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 2, repeat: Infinity, delay: 1 }}
                >
                  $25B+
                </motion.h3>
                <p className="text-muted-foreground">Total Investment</p>
              </div>
              <div>
                <motion.h3 
                  className="text-3xl font-bold mb-2 text-orange-600"
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 2, repeat: Infinity, delay: 1.5 }}
                >
                  98.5%
                </motion.h3>
                <p className="text-muted-foreground">Coverage</p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}