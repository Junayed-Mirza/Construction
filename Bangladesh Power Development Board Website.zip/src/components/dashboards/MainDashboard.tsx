import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  LayoutDashboard,
  Users,
  Settings,
  LogOut,
  Bell,
  Search,
  Menu,
  Sun,
  Moon,
  Zap,
  BarChart3,
  Building,
  Factory,
  FileText,
  ChevronDown,
  Shield,
  Building2,
  Wrench,
  Package,
  DollarSign,
  HardHat,
  ClipboardCheck,
  Calendar,
  Truck,
  Target,
  Database,
} from "lucide-react";
import { Button } from "../ui/button";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "../ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "../ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarProvider,
  SidebarTrigger,
} from "../ui/sidebar";
import { Input } from "../ui/input";
import { supabase } from "../../utils/supabase/client";
import { projectId } from "../../utils/supabase/info";

// Dashboard Components
import ExecutiveDashboard from "./ExecutiveDashboard";
import DepartmentDashboard from "./DepartmentDashboard";
import PowerPlantDashboard from "./PowerPlantDashboard";
import UserDashboard from "./UserDashboard";

// Department-Specific Dashboards
import GenerationDashboard from "./departments/GenerationDashboard";
import TransmissionDashboard from "./departments/TransmissionDashboard";

// Role-Based Dashboards
import SeniorEngineerDashboard from "./roles/SeniorEngineerDashboard";

// Power Plant Dashboards
import BarapukuriaCoalPowerPlantDashboard from "./powerplants/BarapukuriaCoalPowerPlantDashboard";

// Router and System Components
import DashboardRouter from "./DashboardRouter";
import SystemOverview from "./SystemOverview";

// Profile Components
import UserProfile from "../profile/UserProfile";
import TwoFactorAuth from "../auth/TwoFactorAuth";

// Construction Management Components
import ProjectManagement from "../construction/ProjectManagement";
import EquipmentManagement from "../construction/EquipmentManagement";
import MaterialManagement from "../construction/MaterialManagement";
import ContractorManagement from "../construction/ContractorManagement";
import FinancialManagement from "../construction/FinancialManagement";
import QualitySafetyManagement from "../construction/QualitySafetyManagement";
import DocumentManagement from "../construction/DocumentManagement";
import MaintenanceScheduling from "../construction/MaintenanceScheduling";
import ReportingAnalytics from "../construction/ReportingAnalytics";

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  department: string;
  powerPlant?: string;
  level: number;
  permissions: string[];
  accessToken: string;
}

interface MainDashboardProps {
  user: User;
  onLogout: () => void;
  isDark: boolean;
  toggleTheme: () => void;
}

export default function MainDashboard({
  user,
  onLogout,
  isDark,
  toggleTheme,
}: MainDashboardProps) {
  const [activeView, setActiveView] = useState("overview");
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [notifications, setNotifications] = useState(3);
  const [showProfile, setShowProfile] = useState(false);
  const [show2FA, setShow2FA] = useState(false);
  const [currentUser, setCurrentUser] = useState(user);

  useEffect(() => {
    fetchDashboardData();
  }, [user.accessToken]);

  const fetchDashboardData = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/dashboard/overview`,
        {
          headers: {
            Authorization: `Bearer ${user.accessToken}`,
            "Content-Type": "application/json",
          },
        },
      );

      if (response.ok) {
        const data = await response.json();
        setDashboardData(data);
      }
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      onLogout();
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  const handleUserUpdate = (updatedUser: any) => {
    setCurrentUser(updatedUser);
  };

  const handle2FASuccess = (verifiedUser: any) => {
    setCurrentUser(verifiedUser);
    setShow2FA(false);
  };

  const getMenuItems = () => {
    const baseItems = [
      {
        id: "overview",
        label: "Overview",
        icon: LayoutDashboard,
      },
    ];

    // Construction Management items (available to most users based on permissions)
    const constructionItems = [
      {
        id: "projects",
        label: "Project Management",
        icon: Building2,
      },
      {
        id: "equipment",
        label: "Equipment Management",
        icon: Wrench,
      },
      {
        id: "materials",
        label: "Material Management",
        icon: Package,
      },
      {
        id: "contractors",
        label: "Contractor Management",
        icon: Users,
      },
      {
        id: "financial",
        label: "Financial Management",
        icon: DollarSign,
      },
      {
        id: "quality-safety",
        label: "Quality & Safety",
        icon: HardHat,
      },
      {
        id: "documents",
        label: "Document Management",
        icon: FileText,
      },
      {
        id: "maintenance",
        label: "Maintenance Scheduling",
        icon: Calendar,
      },
    ];

    if (user.level >= 8) {
      // Executive level - access to all dashboards and construction management
      return [
        ...baseItems,
        {
          id: "system-overview",
          label: "System Overview",
          icon: LayoutDashboard,
        },
        {
          id: "executive",
          label: "Executive Dashboard",
          icon: BarChart3,
        },
        {
          id: "departments",
          label: "All Departments",
          icon: Building,
        },
        {
          id: "powerplants",
          label: "All Power Plants",
          icon: Factory,
        },
        ...constructionItems,
        { id: "users", label: "User Management", icon: Users },
        {
          id: "reports",
          label: "Reports & Analytics",
          icon: BarChart3,
        },
        {
          id: "data-management",
          label: "Data Management",
          icon: Database,
        },
      ];
    } else if (user.level >= 6) {
      // Department managers - access to construction management
      return [
        ...baseItems,
        {
          id: "department",
          label: "Department Dashboard",
          icon: Building,
        },
        ...constructionItems,
        { id: "team", label: "Team Management", icon: Users },
        {
          id: "reports",
          label: "Reports & Analytics",
          icon: BarChart3,
        },
      ];
    } else if (user.level >= 4) {
      // Project managers and supervisors - access to specific construction modules
      return [
        ...baseItems,
        {
          id: "powerplant",
          label: "Power Plant Dashboard",
          icon: Factory,
        },
        {
          id: "projects",
          label: "Project Management",
          icon: Building2,
        },
        {
          id: "equipment",
          label: "Equipment Management",
          icon: Wrench,
        },
        {
          id: "materials",
          label: "Material Management",
          icon: Package,
        },
        {
          id: "quality-safety",
          label: "Quality & Safety",
          icon: HardHat,
        },
        {
          id: "operations",
          label: "Operations",
          icon: Settings,
        },
      ];
    } else if (user.powerPlant) {
      // Plant-specific users - limited construction access
      return [
        ...baseItems,
        {
          id: "powerplant",
          label: "Power Plant Dashboard",
          icon: Factory,
        },
        {
          id: "projects",
          label: "Project View",
          icon: Building2,
        },
        {
          id: "equipment",
          label: "Equipment View",
          icon: Wrench,
        },
        { id: "documents", label: "Documents", icon: FileText },
        {
          id: "maintenance",
          label: "Maintenance",
          icon: Calendar,
        },
        {
          id: "quality-safety",
          label: "Safety Reports",
          icon: HardHat,
        },
        {
          id: "operations",
          label: "Operations",
          icon: Settings,
        },
      ];
    } else {
      // General users - basic access
      return [
        ...baseItems,
        {
          id: "department",
          label: "Department View",
          icon: Building,
        },
        {
          id: "projects",
          label: "Project View",
          icon: Building2,
        },
        { id: "tasks", label: "My Tasks", icon: FileText },
      ];
    }
  };

  const renderDashboardContent = () => {
    if (isLoading) {
      return (
        <div className="flex items-center justify-center h-64">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{
              duration: 1,
              repeat: Infinity,
              ease: "linear",
            }}
            className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full"
          />
        </div>
      );
    }

    switch (activeView) {
      case "overview":
        // Use SystemOverview for high-level users or DashboardRouter for specific routing
        if (user.level >= 8) {
          return <SystemOverview user={user} isDark={isDark} />;
        }
        return <DashboardRouter user={user} isDark={isDark} activeView={activeView} dashboardData={dashboardData} />;
      
      case "executive":
        return <ExecutiveDashboard user={user} />;
      
      case "department":
      case "departments":
        if (activeView === "department") {
          return <DashboardRouter user={user} isDark={isDark} activeView={activeView} dashboardData={dashboardData} />;
        }
        return <DepartmentDashboard user={user} viewAll={true} />;
      
      case "powerplant":
      case "powerplants":
        if (activeView === "powerplant") {
          return <DashboardRouter user={user} isDark={isDark} activeView={activeView} dashboardData={dashboardData} />;
        }
        return <PowerPlantDashboard user={user} viewAll={true} />;

      // Specific Dashboard Routes - handled by DashboardRouter
      case "generation-dept":
      case "transmission-dept":
      case "senior-engineer":
      case "barapukuria-plant":
        return <DashboardRouter user={user} isDark={isDark} activeView={activeView} dashboardData={dashboardData} />;

      // System Overview for executives
      case "system-overview":
        return <SystemOverview user={user} isDark={isDark} />;

      // Construction Management Components
      case "projects":
        return <ProjectManagement />;
      case "equipment":
        return <EquipmentManagement />;
      case "materials":
        return <MaterialManagement />;
      case "contractors":
        return <ContractorManagement />;
      case "financial":
        return <FinancialManagement />;
      case "quality-safety":
        return <QualitySafetyManagement />;
      case "documents":
        return <DocumentManagement />;
      case "maintenance":
        return <MaintenanceScheduling />;
      case "reports":
        return <ReportingAnalytics />;

      default:
        return <DashboardRouter user={user} isDark={isDark} activeView="overview" dashboardData={dashboardData} />;
    }
  };

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900">
        {/* Background Pattern */}
        <div className="fixed inset-0 opacity-30 dark:opacity-20 pointer-events-none">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 via-transparent to-green-50/50 dark:from-blue-900/20 dark:via-transparent dark:to-green-900/20"></div>
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%234f46e5' fill-opacity='0.1'%3E%3Cpath d='m36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
              backgroundRepeat: "repeat",
            }}
          ></div>
        </div>

        <SidebarProvider>
          <div className="relative z-10 flex h-screen">
            {/* Sidebar */}
            <Sidebar className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border-r border-white/20 dark:border-gray-700/30">
              <SidebarHeader className="p-6 border-b border-white/20 dark:border-gray-700/30">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-green-600 rounded-lg flex items-center justify-center">
                    <Zap className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h1 className="font-bold text-gray-900 dark:text-white">
                      BPDB Portal
                    </h1>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Dashboard
                    </p>
                  </div>
                </div>
              </SidebarHeader>

              <SidebarContent>
                <SidebarMenu>
                  {getMenuItems().map((item) => (
                    <SidebarMenuItem key={item.id}>
                      <SidebarMenuButton
                        onClick={() => setActiveView(item.id)}
                        isActive={activeView === item.id}
                        className="w-full justify-start"
                      >
                        <item.icon className="w-5 h-5 mr-3" />
                        {item.label}
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarContent>
            </Sidebar>

            {/* Main Content */}
            <div className="flex-1 flex flex-col">
              {/* Header */}
              <header className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border-b border-white/20 dark:border-gray-700/30 p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <SidebarTrigger className="lg:hidden" />
                    <div>
                      <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                        {getMenuItems().find(
                          (item) => item.id === activeView,
                        )?.label || "Dashboard"}
                      </h2>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Welcome back, {user.name}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    {/* Search */}
                    <div className="relative hidden md:block">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        placeholder="Search..."
                        className="pl-10 w-64 backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-white/20 dark:border-gray-700/30"
                      />
                    </div>

                    {/* Notifications */}
                    <Button
                      variant="ghost"
                      size="sm"
                      className="relative"
                    >
                      <Bell className="w-5 h-5" />
                      {notifications > 0 && (
                        <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 text-xs bg-red-500">
                          {notifications}
                        </Badge>
                      )}
                    </Button>

                    {/* Theme Toggle */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={toggleTheme}
                    >
                      {isDark ? (
                        <Sun className="w-5 h-5" />
                      ) : (
                        <Moon className="w-5 h-5" />
                      )}
                    </Button>

                    {/* User Menu */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          className="flex items-center space-x-2 p-2"
                        >
                          <Avatar className="w-8 h-8">
                            <AvatarImage
                              src=""
                              alt={user.name}
                            />
                            <AvatarFallback className="bg-gradient-to-r from-blue-600 to-green-600 text-white">
                              {user.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")
                                .slice(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="hidden md:block text-left">
                            <p className="text-sm font-medium text-gray-900 dark:text-white">
                              {user.name}
                            </p>
                            <p className="text-xs text-gray-600 dark:text-gray-400">
                              {user.role}
                            </p>
                          </div>
                          <ChevronDown className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent
                        align="end"
                        className="w-56"
                      >
                        <div className="p-2">
                          <p className="text-sm font-medium">
                            {user.name}
                          </p>
                          <p className="text-xs text-gray-600 dark:text-gray-400">
                            {user.email}
                          </p>
                          <Badge
                            variant="secondary"
                            className="mt-1 text-xs"
                          >
                            {user.role}
                          </Badge>
                        </div>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => setShowProfile(true)}
                        >
                          <Settings className="w-4 h-4 mr-2" />
                          Profile & Settings
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => setShow2FA(true)}
                        >
                          <Shield className="w-4 h-4 mr-2" />
                          Security Verification
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={handleLogout}
                          className="text-red-600 dark:text-red-400"
                        >
                          <LogOut className="w-4 h-4 mr-2" />
                          Logout
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </header>

              {/* Dashboard Content */}
              <main className="flex-1 p-6 overflow-auto">
                {renderDashboardContent()}
              </main>
            </div>
          </div>
        </SidebarProvider>
      </div>

      {/* Profile Modal */}
      {showProfile && (
        <UserProfile
          user={currentUser}
          onUserUpdate={handleUserUpdate}
          onClose={() => setShowProfile(false)}
        />
      )}

      {/* Two-Factor Authentication Modal */}
      {show2FA && (
        <TwoFactorAuth
          user={currentUser}
          onSuccess={handle2FASuccess}
          onBack={() => setShow2FA(false)}
          method="email"
        />
      )}
    </>
  );
}