import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../ui/card";
import { Badge } from "../../ui/badge";
import { Button } from "../../ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../ui/tabs";
import { Progress } from "../../ui/progress";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';
import { 
  Factory, 
  TrendingUp, 
  Settings, 
  AlertTriangle, 
  Zap, 
  Gauge,
  Thermometer,
  Droplets,
  Wind,
  Calendar,
  FileText,
  Activity,
  Shield,
  Timer,
  Users,
  Wrench
} from 'lucide-react';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  department: string;
  powerPlant?: string;
  level: number;
  permissions: string[];
  accessToken: string;
}

interface BarapukuriaCoalPowerPlantDashboardProps {
  user: User;
  isDark: boolean;
}

export default function BarapukuriaCoalPowerPlantDashboard({ user, isDark }: BarapukuriaCoalPowerPlantDashboardProps) {
  const [plantData, setPlantData] = useState<any[]>([]);
  const [unitStatus, setUnitStatus] = useState<any[]>([]);
  const [realTimeMetrics, setRealTimeMetrics] = useState<any>({});
  const [environmentalData, setEnvironmentalData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Mock data - replace with real API calls
    setPlantData([
      { time: '00:00', generation: 480, efficiency: 91.2, coalConsumption: 85, steamPressure: 165 },
      { time: '06:00', generation: 510, efficiency: 92.1, coalConsumption: 88, steamPressure: 168 },
      { time: '12:00', generation: 525, efficiency: 91.8, coalConsumption: 92, steamPressure: 170 },
      { time: '18:00', generation: 520, efficiency: 91.5, coalConsumption: 91, steamPressure: 169 },
      { time: '24:00', generation: 490, efficiency: 91.0, coalConsumption: 87, steamPressure: 166 },
    ]);

    setUnitStatus([
      { 
        name: 'Unit 1', 
        capacity: 125, 
        generation: 120, 
        status: 'operational', 
        temperature: 540, 
        pressure: 165,
        efficiency: 91.2,
        lastMaintenance: '2024-01-15',
        nextMaintenance: '2024-04-15'
      },
      { 
        name: 'Unit 2', 
        capacity: 125, 
        generation: 125, 
        status: 'operational', 
        temperature: 545, 
        pressure: 168,
        efficiency: 92.4,
        lastMaintenance: '2024-02-01',
        nextMaintenance: '2024-05-01'
      },
      { 
        name: 'Unit 3', 
        capacity: 125, 
        generation: 123, 
        status: 'operational', 
        temperature: 542, 
        pressure: 166,
        efficiency: 91.8,
        lastMaintenance: '2024-01-28',
        nextMaintenance: '2024-04-28'
      },
      { 
        name: 'Unit 4', 
        capacity: 125, 
        generation: 0, 
        status: 'maintenance', 
        temperature: 0, 
        pressure: 0,
        efficiency: 0,
        lastMaintenance: '2024-03-01',
        nextMaintenance: '2024-03-10'
      },
      { 
        name: 'Unit 5', 
        capacity: 25, 
        generation: 22, 
        status: 'operational', 
        temperature: 520, 
        pressure: 160,
        efficiency: 88.5,
        lastMaintenance: '2024-02-15',
        nextMaintenance: '2024-05-15'
      }
    ]);

    setEnvironmentalData([
      { time: '00:00', so2: 45, nox: 32, co2: 890, particulates: 12 },
      { time: '06:00', so2: 48, nox: 35, co2: 920, particulates: 14 },
      { time: '12:00', so2: 52, nox: 38, co2: 980, particulates: 15 },
      { time: '18:00', so2: 49, nox: 36, co2: 960, particulates: 13 },
      { time: '24:00', so2: 46, nox: 33, co2: 910, particulates: 12 },
    ]);

    setRealTimeMetrics({
      totalGeneration: 490,
      plantCapacity: 525,
      plantEfficiency: 91.4,
      coalConsumption: 87,
      waterConsumption: 245,
      fuelStock: 15000,
      coalQuality: 4200,
      staffOnDuty: 45,
      safetyRecord: 125
    });

    setIsLoading(false);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'operational': return 'bg-green-500';
      case 'warning': return 'bg-yellow-500';
      case 'maintenance': return 'bg-blue-500';
      case 'fault': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'operational': return { variant: 'default', text: 'Operational' };
      case 'warning': return { variant: 'secondary', text: 'Warning' };
      case 'maintenance': return { variant: 'outline', text: 'Maintenance' };
      case 'fault': return { variant: 'destructive', text: 'Fault' };
      default: return { variant: 'outline', text: 'Unknown' };
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-orange-50/50 to-red-50/50 dark:from-gray-900 dark:to-orange-900 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Barapukuria Coal Power Plant</h1>
          <p className="text-gray-600 dark:text-gray-300">525 MW Capacity • Welcome back, {user.name}</p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="px-3 py-1">
            <Factory className="w-4 h-4 mr-2" />
            {realTimeMetrics.totalGeneration}/{realTimeMetrics.plantCapacity} MW
          </Badge>
          <Badge variant="outline" className="px-3 py-1">
            <Gauge className="w-4 h-4 mr-2" />
            {realTimeMetrics.plantEfficiency}%
          </Badge>
        </div>
      </div>

      {/* Real-Time Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Current Generation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{realTimeMetrics.totalGeneration} MW</div>
            <p className="text-xs text-muted-foreground">
              {((realTimeMetrics.totalGeneration / realTimeMetrics.plantCapacity) * 100).toFixed(1)}% of capacity
            </p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Plant Efficiency</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{realTimeMetrics.plantEfficiency}%</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 inline mr-1" />
              +0.2% from yesterday
            </p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Coal Consumption</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{realTimeMetrics.coalConsumption} t/hr</div>
            <p className="text-xs text-muted-foreground">Quality: {realTimeMetrics.coalQuality} kcal/kg</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Water Consumption</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-cyan-600">{realTimeMetrics.waterConsumption} m³/hr</div>
            <p className="text-xs text-muted-foreground">Cooling & process</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Fuel Stock</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{realTimeMetrics.fuelStock} tons</div>
            <p className="text-xs text-muted-foreground">~15 days supply</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Staff on Duty</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-indigo-600">{realTimeMetrics.staffOnDuty}</div>
            <p className="text-xs text-muted-foreground">
              <Shield className="w-3 h-3 inline mr-1" />
              {realTimeMetrics.safetyRecord} days safe
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="units">Units</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="environmental">Environmental</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Generation Trend */}
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Generation & Efficiency Trend</CardTitle>
                <CardDescription>24-hour plant performance</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={plantData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Line yAxisId="left" type="monotone" dataKey="generation" stroke="#10B981" strokeWidth={2} name="Generation (MW)" />
                    <Line yAxisId="right" type="monotone" dataKey="efficiency" stroke="#3B82F6" strokeWidth={2} name="Efficiency (%)" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Fuel & Water Consumption */}
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Resource Consumption</CardTitle>
                <CardDescription>Coal consumption and steam pressure</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={plantData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Area yAxisId="left" type="monotone" dataKey="coalConsumption" stackId="1" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.3} name="Coal (t/hr)" />
                    <Line yAxisId="right" type="monotone" dataKey="steamPressure" stroke="#8B5CF6" strokeWidth={2} name="Steam Pressure (bar)" />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Key Performance Indicators */}
          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
            <CardHeader>
              <CardTitle>Key Performance Indicators</CardTitle>
              <CardDescription>Real-time operational metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-lg flex items-center justify-center">
                    <Activity className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">93.3%</div>
                    <div className="text-sm text-muted-foreground">Availability Factor</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                    <Gauge className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">85.2%</div>
                    <div className="text-sm text-muted-foreground">Load Factor</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/20 rounded-lg flex items-center justify-center">
                    <Thermometer className="w-6 h-6 text-orange-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">542°C</div>
                    <div className="text-sm text-muted-foreground">Avg. Steam Temp</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/20 rounded-lg flex items-center justify-center">
                    <Wind className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">167 bar</div>
                    <div className="text-sm text-muted-foreground">Steam Pressure</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="units" className="space-y-4">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {unitStatus.map((unit, index) => (
              <motion.div
                key={unit.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                    <div>
                      <CardTitle className="text-lg">{unit.name}</CardTitle>
                      <CardDescription>{unit.capacity} MW Capacity</CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${getStatusColor(unit.status)}`} />
                      <Badge variant={getStatusBadge(unit.status).variant as any}>
                        {getStatusBadge(unit.status).text}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-xl font-bold text-green-600">{unit.generation} MW</div>
                        <p className="text-xs text-muted-foreground">Generation</p>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-blue-600">{unit.efficiency}%</div>
                        <p className="text-xs text-muted-foreground">Efficiency</p>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-orange-600">{unit.temperature}°C</div>
                        <p className="text-xs text-muted-foreground">Temperature</p>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-purple-600">{unit.pressure} bar</div>
                        <p className="text-xs text-muted-foreground">Pressure</p>
                      </div>
                    </div>
                    
                    {unit.status === 'operational' && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Load Factor</span>
                          <span>{unit.generation}/{unit.capacity} MW</span>
                        </div>
                        <Progress value={(unit.generation / unit.capacity) * 100} className="h-2" />
                      </div>
                    )}
                    
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div>Last Maintenance: {new Date(unit.lastMaintenance).toLocaleDateString()}</div>
                      <div>Next Maintenance: {new Date(unit.nextMaintenance).toLocaleDateString()}</div>
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        <Settings className="w-4 h-4 mr-2" />
                        Control
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        <Wrench className="w-4 h-4 mr-2" />
                        Maintenance
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Unit Performance Comparison</CardTitle>
                <CardDescription>Efficiency comparison across all units</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={unitStatus.filter(unit => unit.status !== 'maintenance')}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="efficiency" fill="#3B82F6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Heat Rate Analysis</CardTitle>
                <CardDescription>Energy efficiency metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <div>
                      <div className="font-medium">Design Heat Rate</div>
                      <div className="text-sm text-muted-foreground">Target efficiency</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold text-green-600">2,400 kcal/kWh</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div>
                      <div className="font-medium">Actual Heat Rate</div>
                      <div className="text-sm text-muted-foreground">Current performance</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold text-blue-600">2,520 kcal/kWh</div>
                      <div className="text-xs text-muted-foreground">+5% from target</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                    <div>
                      <div className="font-medium">Station Heat Rate</div>
                      <div className="text-sm text-muted-foreground">Overall plant efficiency</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold text-orange-600">2,680 kcal/kWh</div>
                      <div className="text-xs text-muted-foreground">Includes auxiliaries</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="environmental" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Emissions Monitoring</CardTitle>
                <CardDescription>Real-time environmental parameters</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={environmentalData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="so2" stroke="#EF4444" strokeWidth={2} name="SO₂ (mg/Nm³)" />
                    <Line type="monotone" dataKey="nox" stroke="#F97316" strokeWidth={2} name="NOₓ (mg/Nm³)" />
                    <Line type="monotone" dataKey="particulates" stroke="#8B5CF6" strokeWidth={2} name="Particulates (mg/Nm³)" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Environmental Compliance</CardTitle>
                <CardDescription>Current emission levels vs. limits</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>SO₂ Emissions</span>
                      <span>49 mg/Nm³ / 200 mg/Nm³</span>
                    </div>
                    <Progress value={24.5} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>NOₓ Emissions</span>
                      <span>36 mg/Nm³ / 100 mg/Nm³</span>
                    </div>
                    <Progress value={36} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Particulates</span>
                      <span>13 mg/Nm³ / 50 mg/Nm³</span>
                    </div>
                    <Progress value={26} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>CO₂ Intensity</span>
                      <span>0.96 tCO₂/MWh</span>
                    </div>
                    <div className="text-xs text-muted-foreground">Within industry standards</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="maintenance" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Scheduled Maintenance</CardTitle>
                <CardDescription>Upcoming maintenance activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Factory className="w-5 h-5 text-blue-600" />
                      <div>
                        <div className="font-medium">Unit 4 Major Overhaul</div>
                        <div className="text-sm text-muted-foreground">Turbine and generator maintenance</div>
                      </div>
                    </div>
                    <Badge variant="outline">In Progress</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Wrench className="w-5 h-5 text-yellow-600" />
                      <div>
                        <div className="font-medium">Unit 1 Minor Service</div>
                        <div className="text-sm text-muted-foreground">Routine inspection and cleaning</div>
                      </div>
                    </div>
                    <Badge variant="outline">Next Week</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Settings className="w-5 h-5 text-green-600" />
                      <div>
                        <div className="font-medium">Emission System</div>
                        <div className="text-sm text-muted-foreground">ESP maintenance</div>
                      </div>
                    </div>
                    <Badge variant="outline">2 Weeks</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Maintenance History</CardTitle>
                <CardDescription>Recent maintenance activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <div>
                        <div className="font-medium text-sm">Unit 2 Boiler Inspection</div>
                        <div className="text-xs text-muted-foreground">Completed successfully</div>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground">3 days ago</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <div>
                        <div className="font-medium text-sm">Coal Handling System</div>
                        <div className="text-xs text-muted-foreground">Conveyor belt replacement</div>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground">1 week ago</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <div>
                        <div className="font-medium text-sm">Water Treatment Plant</div>
                        <div className="text-xs text-muted-foreground">Filter cleaning and calibration</div>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground">2 weeks ago</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Daily Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <Button className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Daily Generation Report
                </Button>
                <Button variant="outline" className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Plant Performance
                </Button>
                <Button variant="outline" className="w-full">
                  <FileText className="w-4 h-4 mr-2" />
                  Environmental Report
                </Button>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Operational Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <Button className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Unit Status Report
                </Button>
                <Button variant="outline" className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Fuel Consumption
                </Button>
                <Button variant="outline" className="w-full">
                  <FileText className="w-4 h-4 mr-2" />
                  Efficiency Analysis
                </Button>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Maintenance Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <Button variant="outline" className="w-full mb-2">
                  <Calendar className="w-4 h-4 mr-2" />
                  Maintenance Schedule
                </Button>
                <Button variant="outline" className="w-full mb-2">
                  <Wrench className="w-4 h-4 mr-2" />
                  Work Orders
                </Button>
                <Button variant="outline" className="w-full">
                  <Users className="w-4 h-4 mr-2" />
                  Safety Report
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}