import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  TrendingUp, 
  TrendingDown, 
  Zap, 
  Users, 
  Factory, 
  Building,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Clock,
  BarChart3,
  PieChart,
  Activity
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, PieChart as RechartsPieChart, Cell, BarChart as RechartsBarChart, Bar, Pie } from 'recharts';
import { projectId } from '../../utils/supabase/info';

interface User {
  id: string;
  name: string;
  role: string;
  department: string;
  level: number;
  accessToken: string;
}

interface ExecutiveDashboardProps {
  user: User;
}

export default function ExecutiveDashboard({ user }: ExecutiveDashboardProps) {
  const [systemData, setSystemData] = useState<any>(null);
  const [generationData, setGenerationData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchSystemData();
    fetchGenerationData();
  }, []);

  const fetchSystemData = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/dashboard/overview`, {
        headers: {
          'Authorization': `Bearer ${user.accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        setSystemData(data);
      }
    } catch (error) {
      console.error('Failed to fetch system data:', error);
    }
  };

  const fetchGenerationData = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/data/generation`, {
        headers: {
          'Authorization': `Bearer ${user.accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        setGenerationData(data);
      }
    } catch (error) {
      console.error('Failed to fetch generation data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Sample data for charts
  const powerTrendData = [
    { name: 'Jan', generation: 14500, demand: 13800 },
    { name: 'Feb', generation: 15200, demand: 14200 },
    { name: 'Mar', generation: 15800, demand: 14800 },
    { name: 'Apr', generation: 16200, demand: 15200 },
    { name: 'May', generation: 16800, demand: 15800 },
    { name: 'Jun', generation: 17200, demand: 16200 },
  ];

  const departmentPerformance = [
    { name: 'Generation', performance: 95, budget: 85 },
    { name: 'Transmission', performance: 92, budget: 88 },
    { name: 'Distribution', performance: 89, budget: 82 },
    { name: 'Finance', performance: 96, budget: 90 },
    { name: 'HR', performance: 91, budget: 87 },
    { name: 'Planning', performance: 94, budget: 89 },
  ];

  const plantStatusData = [
    { name: 'Operational', value: 28, color: '#22c55e' },
    { name: 'Maintenance', value: 4, color: '#f59e0b' },
    { name: 'Offline', value: 2, color: '#ef4444' },
  ];

  const kpiData = [
    {
      title: 'Total Generation Capacity',
      value: generationData?.totalGeneration || 15420,
      unit: 'MW',
      change: '+5.2%',
      trend: 'up',
      icon: Zap,
      color: 'text-blue-600'
    },
    {
      title: 'System Efficiency',
      value: 87.5,
      unit: '%',
      change: '+2.1%',
      trend: 'up',
      icon: TrendingUp,
      color: 'text-green-600'
    },
    {
      title: 'Active Power Plants',
      value: generationData?.powerPlants?.filter((p: any) => p.status === 'online').length || 28,
      unit: 'plants',
      change: '+2',
      trend: 'up',
      icon: Factory,
      color: 'text-purple-600'
    },
    {
      title: 'Total Employees',
      value: 12450,
      unit: 'staff',
      change: '+125',
      trend: 'up',
      icon: Users,
      color: 'text-orange-600'
    },
    {
      title: 'Revenue (Monthly)',
      value: 2.8,
      unit: 'B BDT',
      change: '+8.5%',
      trend: 'up',
      icon: DollarSign,
      color: 'text-emerald-600'
    },
    {
      title: 'System Reliability',
      value: 99.2,
      unit: '%',
      change: '+0.3%',
      trend: 'up',
      icon: CheckCircle,
      color: 'text-teal-600'
    }
  ];

  const alerts = [
    { type: 'critical', message: 'Transformer maintenance required at Dhaka Grid', time: '2 hours ago' },
    { type: 'warning', message: 'High demand expected during peak hours', time: '4 hours ago' },
    { type: 'info', message: 'New renewable project proposal submitted', time: '1 day ago' },
    { type: 'success', message: 'Monthly safety target achieved', time: '2 days ago' }
  ];

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'critical': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'warning': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'success': return <CheckCircle className="w-4 h-4 text-green-500" />;
      default: return <Activity className="w-4 h-4 text-blue-500" />;
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'critical': return 'border-l-red-500 bg-red-50 dark:bg-red-900/20';
      case 'warning': return 'border-l-yellow-500 bg-yellow-50 dark:bg-yellow-900/20';
      case 'success': return 'border-l-green-500 bg-green-50 dark:bg-green-900/20';
      default: return 'border-l-blue-500 bg-blue-50 dark:bg-blue-900/20';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Executive Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Comprehensive overview of BPDB operations and performance
          </p>
        </div>
        <Badge variant="outline" className="text-sm">
          Last updated: {new Date().toLocaleTimeString()}
        </Badge>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {kpiData.map((kpi, index) => (
          <motion.div
            key={kpi.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg bg-gray-100 dark:bg-gray-800 ${kpi.color}`}>
                      <kpi.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{kpi.title}</p>
                      <div className="flex items-baseline space-x-1">
                        <span className="text-2xl font-bold text-gray-900 dark:text-white">
                          {kpi.value.toLocaleString()}
                        </span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">{kpi.unit}</span>
                      </div>
                    </div>
                  </div>
                  <div className={`flex items-center space-x-1 ${kpi.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                    {kpi.trend === 'up' ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                    <span className="text-sm font-medium">{kpi.change}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">System Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="operations">Operations</TabsTrigger>
          <TabsTrigger value="alerts">Alerts & Issues</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Power Generation Trend */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="w-5 h-5 text-blue-600" />
                  <span>Power Generation vs Demand</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={powerTrendData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                    <XAxis dataKey="name" className="text-gray-600 dark:text-gray-400" />
                    <YAxis className="text-gray-600 dark:text-gray-400" />
                    <Tooltip />
                    <Area type="monotone" dataKey="generation" stackId="1" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.6} />
                    <Area type="monotone" dataKey="demand" stackId="2" stroke="#10b981" fill="#10b981" fillOpacity={0.6} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Plant Status Distribution */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <PieChart className="w-5 h-5 text-green-600" />
                  <span>Power Plant Status</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPieChart>
                    <Pie
                      data={plantStatusData}
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({name, value}) => `${name}: ${value}`}
                    >
                      {plantStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          {/* Department Performance */}
          <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Building className="w-5 h-5 text-purple-600" />
                <span>Department Performance & Budget Utilization</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <RechartsBarChart data={departmentPerformance}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                  <XAxis dataKey="name" className="text-gray-600 dark:text-gray-400" />
                  <YAxis className="text-gray-600 dark:text-gray-400" />
                  <Tooltip />
                  <Bar dataKey="performance" fill="#3b82f6" name="Performance %" />
                  <Bar dataKey="budget" fill="#10b981" name="Budget Utilization %" />
                </RechartsBarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="operations" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Real-time Power Plants */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Factory className="w-5 h-5 text-orange-600" />
                  <span>Power Plants Status</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-80 overflow-y-auto">
                  {generationData?.powerPlants?.slice(0, 8).map((plant: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">{plant.name}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {plant.current} / {plant.capacity} MW
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge variant={plant.status === 'online' ? 'default' : 'secondary'}>
                          {plant.status}
                        </Badge>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                          {plant.efficiency}% efficiency
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* System Health */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-red-600" />
                  <span>System Health Metrics</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Grid Stability</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">98.5%</span>
                    </div>
                    <Progress value={98.5} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Transmission Efficiency</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">94.2%</span>
                    </div>
                    <Progress value={94.2} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Distribution Reliability</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">96.8%</span>
                    </div>
                    <Progress value={96.8} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Renewable Integration</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">23.5%</span>
                    </div>
                    <Progress value={23.5} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-6">
          {/* Alerts and Issues */}
          <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertTriangle className="w-5 h-5 text-yellow-600" />
                <span>System Alerts & Issues</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {alerts.map((alert, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`p-4 border-l-4 rounded-lg ${getAlertColor(alert.type)}`}
                  >
                    <div className="flex items-start space-x-3">
                      {getAlertIcon(alert.type)}
                      <div className="flex-1">
                        <p className="font-medium text-gray-900 dark:text-white">{alert.message}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{alert.time}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}