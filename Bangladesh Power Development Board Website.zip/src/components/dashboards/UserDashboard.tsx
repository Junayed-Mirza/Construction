import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  User, 
  Calendar, 
  Clock, 
  FileText, 
  CheckCircle, 
  AlertTriangle,
  TrendingUp,
  Bell,
  Target,
  BarChart3,
  Activity,
  Building,
  Factory,
  Users,
  Award,
  MessageSquare,
  Settings
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Button } from "../ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Cell } from 'recharts';

interface User {
  id: string;
  name: string;
  role: string;
  department: string;
  powerPlant?: string;
  level: number;
}

interface UserDashboardProps {
  user: User;
  data?: any;
}

export default function UserDashboard({ user, data }: UserDashboardProps) {
  // Sample user-specific data
  const personalStats = [
    {
      title: 'Tasks Completed',
      value: 28,
      total: 35,
      change: '+4 this week',
      icon: CheckCircle,
      color: 'text-green-600',
      bgColor: 'bg-green-100 dark:bg-green-900/20'
    },
    {
      title: 'Active Projects',
      value: 3,
      change: 'On track',
      icon: Target,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100 dark:bg-blue-900/20'
    },
    {
      title: 'Hours This Week',
      value: 42,
      target: 40,
      change: '+2 overtime',
      icon: Clock,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100 dark:bg-purple-900/20'
    },
    {
      title: 'Performance Score',
      value: 94,
      unit: '%',
      change: '+5% from last month',
      icon: TrendingUp,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100 dark:bg-orange-900/20'
    }
  ];

  const recentTasks = [
    {
      id: 1,
      title: 'Review safety protocols for Generator Unit 2',
      status: 'completed',
      priority: 'high',
      dueDate: '2024-01-20',
      completedDate: '2024-01-19'
    },
    {
      id: 2,
      title: 'Update maintenance schedule',
      status: 'in-progress',
      priority: 'medium',
      dueDate: '2024-01-25',
      progress: 75
    },
    {
      id: 3,
      title: 'Prepare monthly report',
      status: 'pending',
      priority: 'high',
      dueDate: '2024-01-30'
    },
    {
      id: 4,
      title: 'Equipment inspection checklist',
      status: 'completed',
      priority: 'low',
      dueDate: '2024-01-18',
      completedDate: '2024-01-17'
    }
  ];

  const weeklyActivity = [
    { day: 'Mon', tasks: 8, hours: 8.5 },
    { day: 'Tue', tasks: 6, hours: 7.5 },
    { day: 'Wed', tasks: 9, hours: 9.0 },
    { day: 'Thu', tasks: 7, hours: 8.0 },
    { day: 'Fri', tasks: 5, hours: 7.0 },
    { day: 'Sat', tasks: 2, hours: 2.0 },
    { day: 'Sun', tasks: 0, hours: 0 },
  ];

  const notifications = [
    {
      id: 1,
      type: 'task',
      title: 'New task assigned',
      message: 'You have been assigned to review the Q1 safety audit',
      time: '2 hours ago',
      unread: true
    },
    {
      id: 2,
      type: 'meeting',
      title: 'Upcoming meeting',
      message: 'Department meeting scheduled for tomorrow at 2 PM',
      time: '4 hours ago',
      unread: true
    },
    {
      id: 3,
      type: 'system',
      title: 'System update',
      message: 'Maintenance window scheduled for this weekend',
      time: '1 day ago',
      unread: false
    },
    {
      id: 4,
      type: 'achievement',
      title: 'Milestone reached',
      message: 'Congratulations! You completed 100 tasks this month',
      time: '2 days ago',
      unread: false
    }
  ];

  const upcomingDeadlines = [
    { task: 'Monthly safety report', date: '2024-01-25', days: 3, priority: 'high' },
    { task: 'Equipment calibration', date: '2024-01-28', days: 6, priority: 'medium' },
    { task: 'Team performance review', date: '2024-02-01', days: 10, priority: 'low' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-200';
      case 'in-progress':
        return 'bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-200';
      case 'pending':
        return 'bg-yellow-100 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-200';
      default:
        return 'bg-gray-100 dark:bg-gray-900/20 text-gray-800 dark:text-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'text-red-600';
      case 'medium':
        return 'text-yellow-600';
      case 'low':
        return 'text-green-600';
      default:
        return 'text-gray-600';
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'task':
        return <FileText className="w-4 h-4 text-blue-500" />;
      case 'meeting':
        return <Calendar className="w-4 h-4 text-purple-500" />;
      case 'system':
        return <Settings className="w-4 h-4 text-orange-500" />;
      case 'achievement':
        return <Award className="w-4 h-4 text-green-500" />;
      default:
        return <Bell className="w-4 h-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Welcome back, {user.name.split(' ')[0]}!
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Here's what's happening in your workspace today.
          </p>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </p>
        </div>
      </div>

      {/* Personal Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {personalStats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{stat.title}</p>
                    <div className="flex items-baseline space-x-1 mt-1">
                      <span className="text-2xl font-bold text-gray-900 dark:text-white">
                        {stat.value}
                      </span>
                      {stat.unit && (
                        <span className="text-sm text-gray-500 dark:text-gray-400">{stat.unit}</span>
                      )}
                      {stat.total && (
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          / {stat.total}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{stat.change}</p>
                    {stat.total && (
                      <Progress value={(stat.value / stat.total) * 100} className="h-2 mt-2" />
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Tasks */}
        <div className="lg:col-span-2">
          <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="w-5 h-5 text-blue-600" />
                <span>Recent Tasks</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentTasks.map((task) => (
                  <div key={task.id} className="flex items-center justify-between p-4 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 dark:text-white">{task.title}</h4>
                      <div className="flex items-center space-x-4 mt-2">
                        <Badge className={getStatusColor(task.status)}>
                          {task.status.replace('-', ' ')}
                        </Badge>
                        <span className={`text-sm ${getPriorityColor(task.priority)}`}>
                          {task.priority} priority
                        </span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          Due: {task.dueDate}
                        </span>
                      </div>
                      {task.progress && (
                        <div className="mt-2">
                          <Progress value={task.progress} className="h-2" />
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            {task.progress}% complete
                          </p>
                        </div>
                      )}
                      {task.completedDate && (
                        <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                          Completed on {task.completedDate}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                <Button variant="outline" className="w-full">
                  View All Tasks
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Notifications */}
        <div>
          <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Bell className="w-5 h-5 text-orange-600" />
                  <span>Notifications</span>
                </div>
                <Badge className="bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-200">
                  {notifications.filter(n => n.unread).length} new
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {notifications.slice(0, 4).map((notification) => (
                  <div 
                    key={notification.id} 
                    className={`p-3 rounded-lg ${notification.unread ? 'bg-blue-50 dark:bg-blue-900/20' : 'bg-gray-50 dark:bg-gray-800/50'}`}
                  >
                    <div className="flex items-start space-x-3">
                      {getNotificationIcon(notification.type)}
                      <div className="flex-1">
                        <h5 className="font-medium text-gray-900 dark:text-white text-sm">
                          {notification.title}
                        </h5>
                        <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                          {notification.message}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                          {notification.time}
                        </p>
                      </div>
                      {notification.unread && (
                        <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                <Button variant="outline" size="sm" className="w-full">
                  View All Notifications
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Activity */}
        <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="w-5 h-5 text-green-600" />
              <span>Weekly Activity</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={weeklyActivity}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                <XAxis dataKey="day" className="text-gray-600 dark:text-gray-400" />
                <YAxis className="text-gray-600 dark:text-gray-400" />
                <Tooltip />
                <Line type="monotone" dataKey="tasks" stroke="#3b82f6" strokeWidth={2} name="Tasks" />
                <Line type="monotone" dataKey="hours" stroke="#10b981" strokeWidth={2} name="Hours" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Upcoming Deadlines */}
        <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-red-600" />
              <span>Upcoming Deadlines</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingDeadlines.map((deadline, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-white">{deadline.task}</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{deadline.date}</p>
                  </div>
                  <div className="text-right">
                    <Badge className={
                      deadline.days <= 3 ? 'bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-200' :
                      deadline.days <= 7 ? 'bg-yellow-100 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-200' :
                      'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-200'
                    }>
                      {deadline.days} days
                    </Badge>
                    <p className={`text-xs mt-1 ${getPriorityColor(deadline.priority)}`}>
                      {deadline.priority}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="w-5 h-5 text-purple-600" />
            <span>Quick Actions</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
              <FileText className="w-6 h-6" />
              <span className="text-sm">New Report</span>
            </Button>
            <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
              <Calendar className="w-6 h-6" />
              <span className="text-sm">Schedule</span>
            </Button>
            <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
              <MessageSquare className="w-6 h-6" />
              <span className="text-sm">Message</span>
            </Button>
            <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
              <Settings className="w-6 h-6" />
              <span className="text-sm">Settings</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}