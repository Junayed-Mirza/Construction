import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown,
  PieChart,
  BarChart3,
  FileText,
  CreditCard,
  Wallet,
  Calculator,
  AlertTriangle,
  CheckCircle,
  Clock,
  Settings,
  Download,
  Receipt,
  Banknote,
  Target
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../ui/card";
import { Button } from "../../ui/button";
import { Badge } from "../../ui/badge";
import { Progress } from "../../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../ui/tabs";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart as RechartsPieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface User {
  id: string;
  name: string;
  role: string;
  department: string;
}

interface FinanceAccountsDashboardProps {
  user: User;
  isDark: boolean;
}

const FinanceAccountsDashboard: React.FC<FinanceAccountsDashboardProps> = ({ user, isDark }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('monthly');
  const [selectedCategory, setSelectedCategory] = useState('all');

  // Mock financial data
  const financialMetrics = {
    totalRevenue: 85420000000, // BDT 85.42 billion
    totalExpenses: 67890000000, // BDT 67.89 billion
    netIncome: 17530000000, // BDT 17.53 billion
    operatingCash: 12450000000, // BDT 12.45 billion
    accountsReceivable: 23100000000, // BDT 23.1 billion
    accountsPayable: 8750000000, // BDT 8.75 billion
    budgetUtilization: 78.5, // %
    profitMargin: 20.5 // %
  };

  // Revenue vs Expenses trend (monthly data)
  const revenueExpenseData = [
    { month: 'Jan', revenue: 7200, expenses: 5800, netIncome: 1400 },
    { month: 'Feb', revenue: 6950, expenses: 5650, netIncome: 1300 },
    { month: 'Mar', revenue: 7350, expenses: 5950, netIncome: 1400 },
    { month: 'Apr', revenue: 7500, expenses: 6100, netIncome: 1400 },
    { month: 'May', revenue: 7800, expenses: 6200, netIncome: 1600 },
    { month: 'Jun', revenue: 8100, expenses: 6400, netIncome: 1700 },
    { month: 'Jul', revenue: 8250, expenses: 6500, netIncome: 1750 },
    { month: 'Aug', revenue: 8400, expenses: 6650, netIncome: 1750 },
    { month: 'Sep', revenue: 8200, expenses: 6550, netIncome: 1650 },
    { month: 'Oct', revenue: 8350, expenses: 6700, netIncome: 1650 },
    { month: 'Nov', revenue: 8500, expenses: 6800, netIncome: 1700 },
    { month: 'Dec', revenue: 8650, expenses: 6900, netIncome: 1750 }
  ];

  // Expense breakdown by category
  const expenseBreakdown = [
    { name: 'Fuel & Energy', value: 35, amount: 23761500000, color: '#ef4444' },
    { name: 'Personnel', value: 25, amount: 16972500000, color: '#3b82f6' },
    { name: 'Maintenance', value: 15, amount: 10183500000, color: '#10b981' },
    { name: 'Equipment', value: 12, amount: 8146800000, color: '#f59e0b' },
    { name: 'Operations', value: 8, amount: 5431200000, color: '#8b5cf6' },
    { name: 'Others', value: 5, amount: 3394500000, color: '#6b7280' }
  ];

  // Budget allocation and utilization
  const budgetData = [
    { department: 'Generation', allocated: 35000, utilized: 27500, utilization: 78.6 },
    { department: 'Transmission', allocated: 18000, utilized: 14400, utilization: 80.0 },
    { department: 'Distribution', allocated: 25000, utilized: 19500, utilization: 78.0 },
    { department: 'IT', allocated: 8000, utilized: 6200, utilization: 77.5 },
    { department: 'HR', allocated: 12000, utilized: 9600, utilization: 80.0 },
    { department: 'Administration', allocated: 15000, utilized: 11700, utilization: 78.0 }
  ];

  // Cash flow analysis
  const cashFlowData = [
    { quarter: 'Q1 2024', inflow: 22500, outflow: 18200, netFlow: 4300 },
    { quarter: 'Q2 2024', inflow: 24200, outflow: 19100, netFlow: 5100 },
    { quarter: 'Q3 2024', inflow: 25800, outflow: 20400, netFlow: 5400 },
    { quarter: 'Q4 2024', inflow: 26100, outflow: 20900, netFlow: 5200 }
  ];

  // Outstanding payments
  const outstandingPayments = [
    {
      id: 'INV-2024-1205',
      vendor: 'Bangladesh Petroleum Corporation',
      amount: 2450000000,
      dueDate: '2024-12-15',
      category: 'Fuel',
      status: 'Overdue',
      days: 5
    },
    {
      id: 'INV-2024-1198',
      vendor: 'Siemens Bangladesh',
      amount: 850000000,
      dueDate: '2024-12-20',
      category: 'Equipment',
      status: 'Due Soon',
      days: 3
    },
    {
      id: 'INV-2024-1189',
      vendor: 'BSTI Services Ltd',
      amount: 125000000,
      dueDate: '2024-12-25',
      category: 'Services',
      status: 'Pending',
      days: 8
    }
  ];

  // Recent transactions
  const recentTransactions = [
    {
      id: 'TXN-2024-15432',
      type: 'Revenue',
      description: 'Electricity Sales - Commercial',
      amount: 1250000000,
      date: '2024-12-10',
      status: 'Completed'
    },
    {
      id: 'TXN-2024-15431',
      type: 'Expense',
      description: 'Fuel Purchase - Payra Plant',
      amount: -850000000,
      date: '2024-12-10',
      status: 'Completed'
    },
    {
      id: 'TXN-2024-15430',
      type: 'Revenue',
      description: 'Government Subsidy',
      amount: 2100000000,
      date: '2024-12-09',
      status: 'Completed'
    }
  ];

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setIsLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000000) {
      return `৳${(amount / 1000000000).toFixed(2)}B`;
    } else if (amount >= 1000000) {
      return `৳${(amount / 1000000).toFixed(1)}M`;
    } else if (amount >= 1000) {
      return `৳${(amount / 1000).toFixed(1)}K`;
    }
    return `৳${amount.toFixed(0)}`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Overdue': return 'text-red-600 bg-red-100 dark:bg-red-900/20';
      case 'Due Soon': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20';
      case 'Pending': return 'text-blue-600 bg-blue-100 dark:bg-blue-900/20';
      case 'Completed': return 'text-green-600 bg-green-100 dark:bg-green-900/20';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"
          />
          <p className="text-gray-600 dark:text-gray-400">Loading Finance Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Finance & Accounts Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Financial overview and accounting management • {user.name}
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Financial Report
          </Button>
          <Button size="sm">
            <Settings className="w-4 h-4 mr-2" />
            Configure
          </Button>
        </div>
      </div>

      {/* Key Financial Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 border-green-200 dark:border-green-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-600 dark:text-green-400">Total Revenue</p>
                <p className="text-2xl font-bold text-green-900 dark:text-green-100">
                  {formatCurrency(financialMetrics.totalRevenue)}
                </p>
                <p className="text-xs text-green-600 dark:text-green-400 mt-1">+5.2% YoY</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-600 dark:text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20 border-red-200 dark:border-red-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-600 dark:text-red-400">Total Expenses</p>
                <p className="text-2xl font-bold text-red-900 dark:text-red-100">
                  {formatCurrency(financialMetrics.totalExpenses)}
                </p>
                <p className="text-xs text-red-600 dark:text-red-400 mt-1">+3.8% YoY</p>
              </div>
              <TrendingDown className="w-8 h-8 text-red-600 dark:text-red-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 border-blue-200 dark:border-blue-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-600 dark:text-blue-400">Net Income</p>
                <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                  {formatCurrency(financialMetrics.netIncome)}
                </p>
                <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">+8.7% YoY</p>
              </div>
              <DollarSign className="w-8 h-8 text-blue-600 dark:text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 border-purple-200 dark:border-purple-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-600 dark:text-purple-400">Profit Margin</p>
                <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">
                  {financialMetrics.profitMargin}%
                </p>
                <p className="text-xs text-purple-600 dark:text-purple-400 mt-1">+1.2% vs target</p>
              </div>
              <Target className="w-8 h-8 text-purple-600 dark:text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="expenses">Expenses</TabsTrigger>
          <TabsTrigger value="budget">Budget</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Revenue vs Expenses Trend */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-blue-600" />
                  Revenue vs Expenses Trend
                </CardTitle>
                <CardDescription>Monthly financial performance (in millions BDT)</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={revenueExpenseData}>
                    <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`৳${value}M`, '']} />
                    <Legend />
                    <Area 
                      type="monotone" 
                      dataKey="revenue" 
                      stackId="1" 
                      stroke="#10b981" 
                      fill="#10b981" 
                      fillOpacity={0.6}
                      name="Revenue"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="expenses" 
                      stackId="2" 
                      stroke="#ef4444" 
                      fill="#ef4444" 
                      fillOpacity={0.6}
                      name="Expenses"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Cash Flow Analysis */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wallet className="w-5 h-5 text-green-600" />
                  Quarterly Cash Flow
                </CardTitle>
                <CardDescription>Cash inflow vs outflow analysis (in millions BDT)</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={cashFlowData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="quarter" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`৳${value}M`, '']} />
                    <Legend />
                    <Bar dataKey="inflow" fill="#10b981" name="Cash Inflow" />
                    <Bar dataKey="outflow" fill="#ef4444" name="Cash Outflow" />
                    <Bar dataKey="netFlow" fill="#3b82f6" name="Net Cash Flow" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Recent Transactions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-purple-600" />
                Recent Transactions
              </CardTitle>
              <CardDescription>Latest financial transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentTransactions.map((transaction) => (
                  <div key={transaction.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className={`p-2 rounded-lg ${transaction.type === 'Revenue' ? 'bg-green-100 dark:bg-green-900/20' : 'bg-red-100 dark:bg-red-900/20'}`}>
                        {transaction.type === 'Revenue' ? 
                          <TrendingUp className="w-5 h-5 text-green-600" /> : 
                          <TrendingDown className="w-5 h-5 text-red-600" />
                        }
                      </div>
                      <div>
                        <h4 className="font-semibold">{transaction.description}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{transaction.id} • {transaction.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-lg font-bold ${transaction.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(Math.abs(transaction.amount))}
                      </p>
                      <Badge className={getStatusColor(transaction.status)}>
                        {transaction.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="expenses" className="space-y-6">
          {/* Expense Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="w-5 h-5 text-orange-600" />
                Expense Category Breakdown
              </CardTitle>
              <CardDescription>Distribution of operational expenses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPieChart>
                    <Pie
                      data={expenseBreakdown}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {expenseBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value}%`, 'Percentage']} />
                  </RechartsPieChart>
                </ResponsiveContainer>

                <div className="space-y-4">
                  {expenseBreakdown.map((category, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-4 h-4 rounded-full" 
                          style={{ backgroundColor: category.color }}
                        />
                        <span className="font-medium">{category.name}</span>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">{formatCurrency(category.amount)}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{category.value}%</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="budget" className="space-y-6">
          {/* Budget Utilization */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="w-5 h-5 text-blue-600" />
                Department Budget Utilization
              </CardTitle>
              <CardDescription>Budget allocation vs utilization by department</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {budgetData.map((dept, index) => (
                  <div key={index} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold">{dept.department}</h4>
                      <div className="text-right">
                        <p className="font-bold">{formatCurrency(dept.utilized * 1000000)} / {formatCurrency(dept.allocated * 1000000)}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{dept.utilization}% utilized</p>
                      </div>
                    </div>
                    <Progress value={dept.utilization} className="h-3" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments" className="space-y-6">
          {/* Outstanding Payments */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-red-600" />
                Outstanding Payments
              </CardTitle>
              <CardDescription>Pending vendor payments and due dates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {outstandingPayments.map((payment) => (
                  <div key={payment.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-white dark:bg-gray-700 rounded-lg">
                        <Banknote className="w-5 h-5 text-orange-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{payment.vendor}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{payment.id} • {payment.category}</p>
                        <p className="text-xs text-gray-500">Due: {payment.dueDate}</p>
                      </div>
                    </div>
                    <div className="text-right space-y-2">
                      <p className="text-lg font-bold">{formatCurrency(payment.amount)}</p>
                      <Badge className={getStatusColor(payment.status)}>
                        {payment.status} ({payment.days}d)
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FinanceAccountsDashboard;