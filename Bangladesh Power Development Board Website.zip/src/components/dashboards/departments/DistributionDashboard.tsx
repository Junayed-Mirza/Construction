import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Zap, 
  TrendingUp, 
  AlertTriangle, 
  Map,
  Users,
  Power,
  BarChart3,
  Shield,
  Clock,
  MapPin,
  Activity,
  Gauge,
  Settings,
  FileText,
  CheckCircle,
  XCircle,
  AlertCircle,
  Wrench
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../ui/card";
import { Button } from "../../ui/button";
import { Badge } from "../../ui/badge";
import { Progress } from "../../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../ui/tabs";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface User {
  id: string;
  name: string;
  role: string;
  department: string;
}

interface DistributionDashboardProps {
  user: User;
  isDark: boolean;
}

const DistributionDashboard: React.FC<DistributionDashboardProps> = ({ user, isDark }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [selectedTimeFrame, setSelectedTimeFrame] = useState('24h');
  const [selectedRegion, setSelectedRegion] = useState('All');

  // Mock data for distribution metrics
  const distributionMetrics = {
    totalConsumers: 42500000,
    activeConnections: 41800000,
    pendingConnections: 125000,
    powerDistributed: 14500, // MW
    systemLosses: 8.5, // %
    reliability: 99.2, // %
    transformers: {
      total: 185000,
      operational: 181500,
      maintenance: 2800,
      faulty: 700
    },
    regions: [
      { name: 'Dhaka', consumers: 12500000, load: 4200, losses: 7.8, reliability: 99.5 },
      { name: 'Chittagong', consumers: 8200000, load: 2800, losses: 8.2, reliability: 99.1 },
      { name: 'Sylhet', consumers: 4100000, load: 1400, losses: 9.1, reliability: 98.8 },
      { name: 'Khulna', consumers: 6800000, load: 2300, losses: 8.7, reliability: 99.0 },
      { name: 'Rajshahi', consumers: 5900000, load: 2000, losses: 8.9, reliability: 98.9 },
      { name: 'Rangpur', consumers: 3200000, load: 1100, losses: 9.5, reliability: 98.6 },
      { name: 'Barisal', consumers: 1800000, load: 700, losses: 9.8, reliability: 98.4 }
    ]
  };

  // Load demand data for the last 24 hours
  const loadDemandData = Array.from({ length: 24 }, (_, i) => ({
    hour: `${i.toString().padStart(2, '0')}:00`,
    demand: 12000 + Math.sin(i * Math.PI / 12) * 3000 + Math.random() * 500,
    supply: 12200 + Math.sin(i * Math.PI / 12) * 3100 + Math.random() * 300,
    losses: 7 + Math.random() * 3
  }));

  // System reliability data
  const reliabilityData = [
    { region: 'Dhaka', availability: 99.5, outages: 2, mttr: 45 },
    { region: 'Chittagong', availability: 99.1, outages: 4, mttr: 68 },
    { region: 'Sylhet', availability: 98.8, outages: 6, mttr: 82 },
    { region: 'Khulna', availability: 99.0, outages: 5, mttr: 72 },
    { region: 'Rajshahi', availability: 98.9, outages: 5, mttr: 78 },
    { region: 'Rangpur', availability: 98.6, outages: 7, mttr: 95 },
    { region: 'Barisal', availability: 98.4, outages: 8, mttr: 105 }
  ];

  // Transformer status data
  const transformerStatusData = [
    { name: 'Operational', value: 181500, color: '#22c55e' },
    { name: 'Maintenance', value: 2800, color: '#f59e0b' },
    { name: 'Faulty', value: 700, color: '#ef4444' }
  ];

  // Recent incidents
  const recentIncidents = [
    {
      id: 1,
      type: 'Power Outage',
      location: 'Dhanmondi, Dhaka',
      severity: 'High',
      time: '2 hours ago',
      status: 'Resolved',
      affected: 25000
    },
    {
      id: 2,
      type: 'Transformer Fault',
      location: 'Agrabad, Chittagong',
      severity: 'Medium',
      time: '4 hours ago',
      status: 'In Progress',
      affected: 8500
    },
    {
      id: 3,
      type: 'Line Maintenance',
      location: 'Zindabazar, Sylhet',
      severity: 'Low',
      time: '6 hours ago',
      status: 'Scheduled',
      affected: 3200
    }
  ];

  // Pending work orders
  const pendingWorkOrders = [
    {
      id: 'WO-2024-1205',
      type: 'New Connection',
      location: 'Uttara, Dhaka',
      priority: 'High',
      estimatedTime: '2 days',
      progress: 75
    },
    {
      id: 'WO-2024-1198',
      type: 'Meter Replacement',
      location: 'Wari, Dhaka',
      priority: 'Medium',
      estimatedTime: '1 day',
      progress: 45
    },
    {
      id: 'WO-2024-1189',
      type: 'Line Extension',
      location: 'Mohammadpur, Dhaka',
      priority: 'Low',
      estimatedTime: '5 days',
      progress: 20
    }
  ];

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setIsLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'High': return 'text-red-600 bg-red-100 dark:bg-red-900/20';
      case 'Medium': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20';
      case 'Low': return 'text-green-600 bg-green-100 dark:bg-green-900/20';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Resolved': return 'text-green-600 bg-green-100 dark:bg-green-900/20';
      case 'In Progress': return 'text-blue-600 bg-blue-100 dark:bg-blue-900/20';
      case 'Scheduled': return 'text-purple-600 bg-purple-100 dark:bg-purple-900/20';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"
          />
          <p className="text-gray-600 dark:text-gray-400">Loading Distribution Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Distribution Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Monitor power distribution network across Bangladesh • {user.name}
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" size="sm">
            <FileText className="w-4 h-4 mr-2" />
            Export Report
          </Button>
          <Button size="sm">
            <Settings className="w-4 h-4 mr-2" />
            Configure
          </Button>
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 border-blue-200 dark:border-blue-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-600 dark:text-blue-400">Total Consumers</p>
                <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                  {(distributionMetrics.totalConsumers / 1000000).toFixed(1)}M
                </p>
                <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">+2.3% this month</p>
              </div>
              <Users className="w-8 h-8 text-blue-600 dark:text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 border-green-200 dark:border-green-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-600 dark:text-green-400">Power Distributed</p>
                <p className="text-2xl font-bold text-green-900 dark:text-green-100">
                  {distributionMetrics.powerDistributed.toLocaleString()} MW
                </p>
                <p className="text-xs text-green-600 dark:text-green-400 mt-1">Real-time</p>
              </div>
              <Power className="w-8 h-8 text-green-600 dark:text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 border-orange-200 dark:border-orange-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-600 dark:text-orange-400">System Losses</p>
                <p className="text-2xl font-bold text-orange-900 dark:text-orange-100">
                  {distributionMetrics.systemLosses}%
                </p>
                <p className="text-xs text-orange-600 dark:text-orange-400 mt-1">-0.3% vs target</p>
              </div>
              <TrendingUp className="w-8 h-8 text-orange-600 dark:text-orange-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 border-purple-200 dark:border-purple-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-600 dark:text-purple-400">System Reliability</p>
                <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">
                  {distributionMetrics.reliability}%
                </p>
                <p className="text-xs text-purple-600 dark:text-purple-400 mt-1">+0.1% this week</p>
              </div>
              <Shield className="w-8 h-8 text-purple-600 dark:text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="regional">Regional Analysis</TabsTrigger>
          <TabsTrigger value="infrastructure">Infrastructure</TabsTrigger>
          <TabsTrigger value="operations">Operations</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Load Demand Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-600" />
                  24-Hour Load Demand
                </CardTitle>
                <CardDescription>Real-time demand vs supply analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={loadDemandData}>
                    <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                    <XAxis dataKey="hour" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area 
                      type="monotone" 
                      dataKey="supply" 
                      stackId="1" 
                      stroke="#10b981" 
                      fill="#10b981" 
                      fillOpacity={0.6}
                      name="Supply (MW)"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="demand" 
                      stackId="2" 
                      stroke="#3b82f6" 
                      fill="#3b82f6" 
                      fillOpacity={0.6}
                      name="Demand (MW)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Transformer Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gauge className="w-5 h-5 text-purple-600" />
                  Transformer Status
                </CardTitle>
                <CardDescription>Distribution transformer health overview</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                        data={transformerStatusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {transformerStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    {transformerStatusData.map((item, index) => (
                      <div key={index} className="space-y-1">
                        <div className="flex items-center justify-center gap-2">
                          <div 
                            className="w-3 h-3 rounded-full" 
                            style={{ backgroundColor: item.color }}
                          />
                          <span className="text-sm font-medium">{item.name}</span>
                        </div>
                        <p className="text-lg font-bold">{item.value.toLocaleString()}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Incidents */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                Recent Incidents & Alerts
              </CardTitle>
              <CardDescription>Latest distribution network incidents</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentIncidents.map((incident) => (
                  <div key={incident.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-white dark:bg-gray-700 rounded-lg">
                        {incident.type === 'Power Outage' && <Zap className="w-5 h-5 text-red-600" />}
                        {incident.type === 'Transformer Fault' && <AlertCircle className="w-5 h-5 text-yellow-600" />}
                        {incident.type === 'Line Maintenance' && <Wrench className="w-5 h-5 text-blue-600" />}
                      </div>
                      <div>
                        <h4 className="font-semibold">{incident.type}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{incident.location}</p>
                        <p className="text-xs text-gray-500">Affected: {incident.affected.toLocaleString()} consumers</p>
                      </div>
                    </div>
                    <div className="text-right space-y-2">
                      <Badge className={getSeverityColor(incident.severity)}>
                        {incident.severity}
                      </Badge>
                      <Badge className={getStatusColor(incident.status)}>
                        {incident.status}
                      </Badge>
                      <p className="text-xs text-gray-500">{incident.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="regional" className="space-y-6">
          {/* Regional Performance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Map className="w-5 h-5 text-green-600" />
                Regional Distribution Performance
              </CardTitle>
              <CardDescription>Performance metrics by administrative division</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={distributionMetrics.regions}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="load" fill="#3b82f6" name="Load (MW)" />
                    <Bar dataKey="losses" fill="#ef4444" name="Losses (%)" />
                  </BarChart>
                </ResponsiveContainer>

                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={reliabilityData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="region" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="availability" stroke="#10b981" name="Availability (%)" />
                    <Line type="monotone" dataKey="mttr" stroke="#f59e0b" name="MTTR (minutes)" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="infrastructure" className="space-y-6">
          {/* Infrastructure Status */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <Gauge className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold mb-2">Distribution Transformers</h3>
                <p className="text-2xl font-bold text-blue-600">{distributionMetrics.transformers.total.toLocaleString()}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Total Units</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold mb-2">Operational</h3>
                <p className="text-2xl font-bold text-green-600">{distributionMetrics.transformers.operational.toLocaleString()}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">98.1% Availability</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-yellow-100 dark:bg-yellow-900/20 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <Clock className="w-6 h-6 text-yellow-600" />
                </div>
                <h3 className="font-semibold mb-2">Under Maintenance</h3>
                <p className="text-2xl font-bold text-yellow-600">{distributionMetrics.transformers.maintenance.toLocaleString()}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">1.5% of Total</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-red-100 dark:bg-red-900/20 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <XCircle className="w-6 h-6 text-red-600" />
                </div>
                <h3 className="font-semibold mb-2">Faulty</h3>
                <p className="text-2xl font-bold text-red-600">{distributionMetrics.transformers.faulty.toLocaleString()}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">0.4% of Total</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="operations" className="space-y-6">
          {/* Pending Work Orders */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wrench className="w-5 h-5 text-blue-600" />
                Pending Work Orders
              </CardTitle>
              <CardDescription>Current maintenance and installation requests</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingWorkOrders.map((order) => (
                  <div key={order.id} className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="font-semibold">{order.type}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{order.id} • {order.location}</p>
                      </div>
                      <div className="text-right">
                        <Badge className={order.priority === 'High' ? 'bg-red-100 text-red-800 dark:bg-red-900/20' : 
                                         order.priority === 'Medium' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20' : 
                                         'bg-green-100 text-green-800 dark:bg-green-900/20'}>
                          {order.priority}
                        </Badge>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">ETA: {order.estimatedTime}</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{order.progress}%</span>
                      </div>
                      <Progress value={order.progress} className="h-2" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DistributionDashboard;