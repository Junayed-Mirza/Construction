import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../ui/card";
import { Badge } from "../../ui/badge";
import { Button } from "../../ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../ui/tabs";
import { Progress } from "../../ui/progress";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { 
  Power, 
  TrendingUp, 
  Settings, 
  AlertTriangle, 
  Zap, 
  Gauge,
  MapPin,
  Calendar,
  FileText,
  Activity,
  Shield,
  Timer
} from 'lucide-react';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  department: string;
  powerPlant?: string;
  level: number;
  permissions: string[];
  accessToken: string;
}

interface TransmissionDashboardProps {
  user: User;
  isDark: boolean;
}

export default function TransmissionDashboard({ user, isDark }: TransmissionDashboardProps) {
  const [transmissionData, setTransmissionData] = useState<any[]>([]);
  const [substationStatus, setSubstationStatus] = useState<any[]>([]);
  const [realTimeMetrics, setRealTimeMetrics] = useState<any>({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Mock data - replace with real API calls
    setTransmissionData([
      { time: '00:00', load: 5200, voltage: 230, losses: 3.2 },
      { time: '06:00', load: 5800, voltage: 230, losses: 3.5 },
      { time: '12:00', load: 6500, voltage: 229, losses: 4.1 },
      { time: '18:00', load: 6850, voltage: 228, losses: 4.3 },
      { time: '24:00', load: 5600, voltage: 230, losses: 3.4 },
    ]);

    setSubstationStatus([
      { name: 'Ashuganj 230kV', voltage: 229.5, load: 85, capacity: 100, status: 'normal', temperature: 45 },
      { name: 'Dhaka 230kV', voltage: 228.2, load: 92, capacity: 100, status: 'warning', temperature: 52 },
      { name: 'Comilla 230kV', voltage: 230.1, load: 78, capacity: 100, status: 'normal', temperature: 41 },
      { name: 'Bogra 230kV', voltage: 229.8, load: 88, capacity: 100, status: 'normal', temperature: 47 },
      { name: 'Rangpur 230kV', voltage: 227.5, load: 75, capacity: 100, status: 'warning', temperature: 38 },
      { name: 'Sylhet 230kV', voltage: 230.3, load: 82, capacity: 100, status: 'normal', temperature: 43 },
    ]);

    setRealTimeMetrics({
      totalTransmission: 6330,
      systemVoltage: 229.2,
      transmissionLosses: 3.8,
      circuitAvailability: 98.2,
      loadFactor: 82.5,
      faultIncidents: 2,
    });

    setIsLoading(false);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'bg-green-500';
      case 'warning': return 'bg-yellow-500';
      case 'maintenance': return 'bg-blue-500';
      case 'fault': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'normal': return { variant: 'default', text: 'Normal' };
      case 'warning': return { variant: 'secondary', text: 'Warning' };
      case 'maintenance': return { variant: 'outline', text: 'Maintenance' };
      case 'fault': return { variant: 'destructive', text: 'Fault' };
      default: return { variant: 'outline', text: 'Unknown' };
    }
  };

  const voltageRanges = [
    { name: '220-225 kV', count: 2, percentage: 12 },
    { name: '225-230 kV', count: 8, percentage: 47 },
    { name: '230-235 kV', count: 7, percentage: 41 },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-blue-50/50 to-purple-50/50 dark:from-gray-900 dark:to-purple-900 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Transmission Department</h1>
          <p className="text-gray-600 dark:text-gray-300">Welcome back, {user.name}</p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="px-3 py-1">
            <Power className="w-4 h-4 mr-2" />
            {realTimeMetrics.totalTransmission} MW
          </Badge>
          <Badge variant="outline" className="px-3 py-1">
            <Zap className="w-4 h-4 mr-2" />
            {realTimeMetrics.systemVoltage} kV
          </Badge>
        </div>
      </div>

      {/* Real-Time Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Transmission</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{realTimeMetrics.totalTransmission} MW</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 inline mr-1" />
              +1.8% from yesterday
            </p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">System Voltage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{realTimeMetrics.systemVoltage} kV</div>
            <p className="text-xs text-muted-foreground">Within normal range</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Transmission Losses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{realTimeMetrics.transmissionLosses}%</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 inline mr-1 text-green-500" />
              -0.2% improvement
            </p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Circuit Availability</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{realTimeMetrics.circuitAvailability}%</div>
            <p className="text-xs text-muted-foreground">Excellent performance</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Load Factor</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-indigo-600">{realTimeMetrics.loadFactor}%</div>
            <p className="text-xs text-muted-foreground">Optimal utilization</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Fault Incidents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{realTimeMetrics.faultIncidents}</div>
            <p className="text-xs text-muted-foreground">Last 24 hours</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="substations">Substations</TabsTrigger>
          <TabsTrigger value="lines">Transmission Lines</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Voltage Distribution */}
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Voltage Level Distribution</CardTitle>
                <CardDescription>Current voltage ranges across network</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {voltageRanges.map((range) => (
                    <div key={range.name} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-4 h-4 bg-blue-500 rounded-full" />
                        <span className="text-sm font-medium">{range.name}</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-24 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div
                            className="bg-blue-500 h-2 rounded-full"
                            style={{ width: `${range.percentage}%` }}
                          />
                        </div>
                        <span className="text-sm text-muted-foreground">{range.count} substations</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Transmission Load Trend */}
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Transmission Load Trend</CardTitle>
                <CardDescription>24-hour load and voltage pattern</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={transmissionData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Line yAxisId="left" type="monotone" dataKey="load" stroke="#3B82F6" strokeWidth={2} />
                    <Line yAxisId="right" type="monotone" dataKey="voltage" stroke="#8B5CF6" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* System Performance Metrics */}
          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
            <CardHeader>
              <CardTitle>System Performance Metrics</CardTitle>
              <CardDescription>Key performance indicators for transmission network</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-lg flex items-center justify-center">
                    <Shield className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">99.8%</div>
                    <div className="text-sm text-muted-foreground">System Reliability</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                    <Gauge className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">2.3 min</div>
                    <div className="text-sm text-muted-foreground">Avg. Outage Duration</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/20 rounded-lg flex items-center justify-center">
                    <Activity className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">95.4%</div>
                    <div className="text-sm text-muted-foreground">Equipment Health</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/20 rounded-lg flex items-center justify-center">
                    <Timer className="w-6 h-6 text-orange-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">4.2 sec</div>
                    <div className="text-sm text-muted-foreground">Fault Clearing Time</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="substations" className="space-y-4">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {substationStatus.map((substation, index) => (
              <motion.div
                key={substation.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                    <div>
                      <CardTitle className="text-lg">{substation.name}</CardTitle>
                      <CardDescription>Substation Status</CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${getStatusColor(substation.status)}`} />
                      <Badge variant={getStatusBadge(substation.status).variant}>
                        {getStatusBadge(substation.status).text}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">{substation.voltage} kV</div>
                        <p className="text-xs text-muted-foreground">Voltage Level</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">{substation.load}%</div>
                        <p className="text-xs text-muted-foreground">Load</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-orange-600">{substation.temperature}°C</div>
                        <p className="text-xs text-muted-foreground">Temperature</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Load Capacity</span>
                        <span>{substation.load}/{substation.capacity}%</span>
                      </div>
                      <Progress value={substation.load} className="h-2" />
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        <Settings className="w-4 h-4 mr-2" />
                        Control
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        <MapPin className="w-4 h-4 mr-2" />
                        Location
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="lines" className="space-y-4">
          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
            <CardHeader>
              <CardTitle>Transmission Line Status</CardTitle>
              <CardDescription>Current status of major transmission lines</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[
                    { name: 'Ashuganj-Comilla 230kV', length: '45 km', status: 'operational', load: 78 },
                    { name: 'Dhaka-Tongi 230kV', length: '25 km', status: 'operational', load: 92 },
                    { name: 'Bogra-Rangpur 230kV', length: '120 km', status: 'maintenance', load: 0 },
                    { name: 'Sylhet-Comilla 230kV', length: '180 km', status: 'operational', load: 65 },
                    { name: 'Khulna-Barisal 230kV', length: '85 km', status: 'operational', load: 73 },
                    { name: 'Chittagong-Comilla 230kV', length: '95 km', status: 'warning', load: 88 },
                  ].map((line) => (
                    <div key={line.name} className="p-4 border rounded-lg bg-white/50 dark:bg-gray-800/50">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium text-sm">{line.name}</h4>
                        <Badge 
                          variant={line.status === 'operational' ? 'default' : line.status === 'warning' ? 'secondary' : 'outline'}
                          className="text-xs"
                        >
                          {line.status}
                        </Badge>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Length: {line.length}</span>
                          <span>Load: {line.load}%</span>
                        </div>
                        {line.status === 'operational' && (
                          <Progress value={line.load} className="h-1" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maintenance" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Scheduled Maintenance</CardTitle>
                <CardDescription>Upcoming maintenance activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Power className="w-5 h-5 text-yellow-600" />
                      <div>
                        <div className="font-medium">Bogra-Rangpur Line</div>
                        <div className="text-sm text-muted-foreground">Conductor replacement</div>
                      </div>
                    </div>
                    <Badge variant="outline">Tomorrow</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Settings className="w-5 h-5 text-blue-600" />
                      <div>
                        <div className="font-medium">Dhaka Substation</div>
                        <div className="text-sm text-muted-foreground">Transformer inspection</div>
                      </div>
                    </div>
                    <Badge variant="outline">3 days</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Shield className="w-5 h-5 text-green-600" />
                      <div>
                        <div className="font-medium">Protection System</div>
                        <div className="text-sm text-muted-foreground">Relay testing</div>
                      </div>
                    </div>
                    <Badge variant="outline">1 week</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Recent Activities</CardTitle>
                <CardDescription>Completed maintenance and repairs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <div>
                        <div className="font-medium text-sm">Sylhet Substation</div>
                        <div className="text-xs text-muted-foreground">Completed transformer maintenance</div>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground">2 days ago</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <div>
                        <div className="font-medium text-sm">Chittagong Line</div>
                        <div className="text-xs text-muted-foreground">Insulator replacement completed</div>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground">1 week ago</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>System Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <Button className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Daily Operations Report
                </Button>
                <Button variant="outline" className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Load Analysis Report
                </Button>
                <Button variant="outline" className="w-full">
                  <FileText className="w-4 h-4 mr-2" />
                  Voltage Profile Report
                </Button>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Maintenance Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <Button className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Equipment Status
                </Button>
                <Button variant="outline" className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Maintenance Schedule
                </Button>
                <Button variant="outline" className="w-full">
                  <FileText className="w-4 h-4 mr-2" />
                  Fault Analysis
                </Button>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Performance Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <Button variant="outline" className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Reliability Metrics
                </Button>
                <Button variant="outline" className="w-full mb-2">
                  <Calendar className="w-4 h-4 mr-2" />
                  Monthly Summary
                </Button>
                <Button variant="outline" className="w-full">
                  <Activity className="w-4 h-4 mr-2" />
                  System Health Report
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}