import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Users, 
  UserPlus, 
  UserMinus,
  GraduationCap,
  Calendar,
  Clock,
  Award,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Settings,
  FileText,
  Download,
  Mail,
  Phone,
  MapPin,
  Briefcase,
  Target,
  BarChart3
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../ui/card";
import { Button } from "../../ui/button";
import { Badge } from "../../ui/badge";
import { Progress } from "../../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "../../ui/avatar";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface User {
  id: string;
  name: string;
  role: string;
  department: string;
}

interface HumanResourcesDashboardProps {
  user: User;
  isDark: boolean;
}

const HumanResourcesDashboard: React.FC<HumanResourcesDashboardProps> = ({ user, isDark }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('monthly');
  const [selectedMetric, setSelectedMetric] = useState('overview');

  // Mock HR data
  const hrMetrics = {
    totalEmployees: 38750,
    activeEmployees: 37820,
    newHires: 145,
    turnoverRate: 3.2, // %
    averageAge: 38.5,
    retentionRate: 96.8, // %
    trainingCompletion: 87.5, // %
    employeeSatisfaction: 8.2 // out of 10
  };

  // Employee distribution by department
  const departmentDistribution = [
    { department: 'Generation', employees: 12500, percentage: 32.3, color: '#3b82f6' },
    { department: 'Transmission', employees: 8200, percentage: 21.2, color: '#10b981' },
    { department: 'Distribution', employees: 10800, percentage: 27.9, color: '#f59e0b' },
    { department: 'Engineering', employees: 3200, percentage: 8.3, color: '#8b5cf6' },
    { department: 'Administration', employees: 2500, percentage: 6.5, color: '#ef4444' },
    { department: 'Finance', employees: 1550, percentage: 4.0, color: '#06b6d4' }
  ];

  // Employee hierarchy breakdown
  const hierarchyData = [
    { level: 'Executive', count: 85, percentage: 0.2 },
    { level: 'Senior Management', count: 420, percentage: 1.1 },
    { level: 'Middle Management', count: 1850, percentage: 4.8 },
    { level: 'Supervisory', count: 4200, percentage: 10.8 },
    { level: 'Technical Staff', count: 18500, percentage: 47.7 },
    { level: 'Administrative', count: 6800, percentage: 17.5 },
    { level: 'Support Staff', count: 6895, percentage: 17.8 }
  ];

  // Monthly hiring trends
  const hiringTrends = [
    { month: 'Jan', hires: 125, terminations: 85, netChange: 40 },
    { month: 'Feb', hires: 110, terminations: 92, netChange: 18 },
    { month: 'Mar', hires: 135, terminations: 88, netChange: 47 },
    { month: 'Apr', hires: 145, terminations: 95, netChange: 50 },
    { month: 'May', hires: 160, terminations: 78, netChange: 82 },
    { month: 'Jun', hires: 155, terminations: 102, netChange: 53 },
    { month: 'Jul', hires: 170, terminations: 115, netChange: 55 },
    { month: 'Aug', hires: 165, terminations: 98, netChange: 67 },
    { month: 'Sep', hires: 150, terminations: 105, netChange: 45 },
    { month: 'Oct', hires: 140, terminations: 110, netChange: 30 },
    { month: 'Nov', hires: 145, terminations: 95, netChange: 50 },
    { month: 'Dec', hires: 155, terminations: 88, netChange: 67 }
  ];

  // Training programs
  const trainingPrograms = [
    {
      id: 'TRN-2024-001',
      name: 'Safety & Compliance Training',
      participants: 2500,
      completed: 2187,
      duration: '40 hours',
      status: 'Ongoing',
      completionRate: 87.5
    },
    {
      id: 'TRN-2024-002',
      name: 'Digital Skills Enhancement',
      participants: 1800,
      completed: 1620,
      duration: '32 hours',
      status: 'Ongoing',
      completionRate: 90.0
    },
    {
      id: 'TRN-2024-003',
      name: 'Leadership Development',
      participants: 450,
      completed: 423,
      duration: '60 hours',
      status: 'Completed',
      completionRate: 94.0
    }
  ];

  // Employee performance distribution
  const performanceData = [
    { rating: 'Outstanding', count: 3875, percentage: 10, color: '#10b981' },
    { rating: 'Exceeds Expectations', count: 11625, percentage: 30, color: '#3b82f6' },
    { rating: 'Meets Expectations', count: 19375, percentage: 50, color: '#f59e0b' },
    { rating: 'Below Expectations', count: 3100, percentage: 8, color: '#ef4444' },
    { rating: 'Needs Improvement', count: 775, percentage: 2, color: '#6b7280' }
  ];

  // Recent HR activities
  const recentActivities = [
    {
      id: 1,
      type: 'New Hire',
      employee: 'Md. Rahman Ahmed',
      position: 'Senior Engineer',
      department: 'Generation',
      date: '2024-12-10',
      status: 'Completed'
    },
    {
      id: 2,
      type: 'Promotion',
      employee: 'Ms. Fatima Khatun',
      position: 'Assistant General Manager',
      department: 'Transmission',
      date: '2024-12-09',
      status: 'Completed'
    },
    {
      id: 3,
      type: 'Training',
      employee: 'Eng. Karim Hassan',
      position: 'Training Completion',
      department: 'Distribution',
      date: '2024-12-08',
      status: 'Completed'
    }
  ];

  // Upcoming events
  const upcomingEvents = [
    {
      id: 1,
      title: 'Annual Performance Review',
      date: '2024-12-15',
      participants: 1250,
      type: 'Review',
      department: 'All'
    },
    {
      id: 2,
      title: 'Safety Training Workshop',
      date: '2024-12-18',
      participants: 500,
      type: 'Training',
      department: 'Generation'
    },
    {
      id: 3,
      title: 'New Employee Orientation',
      date: '2024-12-20',
      participants: 45,
      type: 'Orientation',
      department: 'All'
    }
  ];

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setIsLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed': return 'text-green-600 bg-green-100 dark:bg-green-900/20';
      case 'Ongoing': return 'text-blue-600 bg-blue-100 dark:bg-blue-900/20';
      case 'Pending': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'New Hire': return 'text-green-600 bg-green-100 dark:bg-green-900/20';
      case 'Promotion': return 'text-blue-600 bg-blue-100 dark:bg-blue-900/20';
      case 'Training': return 'text-purple-600 bg-purple-100 dark:bg-purple-900/20';
      case 'Review': return 'text-orange-600 bg-orange-100 dark:bg-orange-900/20';
      case 'Orientation': return 'text-cyan-600 bg-cyan-100 dark:bg-cyan-900/20';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"
          />
          <p className="text-gray-600 dark:text-gray-400">Loading HR Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Human Resources Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Workforce management and employee analytics • {user.name}
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            HR Report
          </Button>
          <Button size="sm">
            <Settings className="w-4 h-4 mr-2" />
            Configure
          </Button>
        </div>
      </div>

      {/* Key HR Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 border-blue-200 dark:border-blue-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-600 dark:text-blue-400">Total Employees</p>
                <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                  {hrMetrics.totalEmployees.toLocaleString()}
                </p>
                <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">+{hrMetrics.newHires} this month</p>
              </div>
              <Users className="w-8 h-8 text-blue-600 dark:text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 border-green-200 dark:border-green-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-600 dark:text-green-400">Retention Rate</p>
                <p className="text-2xl font-bold text-green-900 dark:text-green-100">
                  {hrMetrics.retentionRate}%
                </p>
                <p className="text-xs text-green-600 dark:text-green-400 mt-1">+0.5% vs last year</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 border-purple-200 dark:border-purple-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-600 dark:text-purple-400">Training Completion</p>
                <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">
                  {hrMetrics.trainingCompletion}%
                </p>
                <p className="text-xs text-purple-600 dark:text-purple-400 mt-1">+2.3% this quarter</p>
              </div>
              <GraduationCap className="w-8 h-8 text-purple-600 dark:text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 border-orange-200 dark:border-orange-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-600 dark:text-orange-400">Employee Satisfaction</p>
                <p className="text-2xl font-bold text-orange-900 dark:text-orange-100">
                  {hrMetrics.employeeSatisfaction}/10
                </p>
                <p className="text-xs text-orange-600 dark:text-orange-400 mt-1">+0.3 vs last survey</p>
              </div>
              <Award className="w-8 h-8 text-orange-600 dark:text-orange-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="workforce">Workforce</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="training">Training</TabsTrigger>
          <TabsTrigger value="activities">Activities</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Department Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-blue-600" />
                  Employee Distribution by Department
                </CardTitle>
                <CardDescription>Workforce allocation across departments</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={departmentDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="employees"
                    >
                      {departmentDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [value.toLocaleString(), 'Employees']} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="grid grid-cols-2 gap-2 mt-4">
                  {departmentDistribution.map((dept, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: dept.color }}
                      />
                      <span className="text-sm">{dept.department}</span>
                      <span className="text-xs text-gray-500">({dept.percentage}%)</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Hiring Trends */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  Monthly Hiring Trends
                </CardTitle>
                <CardDescription>New hires vs terminations over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={hiringTrends}>
                    <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area 
                      type="monotone" 
                      dataKey="hires" 
                      stackId="1" 
                      stroke="#10b981" 
                      fill="#10b981" 
                      fillOpacity={0.6}
                      name="New Hires"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="terminations" 
                      stackId="2" 
                      stroke="#ef4444" 
                      fill="#ef4444" 
                      fillOpacity={0.6}
                      name="Terminations"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activities */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-purple-600" />
                Recent HR Activities
              </CardTitle>
              <CardDescription>Latest employee activities and changes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-white dark:bg-gray-700 rounded-lg">
                        {activity.type === 'New Hire' && <UserPlus className="w-5 h-5 text-green-600" />}
                        {activity.type === 'Promotion' && <TrendingUp className="w-5 h-5 text-blue-600" />}
                        {activity.type === 'Training' && <GraduationCap className="w-5 h-5 text-purple-600" />}
                      </div>
                      <div>
                        <h4 className="font-semibold">{activity.employee}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{activity.position}</p>
                        <p className="text-xs text-gray-500">{activity.department} • {activity.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className={getTypeColor(activity.type)}>
                        {activity.type}
                      </Badge>
                      <Badge className={getStatusColor(activity.status)} variant="outline">
                        {activity.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="workforce" className="space-y-6">
          {/* Hierarchy Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-blue-600" />
                Employee Hierarchy Distribution
              </CardTitle>
              <CardDescription>Workforce breakdown by organizational level</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {hierarchyData.map((level, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">{level.level}</span>
                      <div className="text-right">
                        <span className="font-bold">{level.count.toLocaleString()}</span>
                        <span className="text-sm text-gray-600 dark:text-gray-400 ml-2">({level.percentage}%)</span>
                      </div>
                    </div>
                    <Progress value={level.percentage} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          {/* Performance Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-gold-600" />
                Employee Performance Distribution
              </CardTitle>
              <CardDescription>Annual performance review ratings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="rating" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#3b82f6" />
                  </BarChart>
                </ResponsiveContainer>

                <div className="space-y-4">
                  {performanceData.map((perf, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-4 h-4 rounded-full" 
                          style={{ backgroundColor: perf.color }}
                        />
                        <span className="font-medium">{perf.rating}</span>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">{perf.count.toLocaleString()}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{perf.percentage}%</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="training" className="space-y-6">
          {/* Training Programs */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-purple-600" />
                Active Training Programs
              </CardTitle>
              <CardDescription>Current training initiatives and progress</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {trainingPrograms.map((program) => (
                  <div key={program.id} className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="font-semibold">{program.name}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{program.id} • {program.duration}</p>
                      </div>
                      <Badge className={getStatusColor(program.status)}>
                        {program.status}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress: {program.completed}/{program.participants} participants</span>
                        <span>{program.completionRate}%</span>
                      </div>
                      <Progress value={program.completionRate} className="h-2" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activities" className="space-y-6">
          {/* Upcoming Events */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-600" />
                Upcoming HR Events
              </CardTitle>
              <CardDescription>Scheduled activities and deadlines</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingEvents.map((event) => (
                  <div key={event.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-white dark:bg-gray-700 rounded-lg">
                        <Calendar className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{event.title}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{event.department} • {event.participants} participants</p>
                        <p className="text-xs text-gray-500">{event.date}</p>
                      </div>
                    </div>
                    <Badge className={getTypeColor(event.type)}>
                      {event.type}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default HumanResourcesDashboard;