import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../ui/card";
import { Badge } from "../../ui/badge";
import { Button } from "../../ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../ui/tabs";
import { Progress } from "../../ui/progress";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { 
  Zap, 
  TrendingUp, 
  Settings, 
  AlertTriangle, 
  Factory, 
  Gauge,
  Users,
  Calendar,
  FileText,
  Activity
} from 'lucide-react';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  department: string;
  powerPlant?: string;
  level: number;
  permissions: string[];
  accessToken: string;
}

interface GenerationDashboardProps {
  user: User;
  isDark: boolean;
}

export default function GenerationDashboard({ user, isDark }: GenerationDashboardProps) {
  const [generationData, setGenerationData] = useState<any[]>([]);
  const [plantStatus, setPlantStatus] = useState<any[]>([]);
  const [realTimeMetrics, setRealTimeMetrics] = useState<any>({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Mock data - replace with real API calls
    setGenerationData([
      { time: '00:00', coal: 2400, gas: 1200, hydro: 230, renewable: 110 },
      { time: '06:00', coal: 2600, gas: 1400, hydro: 230, renewable: 120 },
      { time: '12:00', coal: 3200, gas: 1800, hydro: 230, renewable: 130 },
      { time: '18:00', coal: 3400, gas: 2000, hydro: 230, renewable: 125 },
      { time: '24:00', coal: 2800, gas: 1600, hydro: 230, renewable: 115 },
    ]);

    setPlantStatus([
      { name: 'Barapukuria Coal', capacity: 525, generation: 480, efficiency: 91.4, status: 'optimal' },
      { name: 'Payra Coal', capacity: 1320, generation: 1250, efficiency: 94.7, status: 'optimal' },
      { name: 'Rampal Coal', capacity: 1320, generation: 1200, efficiency: 90.9, status: 'maintenance' },
      { name: 'Rooppur Nuclear', capacity: 2400, generation: 2300, efficiency: 95.8, status: 'optimal' },
      { name: 'Matarbari Coal', capacity: 1200, generation: 1100, efficiency: 91.7, status: 'optimal' },
    ]);

    setRealTimeMetrics({
      totalGeneration: 6330,
      peakDemand: 6850,
      systemFrequency: 49.98,
      voltageStability: 98.5,
      reserveMargin: 520,
      co2Emissions: 2.45,
    });

    setIsLoading(false);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'optimal': return 'bg-green-500';
      case 'warning': return 'bg-yellow-500';
      case 'maintenance': return 'bg-blue-500';
      case 'critical': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const pieData = [
    { name: 'Coal', value: 3200, color: '#8B5CF6' },
    { name: 'Gas', value: 1800, color: '#10B981' },
    { name: 'Hydro', value: 230, color: '#3B82F6' },
    { name: 'Renewable', value: 130, color: '#F59E0B' },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-blue-50/50 to-green-50/50 dark:from-gray-900 dark:to-blue-900 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Generation Department</h1>
          <p className="text-gray-600 dark:text-gray-300">Welcome back, {user.name}</p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="px-3 py-1">
            <Zap className="w-4 h-4 mr-2" />
            {realTimeMetrics.totalGeneration} MW
          </Badge>
          <Badge variant="outline" className="px-3 py-1">
            <Activity className="w-4 h-4 mr-2" />
            {realTimeMetrics.systemFrequency} Hz
          </Badge>
        </div>
      </div>

      {/* Real-Time Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Generation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{realTimeMetrics.totalGeneration} MW</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 inline mr-1" />
              +2.4% from yesterday
            </p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Peak Demand</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{realTimeMetrics.peakDemand} MW</div>
            <p className="text-xs text-muted-foreground">Expected at 20:00</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">System Frequency</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{realTimeMetrics.systemFrequency} Hz</div>
            <p className="text-xs text-muted-foreground">Within normal range</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Voltage Stability</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{realTimeMetrics.voltageStability}%</div>
            <p className="text-xs text-muted-foreground">Excellent stability</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Reserve Margin</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-indigo-600">{realTimeMetrics.reserveMargin} MW</div>
            <p className="text-xs text-muted-foreground">7.6% of peak demand</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">CO₂ Emissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{realTimeMetrics.co2Emissions} kt/hr</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 inline mr-1 text-green-500" />
              -1.2% from last month
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="plants">Power Plants</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Generation Mix Chart */}
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Generation Mix (Current Hour)</CardTitle>
                <CardDescription>Power generation by fuel type</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value} MW`, 'Generation']} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Daily Generation Trend */}
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Daily Generation Trend</CardTitle>
                <CardDescription>24-hour generation pattern</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={generationData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="coal" stroke="#8B5CF6" strokeWidth={2} />
                    <Line type="monotone" dataKey="gas" stroke="#10B981" strokeWidth={2} />
                    <Line type="monotone" dataKey="hydro" stroke="#3B82F6" strokeWidth={2} />
                    <Line type="monotone" dataKey="renewable" stroke="#F59E0B" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="plants" className="space-y-4">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {plantStatus.map((plant, index) => (
              <motion.div
                key={plant.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                    <div>
                      <CardTitle className="text-lg">{plant.name}</CardTitle>
                      <CardDescription>{plant.capacity} MW Capacity</CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${getStatusColor(plant.status)}`} />
                      <Badge variant="secondary">{plant.status}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">{plant.generation} MW</div>
                        <p className="text-xs text-muted-foreground">Current Generation</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">{plant.efficiency}%</div>
                        <p className="text-xs text-muted-foreground">Efficiency</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-orange-600">{((plant.generation / plant.capacity) * 100).toFixed(1)}%</div>
                        <p className="text-xs text-muted-foreground">Load Factor</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Generation Progress</span>
                        <span>{plant.generation}/{plant.capacity} MW</span>
                      </div>
                      <Progress value={(plant.generation / plant.capacity) * 100} className="h-2" />
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        <Settings className="w-4 h-4 mr-2" />
                        Control
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        <FileText className="w-4 h-4 mr-2" />
                        Reports
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
            <CardHeader>
              <CardTitle>Plant Performance Comparison</CardTitle>
              <CardDescription>Efficiency and availability metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={plantStatus}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="efficiency" fill="#8B5CF6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maintenance" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Scheduled Maintenance</CardTitle>
                <CardDescription>Upcoming maintenance activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Factory className="w-5 h-5 text-yellow-600" />
                      <div>
                        <div className="font-medium">Rampal Coal Plant</div>
                        <div className="text-sm text-muted-foreground">Turbine maintenance</div>
                      </div>
                    </div>
                    <Badge variant="outline">2 days</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Settings className="w-5 h-5 text-blue-600" />
                      <div>
                        <div className="font-medium">Barapukuria Plant</div>
                        <div className="text-sm text-muted-foreground">Routine inspection</div>
                      </div>
                    </div>
                    <Badge variant="outline">1 week</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Alerts & Issues</CardTitle>
                <CardDescription>Active system alerts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <AlertTriangle className="w-5 h-5 text-red-600" />
                      <div>
                        <div className="font-medium">High Vibration</div>
                        <div className="text-sm text-muted-foreground">Unit 2 - Payra Plant</div>
                      </div>
                    </div>
                    <Badge variant="destructive">Critical</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Gauge className="w-5 h-5 text-orange-600" />
                      <div>
                        <div className="font-medium">Temperature Warning</div>
                        <div className="text-sm text-muted-foreground">Cooling system - Matarbari</div>
                      </div>
                    </div>
                    <Badge variant="outline">Warning</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Daily Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <Button className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Generation Summary
                </Button>
                <Button variant="outline" className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Plant Status Report
                </Button>
                <Button variant="outline" className="w-full">
                  <FileText className="w-4 h-4 mr-2" />
                  Efficiency Analysis
                </Button>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Monthly Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <Button className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Performance Review
                </Button>
                <Button variant="outline" className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Maintenance Summary
                </Button>
                <Button variant="outline" className="w-full">
                  <FileText className="w-4 h-4 mr-2" />
                  Cost Analysis
                </Button>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Custom Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <Button variant="outline" className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Create Report
                </Button>
                <Button variant="outline" className="w-full mb-2">
                  <Calendar className="w-4 h-4 mr-2" />
                  Schedule Report
                </Button>
                <Button variant="outline" className="w-full">
                  <Users className="w-4 h-4 mr-2" />
                  Share Report
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}