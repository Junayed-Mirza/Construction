import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Target, 
  TrendingUp, 
  Calendar,
  MapPin,
  Lightbulb,
  BarChart3,
  PieChart,
  AlertTriangle,
  CheckCircle,
  Clock,
  Settings,
  FileText,
  Download,
  Zap,
  Building,
  Gauge,
  DollarSign,
  Users,
  Activity
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../ui/card";
import { Button } from "../../ui/button";
import { Badge } from "../../ui/badge";
import { Progress } from "../../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../ui/tabs";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart as RechartsPieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface User {
  id: string;
  name: string;
  role: string;
  department: string;
}

interface PlanningDevelopmentDashboardProps {
  user: User;
  isDark: boolean;
}

const PlanningDevelopmentDashboard: React.FC<PlanningDevelopmentDashboardProps> = ({ user, isDark }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('5year');
  const [selectedRegion, setSelectedRegion] = useState('National');

  // Mock planning data
  const planningMetrics = {
    totalProjects: 87,
    activeProjects: 42,
    completedProjects: 28,
    plannedCapacity: 15500, // MW
    currentCapacity: 12800, // MW
    targetCapacity: 24000, // MW by 2030
    totalInvestment: 850000000000, // BDT 850 billion
    budgetUtilization: 73.5, // %
    timelineAdherence: 68.2 // %
  };

  // Capacity expansion plan (5-year forecast)
  const capacityPlan = [
    { year: '2024', thermal: 8500, renewable: 2200, nuclear: 1200, hydro: 230, total: 12130 },
    { year: '2025', thermal: 9200, renewable: 3100, nuclear: 1200, hydro: 250, total: 13750 },
    { year: '2026', thermal: 10100, renewable: 4200, nuclear: 2400, hydro: 250, total: 16950 },
    { year: '2027', thermal: 10800, renewable: 5500, nuclear: 2400, hydro: 280, total: 18980 },
    { year: '2028', thermal: 11200, renewable: 7200, nuclear: 2400, hydro: 300, total: 21100 },
    { year: '2029', thermal: 11500, renewable: 8800, nuclear: 2400, hydro: 320, total: 23020 },
    { year: '2030', thermal: 11800, renewable: 10500, nuclear: 2400, hydro: 350, total: 25050 }
  ];

  // Regional development projects
  const regionalProjects = [
    { region: 'Dhaka', projects: 15, capacity: 3200, investment: 180000, status: 'On Track' },
    { region: 'Chittagong', projects: 12, capacity: 2800, investment: 150000, status: 'On Track' },
    { region: 'Khulna', projects: 8, capacity: 1900, investment: 95000, status: 'Delayed' },
    { region: 'Rajshahi', projects: 10, capacity: 2100, investment: 110000, status: 'On Track' },
    { region: 'Sylhet', projects: 6, capacity: 1200, investment: 65000, status: 'On Track' },
    { region: 'Rangpur', projects: 7, capacity: 1400, investment: 72000, status: 'Ahead' },
    { region: 'Barisal', projects: 4, capacity: 800, investment: 42000, status: 'On Track' }
  ];

  // Project categories distribution
  const projectCategories = [
    { name: 'Power Generation', projects: 28, percentage: 32.2, color: '#3b82f6' },
    { name: 'Transmission', projects: 18, percentage: 20.7, color: '#10b981' },
    { name: 'Distribution', projects: 22, percentage: 25.3, color: '#f59e0b' },
    { name: 'Renewable Energy', projects: 12, percentage: 13.8, color: '#8b5cf6' },
    { name: 'Infrastructure', projects: 7, percentage: 8.0, color: '#ef4444' }
  ];

  // Investment allocation by source
  const investmentSources = [
    { source: 'Government Budget', amount: 340000, percentage: 40, color: '#3b82f6' },
    { source: 'Foreign Investment', amount: 255000, percentage: 30, color: '#10b981' },
    { source: 'Development Partners', amount: 170000, percentage: 20, color: '#f59e0b' },
    { source: 'Private Sector', amount: 85000, percentage: 10, color: '#8b5cf6' }
  ];

  // Major ongoing projects
  const majorProjects = [
    {
      id: 'PROJ-2024-001',
      name: 'Rooppur Nuclear Power Plant',
      capacity: 2400, // MW
      investment: 127000, // Million BDT
      progress: 85,
      startDate: '2017-11-30',
      expectedCompletion: '2025-12-31',
      status: 'On Track',
      region: 'Pabna'
    },
    {
      id: 'PROJ-2024-002',
      name: 'Matarbari Coal Power Plant',
      capacity: 1200,
      investment: 46500,
      progress: 78,
      startDate: '2020-06-15',
      expectedCompletion: '2026-06-30',
      status: 'On Track',
      region: 'Cox\'s Bazar'
    },
    {
      id: 'PROJ-2024-003',
      name: 'Payra Coal Power Plant',
      capacity: 1320,
      investment: 19500,
      progress: 92,
      startDate: '2018-01-01',
      expectedCompletion: '2024-12-31',
      status: 'Ahead',
      region: 'Patuakhali'
    },
    {
      id: 'PROJ-2024-004',
      name: 'Chattogram-Cox\'s Bazar Transmission Line',
      capacity: 400, // kV
      investment: 8750,
      progress: 65,
      startDate: '2022-03-01',
      expectedCompletion: '2025-09-30',
      status: 'On Track',
      region: 'Chittagong'
    }
  ];

  // Strategic initiatives
  const strategicInitiatives = [
    {
      initiative: 'Renewable Energy Target',
      target: '40% by 2041',
      current: '4.2%',
      progress: 10.5,
      priority: 'High'
    },
    {
      initiative: 'Universal Electricity Access',
      target: '100% by 2025',
      current: '96.2%',
      progress: 96.2,
      priority: 'Critical'
    },
    {
      initiative: 'System Loss Reduction',
      target: '6% by 2030',
      current: '8.5%',
      progress: 62.5,
      priority: 'High'
    },
    {
      initiative: 'Grid Modernization',
      target: '80% Smart Grid by 2030',
      current: '15%',
      progress: 18.75,
      priority: 'Medium'
    }
  ];

  // Technology roadmap
  const technologyRoadmap = [
    { technology: 'Coal', current: 45, target2030: 35, trend: 'decreasing' },
    { technology: 'Gas', current: 35, target2030: 25, trend: 'decreasing' },
    { technology: 'Nuclear', current: 0, target2030: 10, trend: 'increasing' },
    { technology: 'Solar', current: 2, target2030: 15, trend: 'increasing' },
    { technology: 'Wind', current: 1, target2030: 8, trend: 'increasing' },
    { technology: 'Hydro', current: 2, target2030: 3, trend: 'stable' },
    { technology: 'Others', current: 15, target2030: 4, trend: 'decreasing' }
  ];

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setIsLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'On Track': return 'text-green-600 bg-green-100 dark:bg-green-900/20';
      case 'Ahead': return 'text-blue-600 bg-blue-100 dark:bg-blue-900/20';
      case 'Delayed': return 'text-red-600 bg-red-100 dark:bg-red-900/20';
      case 'Critical': return 'text-red-600 bg-red-100 dark:bg-red-900/20';
      case 'High': return 'text-orange-600 bg-orange-100 dark:bg-orange-900/20';
      case 'Medium': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20';
    }
  };

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000) {
      return `৳${(amount / 1000000).toFixed(1)}B`;
    } else if (amount >= 1000) {
      return `৳${(amount / 1000).toFixed(1)}M`;
    }
    return `৳${amount.toFixed(0)}`;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"
          />
          <p className="text-gray-600 dark:text-gray-400">Loading Planning Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Planning & Development Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Strategic planning and infrastructure development • {user.name}
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Master Plan
          </Button>
          <Button size="sm">
            <Settings className="w-4 h-4 mr-2" />
            Configure
          </Button>
        </div>
      </div>

      {/* Key Planning Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 border-blue-200 dark:border-blue-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-600 dark:text-blue-400">Active Projects</p>
                <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                  {planningMetrics.activeProjects}
                </p>
                <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">of {planningMetrics.totalProjects} total</p>
              </div>
              <Building className="w-8 h-8 text-blue-600 dark:text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 border-green-200 dark:border-green-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-600 dark:text-green-400">Planned Capacity</p>
                <p className="text-2xl font-bold text-green-900 dark:text-green-100">
                  {planningMetrics.plannedCapacity.toLocaleString()} MW
                </p>
                <p className="text-xs text-green-600 dark:text-green-400 mt-1">Target: {planningMetrics.targetCapacity.toLocaleString()} MW</p>
              </div>
              <Zap className="w-8 h-8 text-green-600 dark:text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 border-purple-200 dark:border-purple-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-600 dark:text-purple-400">Total Investment</p>
                <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">
                  {formatCurrency(planningMetrics.totalInvestment / 1000000)}
                </p>
                <p className="text-xs text-purple-600 dark:text-purple-400 mt-1">{planningMetrics.budgetUtilization}% utilized</p>
              </div>
              <DollarSign className="w-8 h-8 text-purple-600 dark:text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 border-orange-200 dark:border-orange-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-600 dark:text-orange-400">Timeline Adherence</p>
                <p className="text-2xl font-bold text-orange-900 dark:text-orange-100">
                  {planningMetrics.timelineAdherence}%
                </p>
                <p className="text-xs text-orange-600 dark:text-orange-400 mt-1">Projects on schedule</p>
              </div>
              <Clock className="w-8 h-8 text-orange-600 dark:text-orange-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="capacity">Capacity Plan</TabsTrigger>
          <TabsTrigger value="projects">Major Projects</TabsTrigger>
          <TabsTrigger value="regional">Regional</TabsTrigger>
          <TabsTrigger value="strategic">Strategic</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Project Categories */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="w-5 h-5 text-blue-600" />
                  Project Categories Distribution
                </CardTitle>
                <CardDescription>Active projects by category</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPieChart>
                    <Pie
                      data={projectCategories}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="projects"
                    >
                      {projectCategories.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [value, 'Projects']} />
                  </RechartsPieChart>
                </ResponsiveContainer>
                <div className="grid grid-cols-1 gap-2 mt-4">
                  {projectCategories.map((category, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: category.color }}
                        />
                        <span className="text-sm">{category.name}</span>
                      </div>
                      <span className="text-sm font-medium">{category.projects} ({category.percentage}%)</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Investment Sources */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-green-600" />
                  Investment Sources
                </CardTitle>
                <CardDescription>Funding allocation by source (in millions BDT)</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={investmentSources}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="source" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`৳${value}M`, 'Investment']} />
                    <Bar dataKey="amount" fill="#3b82f6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Strategic Initiatives */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-purple-600" />
                Strategic Initiatives Progress
              </CardTitle>
              <CardDescription>Key national energy targets and achievements</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {strategicInitiatives.map((initiative, index) => (
                  <div key={index} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold">{initiative.initiative}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Target: {initiative.target}</p>
                      </div>
                      <div className="text-right">
                        <Badge className={getStatusColor(initiative.priority)}>
                          {initiative.priority}
                        </Badge>
                        <p className="text-sm font-medium mt-1">Current: {initiative.current}</p>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{initiative.progress.toFixed(1)}%</span>
                      </div>
                      <Progress value={initiative.progress} className="h-2" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="capacity" className="space-y-6">
          {/* Capacity Expansion Plan */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-blue-600" />
                Capacity Expansion Plan (2024-2030)
              </CardTitle>
              <CardDescription>Planned capacity additions by technology (MW)</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={capacityPlan}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="year" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`${value} MW`, '']} />
                  <Legend />
                  <Area type="monotone" dataKey="thermal" stackId="1" stroke="#ef4444" fill="#ef4444" name="Thermal" />
                  <Area type="monotone" dataKey="renewable" stackId="1" stroke="#10b981" fill="#10b981" name="Renewable" />
                  <Area type="monotone" dataKey="nuclear" stackId="1" stroke="#8b5cf6" fill="#8b5cf6" name="Nuclear" />
                  <Area type="monotone" dataKey="hydro" stackId="1" stroke="#3b82f6" fill="#3b82f6" name="Hydro" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Technology Roadmap */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-orange-600" />
                Technology Mix Roadmap
              </CardTitle>
              <CardDescription>Energy technology transition plan (% share)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-center">Current Mix (2024)</h4>
                  {technologyRoadmap.map((tech, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm">{tech.technology}</span>
                      <span className="text-sm font-medium">{tech.current}%</span>
                    </div>
                  ))}
                </div>
                <div className="space-y-4">
                  <h4 className="font-semibold text-center">Target Mix (2030)</h4>
                  {technologyRoadmap.map((tech, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm">{tech.technology}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">{tech.target2030}%</span>
                        {tech.trend === 'increasing' && <TrendingUp className="w-3 h-3 text-green-600" />}
                        {tech.trend === 'decreasing' && <TrendingUp className="w-3 h-3 text-red-600 rotate-180" />}
                        {tech.trend === 'stable' && <Activity className="w-3 h-3 text-gray-600" />}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="projects" className="space-y-6">
          {/* Major Projects */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="w-5 h-5 text-green-600" />
                Major Ongoing Projects
              </CardTitle>
              <CardDescription>High-impact infrastructure development projects</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {majorProjects.map((project) => (
                  <div key={project.id} className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="font-semibold">{project.name}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {project.id} • {project.region} • {project.capacity} MW
                        </p>
                        <p className="text-xs text-gray-500">
                          Investment: {formatCurrency(project.investment)} • Expected: {project.expectedCompletion}
                        </p>
                      </div>
                      <Badge className={getStatusColor(project.status)}>
                        {project.status}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{project.progress}%</span>
                      </div>
                      <Progress value={project.progress} className="h-3" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="regional" className="space-y-6">
          {/* Regional Projects */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-blue-600" />
                Regional Development Projects
              </CardTitle>
              <CardDescription>Project distribution across administrative divisions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {regionalProjects.map((region, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-white dark:bg-gray-700 rounded-lg">
                        <MapPin className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{region.region}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {region.projects} projects • {region.capacity} MW capacity
                        </p>
                        <p className="text-xs text-gray-500">Investment: {formatCurrency(region.investment)}</p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(region.status)}>
                      {region.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="strategic" className="space-y-6">
          {/* Strategic Priorities */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-green-600" />
                  Vision 2041 Targets
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <h4 className="font-semibold text-green-800 dark:text-green-200">Energy Security</h4>
                  <p className="text-sm text-green-700 dark:text-green-300">Ensure reliable energy supply for all</p>
                </div>
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h4 className="font-semibold text-blue-800 dark:text-blue-200">Clean Energy Transition</h4>
                  <p className="text-sm text-blue-700 dark:text-blue-300">40% renewable energy by 2041</p>
                </div>
                <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <h4 className="font-semibold text-purple-800 dark:text-purple-200">Grid Modernization</h4>
                  <p className="text-sm text-purple-700 dark:text-purple-300">Smart grid infrastructure development</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gauge className="w-5 h-5 text-orange-600" />
                  Key Performance Indicators
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Electrification Rate</span>
                  <span className="text-lg font-bold">96.2%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Per Capita Consumption</span>
                  <span className="text-lg font-bold">512 kWh</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Energy Intensity</span>
                  <span className="text-lg font-bold">0.28 kWh/USD</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">CO₂ Reduction Target</span>
                  <span className="text-lg font-bold">15% by 2030</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PlanningDevelopmentDashboard;