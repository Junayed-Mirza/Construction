import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../ui/card";
import { Badge } from "../../ui/badge";
import { Button } from "../../ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../ui/tabs";
import { Progress } from "../../ui/progress";
import { Alert, AlertDescription, AlertTitle } from "../../ui/alert";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { 
  Wrench, 
  TrendingUp, 
  Settings, 
  AlertTriangle, 
  Zap, 
  Gauge,
  ClipboardList,
  Users,
  Calendar,
  FileText,
  Activity,
  Shield,
  Timer,
  CheckCircle,
  XCircle,
  Clock,
  Wrench
} from 'lucide-react';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  department: string;
  powerPlant?: string;
  level: number;
  permissions: string[];
  accessToken: string;
}

interface SeniorEngineerDashboardProps {
  user: User;
  isDark: boolean;
}

export default function SeniorEngineerDashboard({ user, isDark }: SeniorEngineerDashboardProps) {
  const [workOrders, setWorkOrders] = useState<any[]>([]);
  const [teamStatus, setTeamStatus] = useState<any[]>([]);
  const [equipmentStatus, setEquipmentStatus] = useState<any[]>([]);
  const [performanceMetrics, setPerformanceMetrics] = useState<any>({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Mock data - replace with real API calls
    setWorkOrders([
      { 
        id: 'WO-2024-001', 
        title: 'Turbine Blade Inspection', 
        priority: 'high', 
        status: 'in-progress', 
        assignedTo: 'John Doe',
        equipment: 'Unit 2 Turbine',
        dueDate: '2024-03-15',
        progress: 65,
        estimatedHours: 24,
        actualHours: 16
      },
      { 
        id: 'WO-2024-002', 
        title: 'Boiler Pressure Test', 
        priority: 'medium', 
        status: 'pending', 
        assignedTo: 'Jane Smith',
        equipment: 'Unit 1 Boiler',
        dueDate: '2024-03-18',
        progress: 0,
        estimatedHours: 12,
        actualHours: 0
      },
      { 
        id: 'WO-2024-003', 
        title: 'Generator Cooling System', 
        priority: 'urgent', 
        status: 'completed', 
        assignedTo: 'Mike Johnson',
        equipment: 'Unit 3 Generator',
        dueDate: '2024-03-12',
        progress: 100,
        estimatedHours: 8,
        actualHours: 9
      },
      { 
        id: 'WO-2024-004', 
        title: 'Control System Calibration', 
        priority: 'low', 
        status: 'scheduled', 
        assignedTo: 'Sarah Wilson',
        equipment: 'DCS System',
        dueDate: '2024-03-22',
        progress: 0,
        estimatedHours: 16,
        actualHours: 0
      }
    ]);

    setTeamStatus([
      { name: 'John Doe', role: 'Mechanical Technician', status: 'on-site', currentTask: 'Turbine maintenance', productivity: 92 },
      { name: 'Jane Smith', role: 'Electrical Technician', status: 'on-site', currentTask: 'Cable inspection', productivity: 88 },
      { name: 'Mike Johnson', role: 'Instrumentation Tech', status: 'training', currentTask: 'Safety training', productivity: 85 },
      { name: 'Sarah Wilson', role: 'Control Systems Tech', status: 'on-site', currentTask: 'DCS programming', productivity: 95 },
      { name: 'David Brown', role: 'Maintenance Helper', status: 'off-duty', currentTask: 'Rest period', productivity: 90 }
    ]);

    setEquipmentStatus([
      { name: 'Turbine Unit 1', condition: 'good', lastMaintenance: '2024-02-15', nextMaintenance: '2024-05-15', reliability: 95 },
      { name: 'Turbine Unit 2', condition: 'fair', lastMaintenance: '2024-01-20', nextMaintenance: '2024-04-20', reliability: 88 },
      { name: 'Boiler Unit 1', condition: 'excellent', lastMaintenance: '2024-02-28', nextMaintenance: '2024-05-28', reliability: 98 },
      { name: 'Generator Unit 1', condition: 'good', lastMaintenance: '2024-02-10', nextMaintenance: '2024-05-10', reliability: 92 },
      { name: 'Cooling Tower', condition: 'fair', lastMaintenance: '2024-01-15', nextMaintenance: '2024-04-15', reliability: 85 }
    ]);

    setPerformanceMetrics({
      totalWorkOrders: 15,
      completedThisMonth: 8,
      overdueTasks: 2,
      teamEfficiency: 91,
      equipmentAvailability: 94,
      maintenanceCosts: 125000,
      safetyIncidents: 0,
      certificationStatus: 8
    });

    setIsLoading(false);
  }, []);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'in-progress': return 'bg-blue-500';
      case 'pending': return 'bg-yellow-500';
      case 'scheduled': return 'bg-purple-500';
      case 'overdue': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getConditionIcon = (condition: string) => {
    switch (condition) {
      case 'excellent': return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'good': return <CheckCircle className="w-5 h-5 text-blue-600" />;
      case 'fair': return <Clock className="w-5 h-5 text-yellow-600" />;
      case 'poor': return <XCircle className="w-5 h-5 text-red-600" />;
      default: return <Activity className="w-5 h-5 text-gray-600" />;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-green-50/50 to-blue-50/50 dark:from-gray-900 dark:to-green-900 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Senior Engineer Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-300">{user.department} • {user.powerPlant} • Welcome, {user.name}</p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="px-3 py-1">
            <Wrench className="w-4 h-4 mr-2" />
            {performanceMetrics.totalWorkOrders} Active Orders
          </Badge>
          <Badge variant="outline" className="px-3 py-1">
            <Users className="w-4 h-4 mr-2" />
            {teamStatus.filter(t => t.status === 'on-site').length} Team On-Site
          </Badge>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-8 gap-4">
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Work Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{performanceMetrics.totalWorkOrders}</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 inline mr-1" />
              {performanceMetrics.completedThisMonth} completed
            </p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Team Efficiency</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{performanceMetrics.teamEfficiency}%</div>
            <p className="text-xs text-muted-foreground">Above target</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Equipment Availability</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{performanceMetrics.equipmentAvailability}%</div>
            <p className="text-xs text-muted-foreground">Excellent performance</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Overdue Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{performanceMetrics.overdueTasks}</div>
            <p className="text-xs text-muted-foreground">Needs attention</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Monthly Costs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">৳{performanceMetrics.maintenanceCosts.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Within budget</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Safety Record</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{performanceMetrics.safetyIncidents}</div>
            <p className="text-xs text-muted-foreground">
              <Shield className="w-3 h-3 inline mr-1" />
              Zero incidents
            </p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Certifications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-indigo-600">{performanceMetrics.certificationStatus}/10</div>
            <p className="text-xs text-muted-foreground">Team certified</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Next Inspection</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-cyan-600">5</div>
            <p className="text-xs text-muted-foreground">days remaining</p>
          </CardContent>
        </Card>
      </div>

      {/* Priority Alerts */}
      {performanceMetrics.overdueTasks > 0 && (
        <Alert className="border-red-200 bg-red-50 dark:bg-red-900/20">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertTitle className="text-red-800 dark:text-red-300">Urgent Action Required</AlertTitle>
          <AlertDescription className="text-red-700 dark:text-red-400">
            You have {performanceMetrics.overdueTasks} overdue tasks that require immediate attention.
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="workorders" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="workorders">Work Orders</TabsTrigger>
          <TabsTrigger value="team">Team Status</TabsTrigger>
          <TabsTrigger value="equipment">Equipment</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="planning">Planning</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="workorders" className="space-y-4">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {workOrders.map((order, index) => (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                    <div>
                      <CardTitle className="text-lg">{order.title}</CardTitle>
                      <CardDescription>{order.equipment} • Due: {new Date(order.dueDate).toLocaleDateString()}</CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${getPriorityColor(order.priority)}`} />
                      <Badge variant="outline">{order.status}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="text-xl font-bold text-blue-600">{order.progress}%</div>
                        <p className="text-xs text-muted-foreground">Progress</p>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-green-600">{order.actualHours}h</div>
                        <p className="text-xs text-muted-foreground">Actual</p>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-orange-600">{order.estimatedHours}h</div>
                        <p className="text-xs text-muted-foreground">Estimated</p>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Assigned to: {order.assignedTo}</span>
                        <span>{order.progress}% Complete</span>
                      </div>
                      <Progress value={order.progress} className="h-2" />
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        <Settings className="w-4 h-4 mr-2" />
                        Details
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        <ClipboardList className="w-4 h-4 mr-2" />
                        Update
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="team" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Team Status Overview</CardTitle>
                <CardDescription>Current team deployment and activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {teamStatus.map((member) => (
                    <div key={member.name} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800/20 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className={`w-3 h-3 rounded-full ${
                          member.status === 'on-site' ? 'bg-green-500' :
                          member.status === 'training' ? 'bg-blue-500' : 'bg-gray-500'
                        }`} />
                        <div>
                          <div className="font-medium">{member.name}</div>
                          <div className="text-sm text-muted-foreground">{member.role}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-sm">{member.currentTask}</div>
                        <div className="text-xs text-muted-foreground">Productivity: {member.productivity}%</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Team Performance Metrics</CardTitle>
                <CardDescription>Productivity and efficiency tracking</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={teamStatus.filter(m => m.status !== 'off-duty')}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="productivity" fill="#3B82F6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="equipment" className="space-y-4">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {equipmentStatus.map((equipment, index) => (
              <motion.div
                key={equipment.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                    <div>
                      <CardTitle className="text-lg">{equipment.name}</CardTitle>
                      <CardDescription>Condition: {equipment.condition}</CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getConditionIcon(equipment.condition)}
                      <Badge 
                        variant={equipment.condition === 'excellent' || equipment.condition === 'good' ? 'default' : 'secondary'}
                      >
                        {equipment.reliability}% Reliable
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-muted-foreground">Last Maintenance</div>
                        <div className="font-medium">{new Date(equipment.lastMaintenance).toLocaleDateString()}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Next Maintenance</div>
                        <div className="font-medium">{new Date(equipment.nextMaintenance).toLocaleDateString()}</div>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Reliability Score</span>
                        <span>{equipment.reliability}%</span>
                      </div>
                      <Progress value={equipment.reliability} className="h-2" />
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        <Wrench className="w-4 h-4 mr-2" />
                        Schedule
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        <Activity className="w-4 h-4 mr-2" />
                        History
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Work Order Completion Rate</CardTitle>
                <CardDescription>Monthly completion trends</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={[
                    { month: 'Jan', completed: 12, planned: 15 },
                    { month: 'Feb', completed: 18, planned: 20 },
                    { month: 'Mar', completed: 8, planned: 15 },
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="completed" stroke="#10B981" strokeWidth={2} />
                    <Line type="monotone" dataKey="planned" stroke="#3B82F6" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>KPI Summary</CardTitle>
                <CardDescription>Key performance indicators</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Schedule Adherence</span>
                    <div className="flex items-center space-x-2">
                      <Progress value={87} className="w-20 h-2" />
                      <span className="text-sm text-muted-foreground">87%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Quality Score</span>
                    <div className="flex items-center space-x-2">
                      <Progress value={94} className="w-20 h-2" />
                      <span className="text-sm text-muted-foreground">94%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Cost Efficiency</span>
                    <div className="flex items-center space-x-2">
                      <Progress value={91} className="w-20 h-2" />
                      <span className="text-sm text-muted-foreground">91%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Safety Compliance</span>
                    <div className="flex items-center space-x-2">
                      <Progress value={100} className="w-20 h-2" />
                      <span className="text-sm text-muted-foreground">100%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="planning" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Upcoming Maintenance Schedule</CardTitle>
                <CardDescription>Next 30 days maintenance activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Calendar className="w-5 h-5 text-blue-600" />
                      <div>
                        <div className="font-medium">Turbine Inspection</div>
                        <div className="text-sm text-muted-foreground">Unit 2 - Scheduled maintenance</div>
                      </div>
                    </div>
                    <Badge variant="outline">Mar 15</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Timer className="w-5 h-5 text-yellow-600" />
                      <div>
                        <div className="font-medium">Boiler Cleaning</div>
                        <div className="text-sm text-muted-foreground">Unit 1 - Deep cleaning required</div>
                      </div>
                    </div>
                    <Badge variant="outline">Mar 20</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Shield className="w-5 h-5 text-green-600" />
                      <div>
                        <div className="font-medium">Safety System Test</div>
                        <div className="text-sm text-muted-foreground">Quarterly safety inspection</div>
                      </div>
                    </div>
                    <Badge variant="outline">Mar 25</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Resource Planning</CardTitle>
                <CardDescription>Material and manpower requirements</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 bg-gray-50 dark:bg-gray-800/20 rounded-lg">
                    <div className="font-medium mb-2">Required Materials</div>
                    <div className="text-sm text-muted-foreground space-y-1">
                      <div>• Turbine blades (2 units)</div>
                      <div>• Gasket seals (5 sets)</div>
                      <div>• Hydraulic fluid (200L)</div>
                      <div>• Safety equipment (PPE sets)</div>
                    </div>
                  </div>
                  <div className="p-3 bg-gray-50 dark:bg-gray-800/20 rounded-lg">
                    <div className="font-medium mb-2">Manpower Allocation</div>
                    <div className="text-sm text-muted-foreground space-y-1">
                      <div>• Senior Technicians: 3</div>
                      <div>• Junior Technicians: 5</div>
                      <div>• Safety Officer: 1</div>
                      <div>• Crane Operator: 1</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Engineering Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <Button className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Daily Work Report
                </Button>
                <Button variant="outline" className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Equipment Status
                </Button>
                <Button variant="outline" className="w-full">
                  <FileText className="w-4 h-4 mr-2" />
                  Performance Analysis
                </Button>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Maintenance Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <Button className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Work Order Summary
                </Button>
                <Button variant="outline" className="w-full mb-2">
                  <FileText className="w-4 h-4 mr-2" />
                  Completion Statistics
                </Button>
                <Button variant="outline" className="w-full">
                  <FileText className="w-4 h-4 mr-2" />
                  Cost Analysis
                </Button>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Team Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <Button variant="outline" className="w-full mb-2">
                  <Users className="w-4 h-4 mr-2" />
                  Team Performance
                </Button>
                <Button variant="outline" className="w-full mb-2">
                  <Shield className="w-4 h-4 mr-2" />
                  Safety Report
                </Button>
                <Button variant="outline" className="w-full">
                  <Calendar className="w-4 h-4 mr-2" />
                  Training Status
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}