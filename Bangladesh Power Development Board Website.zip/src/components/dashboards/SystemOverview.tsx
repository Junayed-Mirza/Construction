import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Progress } from "../ui/progress";
import { Alert, AlertDescription, AlertTitle } from "../ui/alert";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { 
  Zap, 
  TrendingUp, 
  AlertTriangle, 
  Factory, 
  Power,
  Gauge,
  Activity,
  Shield,
  Users,
  FileText,
  Calendar,
  Map,
  Database,
  Settings,
  Bell
} from 'lucide-react';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  department: string;
  powerPlant?: string;
  level: number;
  permissions: string[];
  accessToken: string;
}

interface SystemOverviewProps {
  user: User;
  isDark: boolean;
}

export default function SystemOverview({ user, isDark }: SystemOverviewProps) {
  const [systemData, setSystemData] = useState<any>({});
  const [alerts, setAlerts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Mock comprehensive system data
    setSystemData({
      totalGeneration: 8450,
      totalCapacity: 12500,
      systemFrequency: 49.95,
      transmissionLoad: 8200,
      distributionLoss: 8.5,
      peakDemand: 9200,
      systemReliability: 99.2,
      
      // Department Status
      departments: {
        generation: { status: 'optimal', staffCount: 245, activeProjects: 8 },
        transmission: { status: 'warning', staffCount: 189, activeProjects: 12 },
        distribution: { status: 'optimal', staffCount: 456, activeProjects: 23 },
        maintenance: { status: 'busy', staffCount: 123, activeProjects: 15 },
        operations: { status: 'optimal', staffCount: 89, activeProjects: 5 },
      },

      // Power Plants Status
      powerPlants: {
        operational: 18,
        maintenance: 3,
        offline: 2,
        totalCapacity: 12500,
        currentGeneration: 8450,
      },

      // Financial Summary
      financial: {
        monthlyRevenue: 2450000000, // BDT
        operatingCosts: 1850000000,
        constructionBudget: 5000000000,
        utilizationRate: 67.6,
      },

      // Safety & Compliance
      safety: {
        incidentFree: 127,
        complianceScore: 94.5,
        certificationsValid: 28,
        certificationsExpiring: 3,
      }
    });

    setAlerts([
      {
        id: 1,
        type: 'warning',
        title: 'High Transmission Load',
        message: 'Dhaka-Chittagong 230kV line operating at 92% capacity',
        timestamp: '10 minutes ago',
        department: 'Transmission'
      },
      {
        id: 2,
        type: 'info',
        title: 'Scheduled Maintenance',
        message: 'Barapukuria Unit 4 maintenance starting tomorrow',
        timestamp: '1 hour ago',
        department: 'Generation'
      },
      {
        id: 3,
        type: 'success',
        title: 'Project Milestone',
        message: 'Rooppur project Phase 1 completed successfully',
        timestamp: '2 hours ago',
        department: 'Project Management'
      },
      {
        id: 4,
        type: 'critical',
        title: 'Equipment Alert',
        message: 'Transformer temperature high at Ashuganj substation',
        timestamp: '30 minutes ago',
        department: 'Transmission'
      }
    ]);

    setIsLoading(false);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'optimal': return 'bg-green-500';
      case 'warning': return 'bg-yellow-500';
      case 'busy': return 'bg-blue-500';
      case 'critical': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'success': return 'border-green-200 bg-green-50 dark:bg-green-900/20';
      case 'warning': return 'border-yellow-200 bg-yellow-50 dark:bg-yellow-900/20';
      case 'info': return 'border-blue-200 bg-blue-50 dark:bg-blue-900/20';
      case 'critical': return 'border-red-200 bg-red-50 dark:bg-red-900/20';
      default: return 'border-gray-200 bg-gray-50 dark:bg-gray-900/20';
    }
  };

  const generationMix = [
    { name: 'Coal', value: 3200, color: '#8B5CF6', percentage: 37.9 },
    { name: 'Gas', value: 2800, color: '#10B981', percentage: 33.1 },
    { name: 'Hydro', value: 230, color: '#3B82F6', percentage: 2.7 },
    { name: 'Nuclear', value: 1200, color: '#F59E0B', percentage: 14.2 },
    { name: 'Renewable', value: 1020, color: '#06B6D4', percentage: 12.1 },
  ];

  const departmentPerformance = [
    { name: 'Generation', efficiency: 94, projects: 8, staff: 245 },
    { name: 'Transmission', efficiency: 89, projects: 12, staff: 189 },
    { name: 'Distribution', efficiency: 91, projects: 23, staff: 456 },
    { name: 'Maintenance', efficiency: 87, projects: 15, staff: 123 },
    { name: 'Operations', efficiency: 96, projects: 5, staff: 89 },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">BPDB System Overview</h1>
          <p className="text-gray-600 dark:text-gray-300">
            Welcome back, {user.name} • {user.role} • {user.department}
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="px-3 py-1">
            <Zap className="w-4 h-4 mr-2" />
            System Operational
          </Badge>
        </div>
      </div>

      {/* Critical Alerts */}
      {alerts.filter(alert => alert.type === 'critical').length > 0 && (
        <Alert className="border-red-200 bg-red-50 dark:bg-red-900/20">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertTitle className="text-red-800 dark:text-red-300">Critical System Alert</AlertTitle>
          <AlertDescription className="text-red-700 dark:text-red-400">
            {alerts.filter(alert => alert.type === 'critical').length} critical alerts require immediate attention.
          </AlertDescription>
        </Alert>
      )}

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Generation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{systemData.totalGeneration} MW</div>
            <p className="text-xs text-muted-foreground">
              {((systemData.totalGeneration / systemData.totalCapacity) * 100).toFixed(1)}% of capacity
            </p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">System Frequency</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{systemData.systemFrequency} Hz</div>
            <p className="text-xs text-muted-foreground">Within normal range</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Transmission Load</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{systemData.transmissionLoad} MW</div>
            <p className="text-xs text-muted-foreground">
              {((systemData.transmissionLoad / systemData.totalGeneration) * 100).toFixed(1)}% efficiency
            </p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Distribution Loss</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{systemData.distributionLoss}%</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 inline mr-1 text-green-500" />
              -0.3% improvement
            </p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Peak Demand</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{systemData.peakDemand} MW</div>
            <p className="text-xs text-muted-foreground">Expected at 20:00</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">System Reliability</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-indigo-600">{systemData.systemReliability}%</div>
            <p className="text-xs text-muted-foreground">Excellent performance</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Generation Mix */}
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader>
            <CardTitle>Generation Mix</CardTitle>
            <CardDescription>Current power generation by source</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={generationMix}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percentage }) => `${name} ${percentage}%`}
                >
                  {generationMix.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`${value} MW`, 'Generation']} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* System Status */}
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader>
            <CardTitle>System Status</CardTitle>
            <CardDescription>Real-time system health indicators</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Generation Capacity</span>
              <div className="flex items-center space-x-2">
                <Progress value={((systemData.totalGeneration / systemData.totalCapacity) * 100)} className="w-20 h-2" />
                <span className="text-sm text-muted-foreground">
                  {((systemData.totalGeneration / systemData.totalCapacity) * 100).toFixed(1)}%
                </span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">System Reliability</span>
              <div className="flex items-center space-x-2">
                <Progress value={systemData.systemReliability} className="w-20 h-2" />
                <span className="text-sm text-muted-foreground">{systemData.systemReliability}%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Transmission Efficiency</span>
              <div className="flex items-center space-x-2">
                <Progress value={((systemData.transmissionLoad / systemData.totalGeneration) * 100)} className="w-20 h-2" />
                <span className="text-sm text-muted-foreground">
                  {((systemData.transmissionLoad / systemData.totalGeneration) * 100).toFixed(1)}%
                </span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Distribution Efficiency</span>
              <div className="flex items-center space-x-2">
                <Progress value={100 - systemData.distributionLoss} className="w-20 h-2" />
                <span className="text-sm text-muted-foreground">{(100 - systemData.distributionLoss).toFixed(1)}%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Alerts */}
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader>
            <CardTitle>Recent Alerts</CardTitle>
            <CardDescription>System notifications and updates</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {alerts.slice(0, 4).map((alert) => (
                <div key={alert.id} className={`p-3 rounded-lg border ${getAlertColor(alert.type)}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="font-medium text-sm">{alert.title}</div>
                      <div className="text-xs text-muted-foreground mt-1">{alert.message}</div>
                      <div className="flex items-center justify-between mt-2">
                        <Badge variant="outline" className="text-xs">{alert.department}</Badge>
                        <span className="text-xs text-muted-foreground">{alert.timestamp}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Department Performance */}
      <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
        <CardHeader>
          <CardTitle>Department Performance Overview</CardTitle>
          <CardDescription>Efficiency and project status across departments</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={departmentPerformance}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="efficiency" fill="#3B82F6" name="Efficiency %" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Financial Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-green-600">
              ৳{(systemData.financial?.monthlyRevenue / 1000000000).toFixed(2)}B
            </div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 inline mr-1" />
              +5.2% from last month
            </p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Operating Costs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-orange-600">
              ৳{(systemData.financial?.operatingCosts / 1000000000).toFixed(2)}B
            </div>
            <p className="text-xs text-muted-foreground">Within budget limits</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Construction Budget</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-blue-600">
              ৳{(systemData.financial?.constructionBudget / 1000000000).toFixed(2)}B
            </div>
            <p className="text-xs text-muted-foreground">Allocated for projects</p>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Capacity Utilization</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-purple-600">
              {systemData.financial?.utilizationRate}%
            </div>
            <p className="text-xs text-muted-foreground">System efficiency</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-3">
        <Button variant="outline" size="sm">
          <FileText className="w-4 h-4 mr-2" />
          System Report
        </Button>
        <Button variant="outline" size="sm">
          <Calendar className="w-4 h-4 mr-2" />
          Maintenance Schedule
        </Button>
        <Button variant="outline" size="sm">
          <Users className="w-4 h-4 mr-2" />
          Staff Status
        </Button>
        <Button variant="outline" size="sm">
          <Map className="w-4 h-4 mr-2" />
          System Map
        </Button>
        <Button variant="outline" size="sm">
          <Database className="w-4 h-4 mr-2" />
          Data Export
        </Button>
        <Button variant="outline" size="sm">
          <Settings className="w-4 h-4 mr-2" />
          System Settings
        </Button>
      </div>
    </div>
  );
}