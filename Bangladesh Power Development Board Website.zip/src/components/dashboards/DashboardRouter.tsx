import React from 'react';

// Department Dashboards
import GenerationDashboard from "./departments/GenerationDashboard";
import TransmissionDashboard from "./departments/TransmissionDashboard";
import DistributionDashboard from "./departments/DistributionDashboard";
import FinanceAccountsDashboard from "./departments/FinanceAccountsDashboard";
import HumanResourcesDashboard from "./departments/HumanResourcesDashboard";
import PlanningDevelopmentDashboard from "./departments/PlanningDevelopmentDashboard";

// Role Dashboards
import SeniorEngineerDashboard from "./roles/SeniorEngineerDashboard";

// Power Plant Dashboards
import BarapukuriaCoalPowerPlantDashboard from "./powerplants/BarapukuriaCoalPowerPlantDashboard";

// Default Dashboards
import ExecutiveDashboard from "./ExecutiveDashboard";
import DepartmentDashboard from "./DepartmentDashboard";
import PowerPlantDashboard from "./PowerPlantDashboard";
import UserDashboard from "./UserDashboard";

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  department: string;
  powerPlant?: string;
  level: number;
  permissions: string[];
  accessToken: string;
}

interface DashboardRouterProps {
  user: User;
  isDark: boolean;
  activeView: string;
  dashboardData: any;
}

const DEPARTMENT_MAPPING = {
  'generation': GenerationDashboard,
  'transmission': TransmissionDashboard,
  'distribution': DistributionDashboard,
  'finance & accounts': FinanceAccountsDashboard,
  'finance': FinanceAccountsDashboard,
  'accounts': FinanceAccountsDashboard,
  'human resources': HumanResourcesDashboard,
  'hr': HumanResourcesDashboard,
  'planning & development': PlanningDevelopmentDashboard,
  'planning': PlanningDevelopmentDashboard,
  'development': PlanningDevelopmentDashboard,
  'maintenance & engineering': null,
  'operations & control': null,
  'information technology': null,
  'audit & inspection': null,
  'procurement & logistics': null,
  'safety & environment': null,
  'legal & regulatory': null,
  'corporate affairs': null,
  'training & development': null,
  'quality assurance': null,
  'project management': null,
  'research & development': null,
  'customer services': null,
  'security services': null,
  'transport & vehicle': null,
  'store & inventory': null,
  'construction & civil': null,
  'electrical maintenance': null,
  'mechanical maintenance': null,
  'instrumentation & control': null,
  'communication & telecom': null,
  'coal handling': null,
  'water treatment': null,
  'laboratory services': null,
  'general administration': null,
};

const ROLE_MAPPING = {
  'senior engineer': SeniorEngineerDashboard,
  'sr engineer': SeniorEngineerDashboard,
  'senior engineer (electrical)': SeniorEngineerDashboard,
  'senior engineer (mechanical)': SeniorEngineerDashboard,
  'senior engineer (civil)': SeniorEngineerDashboard,
  'senior engineer (control & instrumentation)': SeniorEngineerDashboard,
  // Add more roles as they're created
  'chairman': null,
  'managing director': null,
  'director': null,
  'general manager': null,
  'deputy general manager': null,
  'assistant general manager': null,
  'chief engineer': null,
  'engineer': null,
  'assistant engineer': null,
  'technician': null,
  'plant operator': null,
  'control room operator': null,
  'substation operator': null,
  'system analyst': null,
  'safety officer': null,
  'security officer': null,
  'administrative assistant': null,
};

const POWERPLANT_MAPPING = {
  'barapukuria coal power plant': BarapukuriaCoalPowerPlantDashboard,
  'barapukuria': BarapukuriaCoalPowerPlantDashboard,
  // Add more power plants as they're created
  'payra coal power plant': null,
  'payra': null,
  'rampal coal power plant': null,
  'rampal': null,
  'rooppur nuclear power plant': null,
  'rooppur': null,
  'matarbari coal power plant': null,
  'matarbari': null,
  'ashuganj power plant': null,
  'ashuganj': null,
  'ghorashal power plant': null,
  'ghorashal': null,
  'siddhirganj power plant': null,
  'siddhirganj': null,
  'raozan power plant': null,
  'raozan': null,
  'khulna power plant': null,
  'khulna': null,
  'barisal power plant': null,
  'barisal': null,
  'sylhet power plant': null,
  'sylhet': null,
  'rangpur power plant': null,
  'rangpur': null,
  'comilla power plant': null,
  'comilla': null,
  'mymensingh power plant': null,
  'mymensingh': null,
  'ashuganj south power plant': null,
  'meghnaghat power plant': null,
  'meghnaghat': null,
  'haripur power plant': null,
  'haripur': null,
  'keraniganj power plant': null,
  'keraniganj': null,
  'bhola power plant': null,
  'bhola': null,
  'kaptai hydro power plant': null,
  'kaptai': null,
  'solar power plant': null,
  'wind power plant': null,
};

export default function DashboardRouter({ user, isDark, activeView, dashboardData }: DashboardRouterProps) {
  
  const getSmartDashboard = () => {
    // First check if it's a specific view request
    if (activeView !== 'overview') {
      return null; // Let the main router handle specific views
    }

    // Smart routing based on user role
    const roleKey = user.role?.toLowerCase();
    if (roleKey && ROLE_MAPPING[roleKey]) {
      const RoleDashboard = ROLE_MAPPING[roleKey];
      return <RoleDashboard user={user} isDark={isDark} />;
    }

    // Smart routing based on department
    const deptKey = user.department?.toLowerCase();
    if (deptKey && DEPARTMENT_MAPPING[deptKey]) {
      const DepartmentDashboard = DEPARTMENT_MAPPING[deptKey];
      return <DepartmentDashboard user={user} isDark={isDark} />;
    }

    // Smart routing based on power plant
    const plantKey = user.powerPlant?.toLowerCase();
    if (plantKey) {
      // Try exact match first
      if (POWERPLANT_MAPPING[plantKey]) {
        const PowerPlantDashboard = POWERPLANT_MAPPING[plantKey];
        return <PowerPlantDashboard user={user} isDark={isDark} />;
      }
      
      // Try partial match
      const partialMatch = Object.keys(POWERPLANT_MAPPING).find(key => 
        plantKey.includes(key) || key.includes(plantKey)
      );
      if (partialMatch && POWERPLANT_MAPPING[partialMatch]) {
        const PowerPlantDashboard = POWERPLANT_MAPPING[partialMatch];
        return <PowerPlantDashboard user={user} isDark={isDark} />;
      }
    }

    // Default to user dashboard
    return <UserDashboard user={user} data={dashboardData} />;
  };

  const getSpecificDashboard = () => {
    switch (activeView) {
      case "executive":
        return <ExecutiveDashboard user={user} />;
      
      case "department":
        // Smart department routing
        const deptKey = user.department?.toLowerCase();
        if (deptKey && DEPARTMENT_MAPPING[deptKey]) {
          const DepartmentDashboard = DEPARTMENT_MAPPING[deptKey];
          return <DepartmentDashboard user={user} isDark={isDark} />;
        }
        return <DepartmentDashboard user={user} viewAll={false} />;
      
      case "departments":
        return <DepartmentDashboard user={user} viewAll={true} />;
      
      case "powerplant":
        // Smart power plant routing
        const plantKey = user.powerPlant?.toLowerCase();
        if (plantKey) {
          const exactMatch = POWERPLANT_MAPPING[plantKey];
          if (exactMatch) {
            const PowerPlantDashboard = exactMatch;
            return <PowerPlantDashboard user={user} isDark={isDark} />;
          }
          
          const partialMatch = Object.keys(POWERPLANT_MAPPING).find(key => 
            plantKey.includes(key) || key.includes(plantKey)
          );
          if (partialMatch && POWERPLANT_MAPPING[partialMatch]) {
            const PowerPlantDashboard = POWERPLANT_MAPPING[partialMatch];
            return <PowerPlantDashboard user={user} isDark={isDark} />;
          }
        }
        return <PowerPlantDashboard user={user} viewAll={false} />;
      
      case "powerplants":
        return <PowerPlantDashboard user={user} viewAll={true} />;

      // Specific Department Routes
      case "generation-dept":
        return <GenerationDashboard user={user} isDark={isDark} />;
      case "transmission-dept":
        return <TransmissionDashboard user={user} isDark={isDark} />;
      case "distribution-dept":
        return <DistributionDashboard user={user} isDark={isDark} />;
      case "finance-dept":
        return <FinanceAccountsDashboard user={user} isDark={isDark} />;
      case "hr-dept":
        return <HumanResourcesDashboard user={user} isDark={isDark} />;
      case "planning-dept":
        return <PlanningDevelopmentDashboard user={user} isDark={isDark} />;

      // Specific Role Routes
      case "senior-engineer":
        return <SeniorEngineerDashboard user={user} isDark={isDark} />;

      // Specific Power Plant Routes
      case "barapukuria-plant":
        return <BarapukuriaCoalPowerPlantDashboard user={user} isDark={isDark} />;

      default:
        return null;
    }
  };

  // Return specific dashboard if requested, otherwise smart dashboard
  return getSpecificDashboard() || getSmartDashboard();
}

// Export mappings for use in menu generation
export { DEPARTMENT_MAPPING, ROLE_MAPPING, POWERPLANT_MAPPING };