import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Building, 
  Users, 
  TrendingUp, 
  TrendingDown,
  Target,
  DollarSign,
  Calendar,
  Clock,
  FileText,
  AlertTriangle,
  CheckCircle,
  BarChart3,
  PieChart,
  Settings
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Button } from "../ui/button";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, AreaChart, Area, BarChart as RechartsBarChart, Bar } from 'recharts';
import { projectId } from '../../utils/supabase/info';

interface User {
  id: string;
  name: string;
  role: string;
  department: string;
  level: number;
  accessToken: string;
}

interface DepartmentDashboardProps {
  user: User;
  viewAll?: boolean;
}

export default function DepartmentDashboard({ user, viewAll = false }: DepartmentDashboardProps) {
  const [selectedDepartment, setSelectedDepartment] = useState(user.department);
  const [departmentData, setDepartmentData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  const departments = [
    'GENERATION', 'TRANSMISSION', 'DISTRIBUTION', 'FINANCE', 'HR', 'PLANNING', 'MAINTENANCE', 'OPERATIONS', 'IT', 'AUDIT'
  ];

  useEffect(() => {
    fetchDepartmentData();
  }, [selectedDepartment]);

  const fetchDepartmentData = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/data/department/${selectedDepartment}`, {
        headers: {
          'Authorization': `Bearer ${user.accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        setDepartmentData(data);
      }
    } catch (error) {
      console.error('Failed to fetch department data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Sample data
  const departmentKPIs = [
    {
      title: 'Total Staff',
      value: departmentData?.overview?.totalStaff || 0,
      unit: 'employees',
      change: '+12',
      trend: 'up',
      icon: Users,
      color: 'text-blue-600'
    },
    {
      title: 'Active Projects',
      value: departmentData?.overview?.activeProjects || 0,
      unit: 'projects',
      change: '+3',
      trend: 'up',
      icon: Target,
      color: 'text-green-600'
    },
    {
      title: 'Budget Utilization',
      value: departmentData?.overview?.performance || 0,
      unit: '%',
      change: '+5%',
      trend: 'up',
      icon: DollarSign,
      color: 'text-orange-600'
    },
    {
      title: 'Department Performance',
      value: departmentData?.overview?.performance || 0,
      unit: '%',
      change: '+2.3%',
      trend: 'up',
      icon: TrendingUp,
      color: 'text-purple-600'
    }
  ];

  const monthlyData = [
    { month: 'Jan', performance: 88, budget: 75, projects: 12 },
    { month: 'Feb', performance: 90, budget: 78, projects: 14 },
    { month: 'Mar', performance: 87, budget: 82, projects: 16 },
    { month: 'Apr', performance: 92, budget: 85, projects: 18 },
    { month: 'May', performance: 89, budget: 88, projects: 19 },
    { month: 'Jun', performance: 94, budget: 90, projects: 21 },
  ];

  const teamPerformance = [
    { team: 'Engineering', performance: 95, members: 45 },
    { team: 'Operations', performance: 92, members: 38 },
    { team: 'Maintenance', performance: 88, members: 32 },
    { team: 'Quality Control', performance: 96, members: 15 },
    { team: 'Planning', performance: 90, members: 22 },
  ];

  const upcomingTasks = [
    { task: 'Quarterly Safety Audit', due: '2024-01-15', priority: 'high', assignee: 'John Doe' },
    { task: 'Equipment Maintenance Review', due: '2024-01-18', priority: 'medium', assignee: 'Jane Smith' },
    { task: 'Budget Planning Meeting', due: '2024-01-20', priority: 'high', assignee: 'Mike Johnson' },
    { task: 'Team Performance Review', due: '2024-01-25', priority: 'low', assignee: 'Sarah Wilson' },
  ];

  const recentActivities = [
    { type: 'project', message: 'New maintenance project initiated', time: '2 hours ago', user: 'John Doe' },
    { type: 'staff', message: 'New team member onboarded', time: '4 hours ago', user: 'HR Team' },
    { type: 'budget', message: 'Monthly budget report submitted', time: '1 day ago', user: 'Finance Team' },
    { type: 'meeting', message: 'Department meeting scheduled', time: '2 days ago', user: 'Department Head' },
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50 dark:bg-red-900/20';
      case 'medium': return 'text-yellow-600 bg-yellow-50 dark:bg-yellow-900/20';
      case 'low': return 'text-green-600 bg-green-50 dark:bg-green-900/20';
      default: return 'text-gray-600 bg-gray-50 dark:bg-gray-900/20';
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'project': return <Target className="w-4 h-4 text-blue-500" />;
      case 'staff': return <Users className="w-4 h-4 text-green-500" />;
      case 'budget': return <DollarSign className="w-4 h-4 text-orange-500" />;
      case 'meeting': return <Calendar className="w-4 h-4 text-purple-500" />;
      default: return <FileText className="w-4 h-4 text-gray-500" />;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            {viewAll ? 'All Departments' : 'Department Dashboard'}
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            {viewAll ? 'Overview of all department performance and metrics' : `${selectedDepartment} Department overview and management`}
          </p>
        </div>
        
        {viewAll && (
          <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
            <SelectTrigger className="w-48 backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-white/20 dark:border-gray-700/30">
              <SelectValue placeholder="Select Department" />
            </SelectTrigger>
            <SelectContent>
              {departments.map((dept) => (
                <SelectItem key={dept} value={dept}>{dept}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Department KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {departmentKPIs.map((kpi, index) => (
          <motion.div
            key={kpi.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg bg-gray-100 dark:bg-gray-800 ${kpi.color}`}>
                      <kpi.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{kpi.title}</p>
                      <div className="flex items-baseline space-x-1">
                        <span className="text-2xl font-bold text-gray-900 dark:text-white">
                          {kpi.value.toLocaleString()}
                        </span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">{kpi.unit}</span>
                      </div>
                    </div>
                  </div>
                  <div className={`flex items-center space-x-1 ${kpi.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                    {kpi.trend === 'up' ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                    <span className="text-sm font-medium">{kpi.change}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="team">Team Management</TabsTrigger>
          <TabsTrigger value="tasks">Tasks & Projects</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Department Trends */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="w-5 h-5 text-blue-600" />
                  <span>Department Trends</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                    <XAxis dataKey="month" className="text-gray-600 dark:text-gray-400" />
                    <YAxis className="text-gray-600 dark:text-gray-400" />
                    <Tooltip />
                    <Line type="monotone" dataKey="performance" stroke="#3b82f6" strokeWidth={2} />
                    <Line type="monotone" dataKey="budget" stroke="#10b981" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Recent Activities */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-purple-600" />
                  <span>Recent Activities</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivities.map((activity, index) => (
                    <div key={index} className="flex items-start space-x-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                      {getActivityIcon(activity.type)}
                      <div className="flex-1">
                        <p className="font-medium text-gray-900 dark:text-white">{activity.message}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <p className="text-sm text-gray-600 dark:text-gray-400">{activity.user}</p>
                          <span className="text-gray-400">•</span>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{activity.time}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          {/* Team Performance */}
          <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                <span>Team Performance Analysis</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <RechartsBarChart data={teamPerformance}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                  <XAxis dataKey="team" className="text-gray-600 dark:text-gray-400" />
                  <YAxis className="text-gray-600 dark:text-gray-400" />
                  <Tooltip />
                  <Bar dataKey="performance" fill="#3b82f6" name="Performance %" />
                </RechartsBarChart>
              </ResponsiveContainer>
              
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {teamPerformance.map((team, index) => (
                  <div key={index} className="p-4 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-900 dark:text-white">{team.team}</h4>
                      <Badge variant="outline">{team.members} members</Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600 dark:text-gray-400">Performance</span>
                        <span className="font-medium">{team.performance}%</span>
                      </div>
                      <Progress value={team.performance} className="h-2" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="team" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Team Overview */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  <span>Team Overview</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                      <p className="text-2xl font-bold text-blue-600">{departmentData?.overview?.totalStaff || 152}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Total Staff</p>
                    </div>
                    <div className="text-center p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
                      <p className="text-2xl font-bold text-green-600">8</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Teams</p>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Engineers</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">45 (30%)</span>
                    </div>
                    <Progress value={30} className="h-2" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Operators</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">38 (25%)</span>
                    </div>
                    <Progress value={25} className="h-2" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Technicians</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">32 (21%)</span>
                    </div>
                    <Progress value={21} className="h-2" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Support Staff</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">37 (24%)</span>
                    </div>
                    <Progress value={24} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Department Budget */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <DollarSign className="w-5 h-5 text-green-600" />
                  <span>Budget Status</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="text-center">
                    <p className="text-3xl font-bold text-gray-900 dark:text-white">
                      ৳{(departmentData?.overview?.budget || 850000).toLocaleString()}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Total Budget (Monthly)</p>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Salaries & Benefits</span>
                        <span className="text-sm text-gray-600 dark:text-gray-400">60%</span>
                      </div>
                      <Progress value={60} className="h-2" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Operations</span>
                        <span className="text-sm text-gray-600 dark:text-gray-400">25%</span>
                      </div>
                      <Progress value={25} className="h-2" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Equipment & Maintenance</span>
                        <span className="text-sm text-gray-600 dark:text-gray-400">10%</span>
                      </div>
                      <Progress value={10} className="h-2" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Training & Development</span>
                        <span className="text-sm text-gray-600 dark:text-gray-400">5%</span>
                      </div>
                      <Progress value={5} className="h-2" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tasks" className="space-y-6">
          {/* Upcoming Tasks */}
          <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <FileText className="w-5 h-5 text-orange-600" />
                  <span>Upcoming Tasks & Deadlines</span>
                </div>
                <Button size="sm" className="bg-gradient-to-r from-blue-600 to-green-600">
                  Add Task
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingTasks.map((task, index) => (
                  <div key={index} className="flex items-center justify-between p-4 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 dark:text-white">{task.task}</h4>
                      <div className="flex items-center space-x-4 mt-2">
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-600 dark:text-gray-400">{task.due}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Users className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-600 dark:text-gray-400">{task.assignee}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={getPriorityColor(task.priority)}>
                        {task.priority}
                      </Badge>
                      <Button size="sm" variant="outline">
                        View
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}