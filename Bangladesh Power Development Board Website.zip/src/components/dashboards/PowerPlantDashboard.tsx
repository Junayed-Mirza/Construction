import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Factory, 
  Zap, 
  Thermometer, 
  Gauge,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  TrendingDown,
  Users,
  Settings,
  Clock,
  Calendar,
  Wrench,
  Activity,
  Shield,
  Fuel
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Button } from "../ui/button";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, AreaChart, Area, RadialBarChart, RadialBar, Legend } from 'recharts';
import { projectId } from '../../utils/supabase/info';

interface User {
  id: string;
  name: string;
  role: string;
  department: string;
  powerPlant?: string;
  level: number;
  accessToken: string;
}

interface PowerPlantDashboardProps {
  user: User;
  viewAll?: boolean;
}

export default function PowerPlantDashboard({ user, viewAll = false }: PowerPlantDashboardProps) {
  const [selectedPlant, setSelectedPlant] = useState(user.powerPlant || 'Barapukuria Coal Power Plant');
  const [plantData, setPlantData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  const powerPlants = [
    'Barapukuria Coal Power Plant',
    'Payra Coal Power Plant',
    'Rampal Coal Power Plant',
    'Rooppur Nuclear Power Plant',
    'Ashuganj Power Plant',
    'Ghorashal Power Plant',
    'Siddhirganj Power Plant',
    'Raozan Power Plant',
    'Khulna Power Plant',
    'Barisal Power Plant',
    'Sylhet Power Plant',
    'Rangpur Power Plant'
  ];

  useEffect(() => {
    fetchPlantData();
  }, [selectedPlant]);

  const fetchPlantData = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/data/powerplant/${selectedPlant}`, {
        headers: {
          'Authorization': `Bearer ${user.accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        setPlantData(data);
      }
    } catch (error) {
      console.error('Failed to fetch power plant data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Sample real-time data
  const plantKPIs = [
    {
      title: 'Current Output',
      value: plantData?.currentOutput || 0,
      unit: 'MW',
      capacity: plantData?.capacity || 0,
      change: '+2.5%',
      trend: 'up',
      icon: Zap,
      color: 'text-blue-600'
    },
    {
      title: 'Efficiency',
      value: plantData?.efficiency || 0,
      unit: '%',
      change: '+0.8%',
      trend: 'up',
      icon: TrendingUp,
      color: 'text-green-600'
    },
    {
      title: 'Staff on Duty',
      value: plantData?.staff || 0,
      unit: 'personnel',
      change: '0',
      trend: 'neutral',
      icon: Users,
      color: 'text-purple-600'
    },
    {
      title: 'Active Alerts',
      value: plantData?.alerts || 0,
      unit: 'alerts',
      change: '-2',
      trend: 'down',
      icon: AlertTriangle,
      color: 'text-orange-600'
    }
  ];

  const realTimeData = [
    { time: '00:00', output: 850, temperature: 245, pressure: 18.5 },
    { time: '04:00', output: 820, temperature: 242, pressure: 18.2 },
    { time: '08:00', output: 920, temperature: 248, pressure: 19.1 },
    { time: '12:00', output: 980, temperature: 252, pressure: 19.8 },
    { time: '16:00', output: 950, temperature: 250, pressure: 19.5 },
    { time: '20:00', output: 890, temperature: 247, pressure: 18.9 },
    { time: '24:00', output: 870, temperature: 245, pressure: 18.6 },
  ];

  const equipmentStatus = [
    { equipment: 'Turbine 1', status: 'operational', efficiency: 94, lastMaintenance: '2024-01-10' },
    { equipment: 'Turbine 2', status: 'operational', efficiency: 92, lastMaintenance: '2024-01-08' },
    { equipment: 'Generator 1', status: 'operational', efficiency: 96, lastMaintenance: '2024-01-15' },
    { equipment: 'Generator 2', status: 'maintenance', efficiency: 0, lastMaintenance: '2024-01-20' },
    { equipment: 'Boiler 1', status: 'operational', efficiency: 89, lastMaintenance: '2024-01-12' },
    { equipment: 'Boiler 2', status: 'operational', efficiency: 91, lastMaintenance: '2024-01-14' },
  ];

  const maintenanceSchedule = [
    { task: 'Turbine 1 Inspection', date: '2024-01-25', type: 'preventive', priority: 'medium' },
    { task: 'Generator 2 Repair', date: '2024-01-22', type: 'corrective', priority: 'high' },
    { task: 'Cooling System Check', date: '2024-01-28', type: 'routine', priority: 'low' },
    { task: 'Safety System Test', date: '2024-01-30', type: 'mandatory', priority: 'high' },
  ];

  const performanceMetrics = [
    { name: 'Capacity Factor', value: 87, fill: '#3b82f6' },
    { name: 'Availability', value: 94, fill: '#10b981' },
    { name: 'Reliability', value: 92, fill: '#f59e0b' },
    { name: 'Fuel Efficiency', value: 89, fill: '#8b5cf6' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'operational': return 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-200';
      case 'maintenance': return 'bg-yellow-100 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-200';
      case 'offline': return 'bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-200';
      default: return 'bg-gray-100 dark:bg-gray-900/20 text-gray-800 dark:text-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50 dark:bg-red-900/20';
      case 'medium': return 'text-yellow-600 bg-yellow-50 dark:bg-yellow-900/20';
      case 'low': return 'text-green-600 bg-green-50 dark:bg-green-900/20';
      default: return 'text-gray-600 bg-gray-50 dark:bg-gray-900/20';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            {viewAll ? 'All Power Plants' : 'Power Plant Dashboard'}
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            {viewAll ? 'Overview of all power plant operations and status' : `Real-time monitoring and control for ${selectedPlant}`}
          </p>
        </div>
        
        {(viewAll || user.level >= 7) && (
          <Select value={selectedPlant} onValueChange={setSelectedPlant}>
            <SelectTrigger className="w-64 backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-white/20 dark:border-gray-700/30">
              <SelectValue placeholder="Select Power Plant" />
            </SelectTrigger>
            <SelectContent>
              {powerPlants.map((plant) => (
                <SelectItem key={plant} value={plant}>{plant}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Plant Status Banner */}
      <Card className="backdrop-blur-xl bg-gradient-to-r from-blue-500/10 to-green-500/10 border border-white/20 dark:border-gray-700/30">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-white/20 dark:bg-gray-800/20 rounded-full">
                <Factory className="w-8 h-8 text-blue-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">{selectedPlant}</h3>
                <div className="flex items-center space-x-4 mt-2">
                  <Badge className={getStatusColor(plantData?.status || 'operational')}>
                    {plantData?.status || 'Operational'}
                  </Badge>
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    Capacity: {plantData?.capacity || 1000} MW
                  </span>
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    Last Maintenance: {new Date(plantData?.lastMaintenance || Date.now()).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {((plantData?.currentOutput || 0) / (plantData?.capacity || 1) * 100).toFixed(1)}%
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Capacity Utilization</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Plant KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {plantKPIs.map((kpi, index) => (
          <motion.div
            key={kpi.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg bg-gray-100 dark:bg-gray-800 ${kpi.color}`}>
                      <kpi.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{kpi.title}</p>
                      <div className="flex items-baseline space-x-1">
                        <span className="text-2xl font-bold text-gray-900 dark:text-white">
                          {kpi.value.toLocaleString()}
                        </span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">{kpi.unit}</span>
                      </div>
                      {kpi.capacity && (
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          of {kpi.capacity} {kpi.unit} capacity
                        </p>
                      )}
                    </div>
                  </div>
                  <div className={`flex items-center space-x-1 ${
                    kpi.trend === 'up' ? 'text-green-600' : 
                    kpi.trend === 'down' ? 'text-red-600' : 
                    'text-gray-600'
                  }`}>
                    {kpi.trend === 'up' ? <TrendingUp className="w-4 h-4" /> : 
                     kpi.trend === 'down' ? <TrendingDown className="w-4 h-4" /> : 
                     <Activity className="w-4 h-4" />}
                    <span className="text-sm font-medium">{kpi.change}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="realtime" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="realtime">Real-time Monitoring</TabsTrigger>
          <TabsTrigger value="equipment">Equipment Status</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="realtime" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Real-time Output */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-blue-600" />
                  <span>Real-time Power Output</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={realTimeData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                    <XAxis dataKey="time" className="text-gray-600 dark:text-gray-400" />
                    <YAxis className="text-gray-600 dark:text-gray-400" />
                    <Tooltip />
                    <Area type="monotone" dataKey="output" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.6} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* System Parameters */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Gauge className="w-5 h-5 text-green-600" />
                  <span>System Parameters</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <Thermometer className="w-4 h-4 text-red-500" />
                        <span className="text-sm font-medium">Steam Temperature</span>
                      </div>
                      <span className="text-lg font-bold">248°C</span>
                    </div>
                    <Progress value={82} className="h-2" />
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Normal range: 240-260°C</p>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <Gauge className="w-4 h-4 text-blue-500" />
                        <span className="text-sm font-medium">Steam Pressure</span>
                      </div>
                      <span className="text-lg font-bold">19.1 MPa</span>
                    </div>
                    <Progress value={76} className="h-2" />
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Normal range: 15-25 MPa</p>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <Fuel className="w-4 h-4 text-yellow-500" />
                        <span className="text-sm font-medium">Fuel Consumption</span>
                      </div>
                      <span className="text-lg font-bold">125 T/h</span>
                    </div>
                    <Progress value={65} className="h-2" />
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Optimal range: 120-150 T/h</p>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <Shield className="w-4 h-4 text-green-500" />
                        <span className="text-sm font-medium">Safety Systems</span>
                      </div>
                      <Badge className="bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-200">
                        All Normal
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="equipment" className="space-y-6">
          {/* Equipment Status */}
          <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="w-5 h-5 text-purple-600" />
                <span>Equipment Status Overview</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {equipmentStatus.map((equipment, index) => (
                  <div key={index} className="p-4 rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-medium text-gray-900 dark:text-white">{equipment.equipment}</h4>
                      <Badge className={getStatusColor(equipment.status)}>
                        {equipment.status}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600 dark:text-gray-400">Efficiency</span>
                        <span className="font-medium">{equipment.efficiency}%</span>
                      </div>
                      {equipment.efficiency > 0 && (
                        <Progress value={equipment.efficiency} className="h-1" />
                      )}
                      
                      <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 mt-2">
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-3 h-3" />
                          <span>Last: {equipment.lastMaintenance}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maintenance" className="space-y-6">
          {/* Maintenance Schedule */}
          <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Wrench className="w-5 h-5 text-orange-600" />
                  <span>Maintenance Schedule</span>
                </div>
                <Button size="sm" className="bg-gradient-to-r from-blue-600 to-green-600">
                  Schedule Task
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {maintenanceSchedule.map((task, index) => (
                  <div key={index} className="flex items-center justify-between p-4 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 dark:text-white">{task.task}</h4>
                      <div className="flex items-center space-x-4 mt-2">
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-600 dark:text-gray-400">{task.date}</span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {task.type}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={getPriorityColor(task.priority)}>
                        {task.priority}
                      </Badge>
                      <Button size="sm" variant="outline">
                        Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Performance Metrics */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  <span>Performance Metrics</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RadialBarChart cx="50%" cy="50%" innerRadius="20%" outerRadius="90%" data={performanceMetrics}>
                    <RadialBar minAngle={15} label={{ position: 'insideStart', fill: '#fff' }} background clockWise dataKey="value" />
                    <Legend iconSize={10} layout="vertical" verticalAlign="middle" align="right" />
                  </RadialBarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Monthly Trends */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-blue-600" />
                  <span>Monthly Performance Trends</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={realTimeData.slice(0, 6)}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                    <XAxis dataKey="time" className="text-gray-600 dark:text-gray-400" />
                    <YAxis className="text-gray-600 dark:text-gray-400" />
                    <Tooltip />
                    <Line type="monotone" dataKey="output" stroke="#3b82f6" strokeWidth={2} />
                    <Line type="monotone" dataKey="temperature" stroke="#ef4444" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}