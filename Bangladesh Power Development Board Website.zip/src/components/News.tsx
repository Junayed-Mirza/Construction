import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar, Clock, User, Tag, ArrowRight, 
  Zap, TrendingUp, Award, Globe, Search,
  Filter, ChevronDown, Eye, Share2, BookmarkPlus
} from 'lucide-react';
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

export default function News() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const glassStyle = {
    background: 'rgba(255, 255, 255, 0.1)',
    backdropFilter: 'blur(20px)',
    border: '1px solid rgba(255, 255, 255, 0.2)',
  };

  const newsCategories = [
    { id: 'all', label: 'All News', count: 24 },
    { id: 'projects', label: 'Projects', count: 8 },
    { id: 'technology', label: 'Technology', count: 6 },
    { id: 'sustainability', label: 'Sustainability', count: 5 },
    { id: 'announcements', label: 'Announcements', count: 5 }
  ];

  const featuredNews = [
    {
      id: 1,
      title: 'Rooppur Nuclear Power Plant Achieves 90% Construction Progress',
      excerpt: 'Bangladesh\'s first nuclear power plant project reaches a significant milestone with 90% construction completion, expected to start operations by late 2024.',
      content: 'The Rooppur Nuclear Power Plant project has achieved a remarkable 90% construction progress, marking a significant milestone in Bangladesh\'s nuclear energy journey. The plant, with a total capacity of 2400 MW, is expected to start commercial operations by late 2024. This achievement represents a major step towards Bangladesh\'s energy security and sustainable development goals.',
      category: 'projects',
      date: '2024-01-15',
      author: 'Engineering Team',
      readTime: '5 min read',
      image: 'nuclear-construction',
      featured: true,
      tags: ['Nuclear', 'Construction', 'Milestone']
    },
    {
      id: 2,
      title: 'BPDB Launches Smart Grid Initiative for Rural Areas',
      excerpt: 'Revolutionary smart grid technology deployment begins in rural Bangladesh, promising improved reliability and energy efficiency.',
      content: 'Bangladesh Power Development Board has officially launched its ambitious Smart Grid Initiative targeting rural areas across the country. This cutting-edge technology will enhance power distribution efficiency, reduce outages, and enable better load management. The initiative covers over 500 rural communities in the first phase, with plans to expand nationwide by 2026.',
      category: 'technology',
      date: '2024-01-12',
      author: 'Digital Innovation Team',
      readTime: '4 min read',
      image: 'smart-grid',
      featured: true,
      tags: ['Smart Grid', 'Rural', 'Technology']
    },
    {
      id: 3,
      title: 'Solar Power Capacity Reaches 1 GW Milestone',
      excerpt: 'Bangladesh achieves significant renewable energy milestone with solar power installations crossing 1 gigawatt capacity.',
      content: 'Bangladesh has reached a historic milestone in renewable energy development with solar power installations surpassing 1 gigawatt of total capacity. This achievement is the result of coordinated efforts between BPDB and private sector partners in developing solar parks, rooftop installations, and community solar projects across the country.',
      category: 'sustainability',
      date: '2024-01-10',
      author: 'Renewable Energy Division',
      readTime: '3 min read',
      image: 'solar-milestone',
      featured: true,
      tags: ['Solar', 'Renewable', 'Milestone']
    }
  ];

  const recentNews = [
    {
      id: 4,
      title: 'New Power Purchase Agreement Signed with Independent Power Producers',
      excerpt: 'BPDB signs agreements for additional 500 MW capacity from renewable sources.',
      category: 'announcements',
      date: '2024-01-08',
      author: 'Commercial Team',
      readTime: '3 min read',
      tags: ['PPA', 'IPP', 'Renewable']
    },
    {
      id: 5,
      title: 'Grid Modernization Project Phase 2 Completed',
      excerpt: 'Major infrastructure upgrade enhances power transmission capacity by 30%.',
      category: 'projects',
      date: '2024-01-05',
      author: 'Infrastructure Team',
      readTime: '4 min read',
      tags: ['Grid', 'Modernization', 'Infrastructure']
    },
    {
      id: 6,
      title: 'Energy Efficiency Program Shows 15% Reduction in Consumption',
      excerpt: 'Nationwide energy conservation initiative delivers significant results.',
      category: 'sustainability',
      date: '2024-01-03',
      author: 'Efficiency Division',
      readTime: '3 min read',
      tags: ['Efficiency', 'Conservation', 'Results']
    },
    {
      id: 7,
      title: 'AI-Powered Demand Forecasting System Deployed',
      excerpt: 'Advanced artificial intelligence helps optimize power generation scheduling.',
      category: 'technology',
      date: '2024-01-01',
      author: 'AI Research Team',
      readTime: '5 min read',
      tags: ['AI', 'Forecasting', 'Optimization']
    },
    {
      id: 8,
      title: 'Customer Service Portal Receives Major Update',
      excerpt: 'Enhanced digital platform improves user experience and service accessibility.',
      category: 'announcements',
      date: '2023-12-28',
      author: 'Customer Service Team',
      readTime: '2 min read',
      tags: ['Customer Service', 'Digital', 'Update']
    }
  ];

  const pressReleases = [
    {
      title: 'BPDB Board Approves $2B Investment in Renewable Energy',
      date: '2024-01-14',
      type: 'Investment Announcement'
    },
    {
      title: 'Partnership Agreement Signed with International Energy Consortium',
      date: '2024-01-11',
      type: 'Partnership'
    },
    {
      title: 'New Tariff Structure Approved for Industrial Consumers',
      date: '2024-01-09',
      type: 'Policy Update'
    },
    {
      title: 'BPDB Wins National Excellence Award for Innovation',
      date: '2024-01-06',
      type: 'Recognition'
    }
  ];

  const filteredNews = recentNews.filter(news => {
    const matchesCategory = selectedCategory === 'all' || news.category === selectedCategory;
    const matchesSearch = news.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         news.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section className="pt-32 pb-16 lg:pb-24 px-4 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Badge className="mb-4 bg-orange-500/20 text-orange-600 dark:text-orange-400 border border-orange-500/30">
            Latest Updates
          </Badge>
          <h1 className="text-4xl lg:text-6xl font-bold mb-6">
            News &
            <span className="bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent"> Updates</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Stay informed about the latest developments in Bangladesh's power sector
          </p>
        </motion.div>

        {/* Search and Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-8"
        >
          <Card className="p-6 border-0 shadow-lg" style={glassStyle}>
            <div className="flex flex-col md:flex-row gap-4 items-center">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  placeholder="Search news..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-white/10 border-white/20"
                />
              </div>
              <div className="flex gap-2 flex-wrap">
                {newsCategories.map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category.id)}
                    className={`rounded-lg ${
                      selectedCategory === category.id
                        ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white'
                        : 'bg-white/10 border-white/20 hover:bg-white/20'
                    }`}
                  >
                    {category.label}
                    <Badge variant="secondary" className="ml-2 text-xs">
                      {category.count}
                    </Badge>
                  </Button>
                ))}
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Featured News */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mb-12"
        >
          <h2 className="text-2xl font-bold mb-6">Featured Stories</h2>
          <div className="grid lg:grid-cols-3 gap-6">
            {featuredNews.map((news, index) => (
              <motion.div
                key={news.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className="group cursor-pointer"
              >
                <Card 
                  className={`border-0 shadow-xl overflow-hidden h-full ${
                    index === 0 ? 'lg:col-span-2 lg:row-span-2' : ''
                  }`}
                  style={glassStyle}
                >
                  {/* Image Placeholder */}
                  <div className={`bg-gradient-to-br from-blue-500 to-green-500 ${
                    index === 0 ? 'h-64 lg:h-80' : 'h-48'
                  } relative overflow-hidden`}>
                    <motion.div
                      className="absolute inset-0 bg-black/20"
                      whileHover={{ backgroundColor: 'rgba(0,0,0,0.1)' }}
                    />
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-white/20 text-white border-white/30">
                        {news.category}
                      </Badge>
                    </div>
                    <div className="absolute bottom-4 right-4">
                      <motion.div
                        whileHover={{ scale: 1.1 }}
                        className="bg-white/20 backdrop-blur-md rounded-full p-2"
                      >
                        <Eye className="w-4 h-4 text-white" />
                      </motion.div>
                    </div>
                  </div>

                  <div className="p-6">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {new Date(news.date).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {news.readTime}
                      </div>
                      <div className="flex items-center gap-1">
                        <User className="w-4 h-4" />
                        {news.author}
                      </div>
                    </div>

                    <h3 className={`font-bold mb-3 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-orange-600 group-hover:to-red-600 group-hover:bg-clip-text transition-all duration-300 ${
                      index === 0 ? 'text-xl lg:text-2xl' : 'text-lg'
                    }`}>
                      {news.title}
                    </h3>

                    <p className="text-muted-foreground mb-4 leading-relaxed">
                      {news.excerpt}
                    </p>

                    <div className="flex items-center justify-between">
                      <div className="flex gap-2">
                        {news.tags.map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs bg-white/10 border-white/20">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      
                      <div className="flex gap-2">
                        <Button size="sm" variant="ghost" className="p-2">
                          <Share2 className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" className="p-2">
                          <BookmarkPlus className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      className="w-full mt-4 group-hover:bg-orange-500 group-hover:text-white transition-all duration-300"
                    >
                      Read Full Article
                      <motion.div
                        animate={{ x: [0, 5, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                      >
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </motion.div>
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Recent News & Press Releases */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="grid lg:grid-cols-3 gap-8"
        >
          {/* Recent News */}
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold mb-6">Recent News</h2>
            <div className="space-y-4">
              <AnimatePresence>
                {filteredNews.map((news, index) => (
                  <motion.div
                    key={news.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.02 }}
                    className="group cursor-pointer"
                  >
                    <Card className="p-6 border-0 shadow-lg" style={glassStyle}>
                      <div className="flex items-start gap-4">
                        <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                          {new Date(news.date).getDate()}
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline" className="text-xs bg-white/10 border-white/20">
                              {news.category}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {new Date(news.date).toLocaleDateString()}
                            </span>
                          </div>
                          
                          <h3 className="font-bold mb-2 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-orange-600 group-hover:to-red-600 group-hover:bg-clip-text transition-all duration-300">
                            {news.title}
                          </h3>
                          
                          <p className="text-sm text-muted-foreground mb-3">
                            {news.excerpt}
                          </p>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span>{news.author}</span>
                              <span>{news.readTime}</span>
                            </div>
                            
                            <Button size="sm" variant="ghost">
                              <ArrowRight className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          {/* Press Releases */}
          <div>
            <h2 className="text-2xl font-bold mb-6">Press Releases</h2>
            <Card className="p-6 border-0 shadow-lg" style={glassStyle}>
              <div className="space-y-4">
                {pressReleases.map((release, index) => (
                  <motion.div
                    key={release.title}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.02 }}
                    className="p-4 rounded-lg bg-white/5 border border-white/10 cursor-pointer group"
                  >
                    <Badge variant="outline" className="mb-2 text-xs bg-white/10 border-white/20">
                      {release.type}
                    </Badge>
                    <h4 className="font-medium mb-2 text-sm group-hover:text-orange-500 transition-colors">
                      {release.title}
                    </h4>
                    <p className="text-xs text-muted-foreground">
                      {new Date(release.date).toLocaleDateString()}
                    </p>
                  </motion.div>
                ))}
              </div>
              
              <Button variant="outline" className="w-full mt-6">
                View All Press Releases
              </Button>
            </Card>

            {/* Newsletter Signup */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="mt-8"
            >
              <Card className="p-6 border-0 shadow-lg text-center" style={glassStyle}>
                <motion.div
                  className="inline-flex p-3 rounded-full bg-gradient-to-br from-orange-500 to-red-500 text-white mb-4"
                  animate={{
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                  }}
                >
                  <TrendingUp className="w-6 h-6" />
                </motion.div>
                <h3 className="font-bold mb-2">Stay Updated</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Subscribe to our newsletter for the latest power sector updates
                </p>
                <Input
                  placeholder="Enter your email"
                  className="mb-4 bg-white/10 border-white/20"
                />
                <Button className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600">
                  Subscribe
                </Button>
              </Card>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}