import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  MapPin, Phone, Mail, Clock, Send, MessageCircle,
  Building, Users, Zap, FileText, AlertCircle,
  CheckCircle, User, Globe, Calendar
} from 'lucide-react';
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Label } from "./ui/label";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    category: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const glassStyle = {
    background: 'rgba(255, 255, 255, 0.1)',
    backdropFilter: 'blur(20px)',
    border: '1px solid rgba(255, 255, 255, 0.2)',
  };

  const contactInfo = [
    {
      icon: Building,
      title: 'Head Office',
      details: ['WASA Bhaban (15th Floor)', 'Kawran Bazar, Dhaka-1215', 'Bangladesh'],
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Phone,
      title: 'Phone Numbers',
      details: ['Hotline: 16123', 'Customer Service: +880-2-9611391', 'Emergency: 999'],
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: Mail,
      title: 'Email Addresses',
      details: ['info@bpdb.gov.bd', 'customer.service@bpdb.gov.bd', 'emergency@bpdb.gov.bd'],
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: Clock,
      title: 'Business Hours',
      details: ['Sunday - Thursday: 9:00 AM - 5:00 PM', 'Friday: 9:00 AM - 12:00 PM', '24/7 Emergency Support'],
      color: 'from-orange-500 to-red-500'
    }
  ];

  const quickServices = [
    {
      icon: Zap,
      title: 'Power Outage Report',
      description: 'Report power outages in your area',
      action: 'Report Now',
      urgent: true
    },
    {
      icon: FileText,
      title: 'New Connection',
      description: 'Apply for new electricity connection',
      action: 'Apply Online',
      urgent: false
    },
    {
      icon: MessageCircle,
      title: 'Bill Inquiry',
      description: 'Check your electricity bill and payment status',
      action: 'Check Bill',
      urgent: false
    },
    {
      icon: Users,
      title: 'Customer Support',
      description: 'Get help from our customer service team',
      action: 'Contact Support',
      urgent: false
    }
  ];

  const departments = [
    'Customer Service',
    'Technical Support',
    'Billing & Payments',
    'New Connections',
    'Emergency Services',
    'Corporate Affairs',
    'Human Resources',
    'Procurement',
    'Legal Department'
  ];

  const regionalOffices = [
    {
      region: 'Dhaka Region',
      address: 'WASA Bhaban, Kawran Bazar, Dhaka',
      phone: '+880-2-9611391',
      email: 'dhaka@bpdb.gov.bd'
    },
    {
      region: 'Chittagong Region',
      address: 'Agrabad Commercial Area, Chittagong',
      phone: '+880-31-710515',
      email: 'chittagong@bpdb.gov.bd'
    },
    {
      region: 'Sylhet Region',
      address: 'Zindabazar, Sylhet',
      phone: '+880-821-715234',
      email: 'sylhet@bpdb.gov.bd'
    },
    {
      region: 'Rajshahi Region',
      address: 'Shaheb Bazar, Rajshahi',
      phone: '+880-721-775923',
      email: 'rajshahi@bpdb.gov.bd'
    },
    {
      region: 'Khulna Region',
      address: 'Shibbari, Khulna',
      phone: '+880-41-720856',
      email: 'khulna@bpdb.gov.bd'
    },
    {
      region: 'Barisal Region',
      address: 'Band Road, Barisal',
      phone: '+880-431-64725',
      email: 'barisal@bpdb.gov.bd'
    }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSelectChange = (value: string) => {
    setFormData({
      ...formData,
      category: value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setSubmitted(true);
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: '',
        category: '',
        message: ''
      });
    }, 3000);
  };

  return (
    <section className="pt-32 pb-16 lg:pb-24 px-4 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Badge className="mb-4 bg-blue-500/20 text-blue-600 dark:text-blue-400 border border-blue-500/30">
            Get in Touch
          </Badge>
          <h1 className="text-4xl lg:text-6xl font-bold mb-6">
            Contact
            <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent"> BPDB</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            We're here to help with all your power-related needs. Reach out to us anytime.
          </p>
        </motion.div>

        {/* Emergency Banner */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-12"
        >
          <Card className="p-6 border-0 shadow-xl bg-gradient-to-r from-red-500/20 to-orange-500/20 border border-red-500/30">
            <div className="flex items-center justify-center gap-4 text-center">
              <motion.div
                animate={{
                  scale: [1, 1.2, 1],
                  rotate: [0, 5, -5, 0]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity
                }}
              >
                <AlertCircle className="w-8 h-8 text-red-500" />
              </motion.div>
              <div>
                <h3 className="text-xl font-bold text-red-600 dark:text-red-400 mb-2">
                  Emergency Power Outage?
                </h3>
                <p className="text-muted-foreground mb-4">
                  For immediate assistance with power outages or electrical emergencies
                </p>
                <div className="flex flex-col sm:flex-row gap-2 justify-center">
                  <Button
                    size="lg"
                    className="bg-red-500 hover:bg-red-600 text-white"
                  >
                    <Phone className="mr-2 w-5 h-5" />
                    Call Emergency: 999
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    className="border-red-500/30 text-red-600 hover:bg-red-500/10"
                  >
                    <MessageCircle className="mr-2 w-5 h-5" />
                    Report Online
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Quick Services */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mb-12"
        >
          <h2 className="text-2xl font-bold mb-6 text-center">Quick Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickServices.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="group cursor-pointer"
              >
                <Card 
                  className={`p-6 text-center border-0 shadow-lg relative overflow-hidden ${
                    service.urgent ? 'border-2 border-red-500/30' : ''
                  }`}
                  style={glassStyle}
                >
                  {service.urgent && (
                    <Badge className="absolute top-2 right-2 bg-red-500/20 text-red-600 border border-red-500/30 text-xs">
                      Urgent
                    </Badge>
                  )}
                  
                  <motion.div
                    className={`inline-flex p-4 rounded-xl bg-gradient-to-br ${
                      service.urgent ? 'from-red-500 to-orange-500' : 'from-blue-500 to-green-500'
                    } text-white mb-4`}
                    whileHover={{ rotate: 10 }}
                  >
                    <service.icon className="w-6 h-6" />
                  </motion.div>
                  
                  <h3 className="font-bold mb-2">{service.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {service.description}
                  </p>
                  
                  <Button
                    size="sm"
                    variant="outline"
                    className={`w-full group-hover:${
                      service.urgent ? 'bg-red-500 text-white' : 'bg-blue-500 text-white'
                    } transition-all duration-300`}
                  >
                    {service.action}
                  </Button>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="lg:col-span-2"
          >
            <Card className="p-8 border-0 shadow-xl" style={glassStyle}>
              <h2 className="text-2xl font-bold mb-6">Send us a Message</h2>
              
              {submitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-12"
                >
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 0.5 }}
                  >
                    <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                  </motion.div>
                  <h3 className="text-xl font-bold text-green-600 mb-2">
                    Message Sent Successfully!
                  </h3>
                  <p className="text-muted-foreground">
                    Thank you for contacting us. We'll get back to you within 24 hours.
                  </p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        className="bg-white/10 border-white/20"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className="bg-white/10 border-white/20"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="bg-white/10 border-white/20"
                      />
                    </div>
                    <div>
                      <Label htmlFor="category">Department</Label>
                      <Select onValueChange={handleSelectChange}>
                        <SelectTrigger className="bg-white/10 border-white/20">
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                        <SelectContent>
                          {departments.map((dept) => (
                            <SelectItem key={dept} value={dept.toLowerCase().replace(/\s+/g, '-')}>
                              {dept}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="subject">Subject *</Label>
                    <Input
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleInputChange}
                      required
                      className="bg-white/10 border-white/20"
                    />
                  </div>

                  <div>
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      required
                      rows={6}
                      className="bg-white/10 border-white/20"
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white"
                  >
                    {isSubmitting ? (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      >
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full" />
                      </motion.div>
                    ) : (
                      <>
                        <Send className="mr-2 w-5 h-5" />
                        Send Message
                      </>
                    )}
                  </Button>
                </form>
              )}
            </Card>
          </motion.div>

          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="space-y-6"
          >
            {contactInfo.map((info, index) => (
              <motion.div
                key={info.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
              >
                <Card className="p-6 border-0 shadow-lg" style={glassStyle}>
                  <motion.div
                    className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${info.color} text-white mb-4`}
                    animate={{
                      rotate: [0, 5, -5, 0],
                    }}
                    transition={{
                      duration: 4,
                      repeat: Infinity,
                      delay: index * 0.5,
                    }}
                  >
                    <info.icon className="w-6 h-6" />
                  </motion.div>
                  
                  <h3 className="font-bold mb-3">{info.title}</h3>
                  <div className="space-y-1">
                    {info.details.map((detail, detailIndex) => (
                      <p key={detailIndex} className="text-sm text-muted-foreground">
                        {detail}
                      </p>
                    ))}
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Regional Offices */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1 }}
        >
          <h2 className="text-2xl font-bold mb-6 text-center">Regional Offices</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {regionalOffices.map((office, index) => (
              <motion.div
                key={office.region}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
              >
                <Card className="p-4 border-0 shadow-lg" style={glassStyle}>
                  <div className="flex items-start gap-3">
                    <motion.div
                      className="p-2 rounded-lg bg-gradient-to-br from-blue-500 to-green-500 text-white"
                      whileHover={{ rotate: 10 }}
                    >
                      <MapPin className="w-4 h-4" />
                    </motion.div>
                    <div className="flex-1">
                      <h4 className="font-bold text-sm mb-1">{office.region}</h4>
                      <p className="text-xs text-muted-foreground mb-2">{office.address}</p>
                      <div className="space-y-1">
                        <div className="flex items-center gap-1 text-xs">
                          <Phone className="w-3 h-3" />
                          {office.phone}
                        </div>
                        <div className="flex items-center gap-1 text-xs">
                          <Mail className="w-3 h-3" />
                          {office.email}
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}