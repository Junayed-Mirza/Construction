import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { User, Mail, Phone, Building, Factory, UserCheck, Key, Shield, Save, Edit3, X, Check, Eye, EyeOff, Smartphone, AlertTriangle } from 'lucide-react';
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Switch } from "../ui/switch";
import { Separator } from "../ui/separator";
import { Alert, AlertDescription } from "../ui/alert";
import { projectId } from '../../utils/supabase/info';

interface UserProfileProps {
  user: any;
  onUserUpdate: (updatedUser: any) => void;
  onClose: () => void;
}

export default function UserProfile({ user, onUserUpdate, onClose }: UserProfileProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [config, setConfig] = useState<any>(null);
  
  // Profile form data
  const [profileData, setProfileData] = useState({
    name: user.name || '',
    email: user.email || '',
    phone: user.phone || '',
    role: user.role || '',
    department: user.department || '',
    powerPlant: user.powerPlant || ''
  });

  // Password change data
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  });

  // Security settings
  const [securitySettings, setSecuritySettings] = useState({
    twoFactorEnabled: user.twoFactorEnabled || false,
    emailNotifications: user.emailNotifications !== false,
    loginAlerts: user.loginAlerts !== false,
    sessionTimeout: user.sessionTimeout || 30
  });

  // Fetch configuration data
  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/config`, {
          headers: {
            'Authorization': `Bearer ${user.accessToken}`,
            'Content-Type': 'application/json'
          }
        });
        
        if (response.ok) {
          const configData = await response.json();
          setConfig(configData);
        }
      } catch (error) {
        console.error('Failed to fetch configuration:', error);
      }
    };

    fetchConfig();
  }, [user.accessToken]);

  const handleProfileUpdate = async () => {
    setIsLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/auth/update-profile`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${user.accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId: user.id,
          ...profileData
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to update profile');
      }

      const result = await response.json();
      setSuccess('Profile updated successfully');
      setIsEditing(false);
      
      // Update user in parent component
      onUserUpdate({
        ...user,
        ...profileData
      });

    } catch (error: any) {
      console.error('Profile update error:', error);
      setError(error.message || 'Failed to update profile');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePasswordChange = async () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setError('New passwords do not match');
      return;
    }

    if (passwordData.newPassword.length < 8) {
      setError('New password must be at least 8 characters long');
      return;
    }

    setIsLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/auth/change-password`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${user.accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId: user.id,
          currentPassword: passwordData.currentPassword,
          newPassword: passwordData.newPassword
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to change password');
      }

      setSuccess('Password changed successfully');
      setPasswordData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });

    } catch (error: any) {
      console.error('Password change error:', error);
      setError(error.message || 'Failed to change password');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSecurityUpdate = async () => {
    setIsLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/auth/update-security`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${user.accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId: user.id,
          ...securitySettings
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to update security settings');
      }

      setSuccess('Security settings updated successfully');
      
      // Update user in parent component
      onUserUpdate({
        ...user,
        ...securitySettings
      });

    } catch (error: any) {
      console.error('Security update error:', error);
      setError(error.message || 'Failed to update security settings');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setProfileData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePasswordInputChange = (field: string, value: string) => {
    setPasswordData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const getLevelBadge = (level: number) => {
    if (level >= 8) return { color: 'bg-purple-500', text: 'Executive' };
    if (level >= 6) return { color: 'bg-blue-500', text: 'Manager' };
    if (level >= 4) return { color: 'bg-green-500', text: 'Senior' };
    if (level >= 2) return { color: 'bg-yellow-500', text: 'Mid-Level' };
    return { color: 'bg-gray-500', text: 'Entry Level' };
  };

  const levelBadge = getLevelBadge(user.level || 1);

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="w-full max-w-4xl max-h-[90vh] overflow-hidden"
      >
        <Card className="backdrop-blur-xl bg-white/90 dark:bg-gray-900/90 border border-white/20 dark:border-gray-700/30 shadow-2xl">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-green-600 rounded-full flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  User Profile
                </h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Manage your account settings and security
                </p>
              </div>
            </div>
            <Button
              onClick={onClose}
              variant="ghost"
              size="sm"
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Content */}
          <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
            {/* Status Messages */}
            {error && (
              <Alert className="mb-6 border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20">
                <AlertTriangle className="h-4 w-4 text-red-600 dark:text-red-400" />
                <AlertDescription className="text-red-600 dark:text-red-400">
                  {error}
                </AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="mb-6 border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20">
                <Check className="h-4 w-4 text-green-600 dark:text-green-400" />
                <AlertDescription className="text-green-600 dark:text-green-400">
                  {success}
                </AlertDescription>
              </Alert>
            )}

            <Tabs defaultValue="profile" className="space-y-6">
              <TabsList className="grid grid-cols-3 w-full">
                <TabsTrigger value="profile">Profile</TabsTrigger>
                <TabsTrigger value="security">Security</TabsTrigger>
                <TabsTrigger value="preferences">Preferences</TabsTrigger>
              </TabsList>

              {/* Profile Tab */}
              <TabsContent value="profile" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Basic Information */}
                  <Card className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold">Basic Information</h3>
                      <Button
                        onClick={() => setIsEditing(!isEditing)}
                        variant="outline"
                        size="sm"
                      >
                        {isEditing ? <X className="w-4 h-4" /> : <Edit3 className="w-4 h-4" />}
                      </Button>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <Label>Full Name</Label>
                        {isEditing ? (
                          <Input
                            value={profileData.name}
                            onChange={(e) => handleInputChange('name', e.target.value)}
                            className="mt-1"
                          />
                        ) : (
                          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">{user.name}</p>
                        )}
                      </div>

                      <div>
                        <Label>Email Address</Label>
                        {isEditing ? (
                          <Input
                            type="email"
                            value={profileData.email}
                            onChange={(e) => handleInputChange('email', e.target.value)}
                            className="mt-1"
                          />
                        ) : (
                          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">{user.email}</p>
                        )}
                      </div>

                      <div>
                        <Label>Phone Number</Label>
                        {isEditing ? (
                          <Input
                            type="tel"
                            value={profileData.phone}
                            onChange={(e) => handleInputChange('phone', e.target.value)}
                            placeholder="+880..."
                            className="mt-1"
                          />
                        ) : (
                          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                            {user.phone || 'Not provided'}
                          </p>
                        )}
                      </div>

                      {isEditing && (
                        <Button
                          onClick={handleProfileUpdate}
                          disabled={isLoading}
                          className="w-full"
                        >
                          {isLoading ? 'Updating...' : 'Save Changes'}
                        </Button>
                      )}
                    </div>
                  </Card>

                  {/* Role & Department */}
                  <Card className="p-6">
                    <h3 className="text-lg font-semibold mb-4">Role & Department</h3>
                    
                    <div className="space-y-4">
                      <div>
                        <Label>Role/Designation</Label>
                        {isEditing && config?.roles ? (
                          <Select
                            value={profileData.role}
                            onValueChange={(value) => handleInputChange('role', value)}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {config.roles.map((role: string) => (
                                <SelectItem key={role} value={role}>{role}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        ) : (
                          <div className="mt-1 flex items-center space-x-2">
                            <p className="text-sm text-gray-600 dark:text-gray-400">{user.role}</p>
                            <Badge className={`${levelBadge.color} text-white`}>
                              {levelBadge.text}
                            </Badge>
                          </div>
                        )}
                      </div>

                      <div>
                        <Label>Department</Label>
                        {isEditing && config?.departments ? (
                          <Select
                            value={profileData.department}
                            onValueChange={(value) => handleInputChange('department', value)}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {config.departments.map((dept: string) => (
                                <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        ) : (
                          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">{user.department}</p>
                        )}
                      </div>

                      <div>
                        <Label>Power Plant</Label>
                        {isEditing && config?.powerPlants ? (
                          <Select
                            value={profileData.powerPlant}
                            onValueChange={(value) => handleInputChange('powerPlant', value)}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="">None</SelectItem>
                              {config.powerPlants.map((plant: string) => (
                                <SelectItem key={plant} value={plant}>{plant}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        ) : (
                          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                            {user.powerPlant || 'Not assigned'}
                          </p>
                        )}
                      </div>
                    </div>
                  </Card>
                </div>
              </TabsContent>

              {/* Security Tab */}
              <TabsContent value="security" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Password Change */}
                  <Card className="p-6">
                    <h3 className="text-lg font-semibold mb-4">Change Password</h3>
                    
                    <div className="space-y-4">
                      <div>
                        <Label>Current Password</Label>
                        <div className="relative mt-1">
                          <Input
                            type={showPasswords.current ? "text" : "password"}
                            value={passwordData.currentPassword}
                            onChange={(e) => handlePasswordInputChange('currentPassword', e.target.value)}
                            className="pr-10"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPasswords(prev => ({ ...prev, current: !prev.current }))}
                            className="absolute right-3 top-3 text-gray-400"
                          >
                            {showPasswords.current ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </div>

                      <div>
                        <Label>New Password</Label>
                        <div className="relative mt-1">
                          <Input
                            type={showPasswords.new ? "text" : "password"}
                            value={passwordData.newPassword}
                            onChange={(e) => handlePasswordInputChange('newPassword', e.target.value)}
                            className="pr-10"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPasswords(prev => ({ ...prev, new: !prev.new }))}
                            className="absolute right-3 top-3 text-gray-400"
                          >
                            {showPasswords.new ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </div>

                      <div>
                        <Label>Confirm New Password</Label>
                        <div className="relative mt-1">
                          <Input
                            type={showPasswords.confirm ? "text" : "password"}
                            value={passwordData.confirmPassword}
                            onChange={(e) => handlePasswordInputChange('confirmPassword', e.target.value)}
                            className="pr-10"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPasswords(prev => ({ ...prev, confirm: !prev.confirm }))}
                            className="absolute right-3 top-3 text-gray-400"
                          >
                            {showPasswords.confirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </div>

                      <Button
                        onClick={handlePasswordChange}
                        disabled={isLoading || !passwordData.currentPassword || !passwordData.newPassword}
                        className="w-full"
                      >
                        {isLoading ? 'Changing...' : 'Change Password'}
                      </Button>
                    </div>
                  </Card>

                  {/* Security Settings */}
                  <Card className="p-6">
                    <h3 className="text-lg font-semibold mb-4">Security Settings</h3>
                    
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Shield className="w-5 h-5 text-blue-600" />
                          <div>
                            <Label>Two-Factor Authentication</Label>
                            <p className="text-xs text-gray-500">Add an extra layer of security</p>
                          </div>
                        </div>
                        <Switch
                          checked={securitySettings.twoFactorEnabled}
                          onCheckedChange={(checked) => 
                            setSecuritySettings(prev => ({ ...prev, twoFactorEnabled: checked }))
                          }
                        />
                      </div>

                      <Separator />

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Mail className="w-5 h-5 text-green-600" />
                          <div>
                            <Label>Email Notifications</Label>
                            <p className="text-xs text-gray-500">Receive security alerts via email</p>
                          </div>
                        </div>
                        <Switch
                          checked={securitySettings.emailNotifications}
                          onCheckedChange={(checked) => 
                            setSecuritySettings(prev => ({ ...prev, emailNotifications: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <AlertTriangle className="w-5 h-5 text-orange-600" />
                          <div>
                            <Label>Login Alerts</Label>
                            <p className="text-xs text-gray-500">Get notified of new logins</p>
                          </div>
                        </div>
                        <Switch
                          checked={securitySettings.loginAlerts}
                          onCheckedChange={(checked) => 
                            setSecuritySettings(prev => ({ ...prev, loginAlerts: checked }))
                          }
                        />
                      </div>

                      <Button
                        onClick={handleSecurityUpdate}
                        disabled={isLoading}
                        className="w-full"
                      >
                        {isLoading ? 'Updating...' : 'Update Security Settings'}
                      </Button>
                    </div>
                  </Card>
                </div>
              </TabsContent>

              {/* Preferences Tab */}
              <TabsContent value="preferences" className="space-y-6">
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Account Information</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label>Account ID</Label>
                      <p className="mt-1 text-sm text-gray-600 dark:text-gray-400 font-mono">{user.id}</p>
                    </div>
                    
                    <div>
                      <Label>Member Since</Label>
                      <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                        {new Date(user.createdAt || Date.now()).toLocaleDateString()}
                      </p>
                    </div>
                    
                    <div>
                      <Label>Account Status</Label>
                      <div className="mt-1">
                        <Badge variant={user.isActive ? "default" : "destructive"}>
                          {user.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                    </div>
                    
                    <div>
                      <Label>Permission Level</Label>
                      <div className="mt-1">
                        <Badge className={`${levelBadge.color} text-white`}>
                          Level {user.level} - {levelBadge.text}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}