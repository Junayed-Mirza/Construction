import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Shield, Smartphone, Mail, ArrowLeft, RefreshCw, Check } from 'lucide-react';
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface TwoFactorAuthProps {
  user: any;
  onSuccess: (user: any) => void;
  onBack: () => void;
  method: 'email' | 'sms';
}

export default function TwoFactorAuth({ user, onSuccess, onBack, method }: TwoFactorAuthProps) {
  const [verificationCode, setVerificationCode] = useState(['', '', '', '', '', '']);
  const [isLoading, setIsLoading] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [error, setError] = useState('');
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes
  const [isVerified, setIsVerified] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Countdown timer
  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [timeLeft]);

  // Auto-send verification code on mount
  useEffect(() => {
    sendVerificationCode();
  }, []);

  const sendVerificationCode = async () => {
    setIsResending(true);
    setError('');

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/auth/send-2fa`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${user.accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId: user.id,
          method: method,
          contact: method === 'email' ? user.email : user.phone
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to send verification code');
      }

      setTimeLeft(300); // Reset timer
    } catch (error: any) {
      console.error('2FA send error:', error);
      setError(error.message || 'Failed to send verification code');
    } finally {
      setIsResending(false);
    }
  };

  const handleCodeChange = (index: number, value: string) => {
    if (value.length > 1) return; // Only allow single digit

    const newCode = [...verificationCode];
    newCode[index] = value;
    setVerificationCode(newCode);

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    // Auto-submit when all fields are filled
    if (newCode.every(digit => digit !== '') && !isLoading) {
      handleVerifyCode(newCode.join(''));
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !verificationCode[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleVerifyCode = async (code?: string) => {
    const codeToVerify = code || verificationCode.join('');
    if (codeToVerify.length !== 6) {
      setError('Please enter all 6 digits');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/auth/verify-2fa`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${user.accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId: user.id,
          code: codeToVerify,
          method: method
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Invalid verification code');
      }

      const result = await response.json();
      setIsVerified(true);
      
      // Update user with 2FA verified status
      setTimeout(() => {
        onSuccess({
          ...user,
          twoFactorVerified: true,
          verificationMethod: method
        });
      }, 1000);

    } catch (error: any) {
      console.error('2FA verification error:', error);
      setError(error.message || 'Verification failed. Please try again.');
      // Clear the code on error
      setVerificationCode(['', '', '', '', '', '']);
      inputRefs.current[0]?.focus();
    } finally {
      setIsLoading(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getContactDisplay = () => {
    if (method === 'email') {
      const email = user.email;
      return email.replace(/(.{2}).*(@.*)/, '$1***$2');
    } else {
      const phone = user.phone || '+880********';
      return phone.replace(/(\+880)(\d{2}).*(\d{2})/, '$1$2***$3');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900 py-12">
      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-30 dark:opacity-20 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 via-transparent to-green-50/50 dark:from-blue-900/20 dark:via-transparent dark:to-green-900/20"></div>
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%234f46e5' fill-opacity='0.1'%3E%3Cpath d='m36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          backgroundRepeat: 'repeat'
        }}></div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 w-full max-w-md p-6"
      >
        <Card className="p-8 backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30 shadow-2xl">
          {/* Back Button */}
          <div className="mb-6">
            <button
              onClick={onBack}
              className="flex items-center text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back
            </button>
          </div>

          {/* Header */}
          <div className="text-center mb-8">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="mx-auto w-16 h-16 bg-gradient-to-r from-blue-600 to-green-600 rounded-full flex items-center justify-center mb-4"
            >
              {isVerified ? (
                <Check className="w-8 h-8 text-white" />
              ) : (
                <Shield className="w-8 h-8 text-white" />
              )}
            </motion.div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              {isVerified ? 'Verification Complete' : 'Two-Factor Authentication'}
            </h1>
            <p className="text-gray-600 dark:text-gray-300">
              {isVerified 
                ? 'You have been successfully verified'
                : `Enter the 6-digit code sent to your ${method === 'email' ? 'email' : 'phone'}`
              }
            </p>
            {!isVerified && (
              <div className="mt-2 flex items-center justify-center space-x-2">
                {method === 'email' ? (
                  <Mail className="w-4 h-4 text-blue-600" />
                ) : (
                  <Smartphone className="w-4 h-4 text-green-600" />
                )}
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {getContactDisplay()}
                </span>
              </div>
            )}
          </div>

          {isVerified ? (
            /* Success State */
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center space-y-6"
            >
              <div className="p-6 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                <Check className="w-12 h-12 text-green-600 dark:text-green-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-green-900 dark:text-green-100 mb-2">
                  Authentication Successful
                </h3>
                <p className="text-green-700 dark:text-green-300 text-sm">
                  Your identity has been verified. Redirecting to dashboard...
                </p>
              </div>
            </motion.div>
          ) : (
            /* Verification Form */
            <div className="space-y-6">
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-600 dark:text-red-400 text-sm"
                >
                  {error}
                </motion.div>
              )}

              <div className="space-y-4">
                <Label>Verification Code</Label>
                <div className="flex justify-center space-x-2">
                  {verificationCode.map((digit, index) => (
                    <Input
                      key={index}
                      ref={(el) => (inputRefs.current[index] = el)}
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleCodeChange(index, e.target.value.replace(/\D/g, ''))}
                      onKeyDown={(e) => handleKeyDown(index, e)}
                      className="w-12 h-12 text-center text-lg font-bold backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-white/20 dark:border-gray-700/30"
                      disabled={isLoading || isVerified}
                    />
                  ))}
                </div>
              </div>

              {timeLeft > 0 && (
                <div className="text-center">
                  <Badge variant="outline" className="bg-blue-50 dark:bg-blue-900/20">
                    Code expires in {formatTime(timeLeft)}
                  </Badge>
                </div>
              )}

              <div className="flex space-x-3">
                <Button
                  onClick={() => handleVerifyCode()}
                  disabled={isLoading || verificationCode.some(digit => digit === '')}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white shadow-lg"
                >
                  {isLoading ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                    />
                  ) : (
                    'Verify'
                  )}
                </Button>

                <Button
                  onClick={sendVerificationCode}
                  disabled={isResending || timeLeft > 240} // Can resend after 1 minute
                  variant="outline"
                  className="backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-white/20 dark:border-gray-700/30"
                >
                  {isResending ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <RefreshCw className="w-4 h-4" />
                  )}
                </Button>
              </div>

              {timeLeft <= 240 && timeLeft > 0 && (
                <p className="text-center text-sm text-gray-500 dark:text-gray-400">
                  Didn't receive the code? Click the resend button above.
                </p>
              )}

              {timeLeft === 0 && (
                <div className="text-center">
                  <p className="text-sm text-red-600 dark:text-red-400 mb-3">
                    Verification code has expired.
                  </p>
                  <Button
                    onClick={sendVerificationCode}
                    disabled={isResending}
                    variant="outline"
                    className="backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-white/20 dark:border-gray-700/30"
                  >
                    {isResending ? 'Sending...' : 'Send New Code'}
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* Security Notice */}
          <div className="mt-6 p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
            <p className="text-amber-800 dark:text-amber-200 text-sm">
              <strong>Security Notice:</strong> This additional verification step helps protect your account. 
              Never share your verification code with anyone.
            </p>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}