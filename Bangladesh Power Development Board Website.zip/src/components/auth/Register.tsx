import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { User, Mail, Lock, Eye, EyeOff, Zap, UserCheck, Building, Factory } from 'lucide-react';
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Card } from "../ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { projectId, publicAnonKey } from '../../utils/supabase/info';
import { supabase } from '../../utils/supabase/client';

interface RegisterProps {
  onRegister: (user: any) => void;
  onSwitchToLogin: () => void;
  onBack?: () => void;
}

export default function Register({ onRegister, onSwitchToLogin, onBack }: RegisterProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: '',
    department: '',
    powerPlant: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [config, setConfig] = useState<any>(null);

  // Fetch configuration data
  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/config`, {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          }
        });
        
        if (response.ok) {
          const configData = await response.json();
          setConfig(configData);
        } else {
          throw new Error(`Server responded with status: ${response.status}`);
        }
      } catch (error) {
        console.error('Failed to fetch configuration:', error);
        
        // Provide fallback configuration when server is unavailable
        const fallbackConfig = {
          roles: [
            'Chairman', 'Managing Director', 'Director (Generation)', 'Director (Transmission)',
            'Director (Distribution)', 'Director (Finance)', 'Director (HR)', 'Director (Planning)',
            'GM Generation', 'GM Transmission', 'GM Distribution', 'GM Finance', 'GM HR',
            'GM Planning', 'GM Operations', 'GM Maintenance', 'GM IT', 'GM Audit',
            'DGM Generation', 'DGM Transmission', 'DGM Distribution', 'DGM Finance',
            'DGM HR', 'DGM Planning', 'DGM Operations', 'DGM Maintenance', 'DGM IT',
            'AGM Generation', 'AGM Transmission', 'AGM Distribution', 'AGM Finance',
            'Chief Engineer', 'Senior Engineer (Electrical)', 'Senior Engineer (Mechanical)',
            'Senior Engineer (Civil)', 'Senior Engineer (Control & Instrumentation)',
            'Engineer (Electrical)', 'Engineer (Mechanical)', 'Engineer (Civil)',
            'Engineer (Control & Instrumentation)', 'Engineer (Electronics)',
            'Assistant Engineer (Electrical)', 'Assistant Engineer (Mechanical)',
            'Plant Operator', 'Senior Plant Operator', 'Control Room Operator',
            'Substation Operator', 'Senior Technician', 'Technician (Electrical)',
            'Technician (Mechanical)', 'System Analyst', 'Financial Officer',
            'HR Officer', 'Planning Officer', 'Operations Officer', 'Maintenance Officer',
            'Safety Officer', 'Security Officer', 'Administrative Assistant'
          ],
          departments: [
            'GENERATION', 'TRANSMISSION', 'DISTRIBUTION', 'FINANCE & ACCOUNTS',
            'HUMAN RESOURCES', 'PLANNING & DEVELOPMENT', 'MAINTENANCE & ENGINEERING',
            'OPERATIONS & CONTROL', 'INFORMATION TECHNOLOGY', 'AUDIT & INSPECTION',
            'PROCUREMENT & LOGISTICS', 'SAFETY & ENVIRONMENT', 'LEGAL & REGULATORY',
            'CORPORATE AFFAIRS', 'TRAINING & DEVELOPMENT', 'QUALITY ASSURANCE',
            'PROJECT MANAGEMENT', 'RESEARCH & DEVELOPMENT', 'CUSTOMER SERVICES',
            'SECURITY SERVICES', 'TRANSPORT & VEHICLE', 'STORE & INVENTORY',
            'CONSTRUCTION & CIVIL', 'ELECTRICAL MAINTENANCE', 'MECHANICAL MAINTENANCE',
            'INSTRUMENTATION & CONTROL', 'COMMUNICATION & TELECOM', 'COAL HANDLING',
            'WATER TREATMENT', 'LABORATORY SERVICES', 'GENERAL ADMINISTRATION'
          ],
          powerPlants: [
            'Barapukuria Coal Power Plant (525 MW)', 'Payra Coal Power Plant (1320 MW)',
            'Rampal Coal Power Plant (1320 MW)', 'Rooppur Nuclear Power Plant (2400 MW)',
            'Matarbari Coal Power Plant (1200 MW)', 'Ashuganj Power Plant (450 MW)',
            'Ghorashal Power Plant (210 MW)', 'Siddhirganj Power Plant (150 MW)',
            'Raozan Power Plant (52.5 MW)', 'Khulna Power Plant (210 MW)',
            'Barisal Power Plant (150 MW)', 'Sylhet Power Plant (150 MW)',
            'Rangpur Power Plant (210 MW)', 'Comilla Power Plant (60 MW)',
            'Mymensingh Power Plant (210 MW)', 'Ashuganj South Power Plant (450 MW)',
            'Meghnaghat Power Plant (450 MW)', 'Haripur Power Plant (360 MW)',
            'Keraniganj Power Plant (190 MW)', 'Bhola Power Plant (225 MW)',
            'Kaptai Hydro Power Plant (230 MW)', 'Solar Power Plant (50 MW)',
            'Wind Power Plant (60 MW)', 'Ashuganj 230kV Substation',
            'Comilla 230kV Substation', 'Dhaka 230kV Substation',
            'Bogra 230kV Substation', 'Rangpur 230kV Substation',
            'Sylhet 230kV Substation', 'Barisal 230kV Substation',
            'Khulna 230kV Substation', 'Chittagong 230kV Substation',
            'Maddhapara 132kV Substation', 'Tongi 132kV Substation',
            'Siddhirganj 132kV Substation', 'Ghorashal 132kV Substation',
            'Meghnaghat 132kV Substation', 'Haripur 132kV Substation',
            'Keraniganj 132kV Substation', 'Bhola 132kV Substation'
          ]
        };
        
        setConfig(fallbackConfig);
      }
    };

    fetchConfig();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    // Validate passwords match
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      setIsLoading(false);
      return;
    }

    // Validate required fields
    if (!formData.name || !formData.email || !formData.password || !formData.role) {
      setError('Please fill in all required fields');
      setIsLoading(false);
      return;
    }

    try {
      // Register user with backend
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/auth/register`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email: formData.email,
          password: formData.password,
          name: formData.name,
          role: formData.role,
          department: formData.department || undefined,
          powerPlant: formData.powerPlant || undefined
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Registration failed');
      }

      const result = await response.json();
      
      // Auto-login after successful registration
      const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({
        email: formData.email,
        password: formData.password,
      });

      if (loginError) {
        throw new Error('Registration successful but auto-login failed. Please login manually.');
      }

      if (loginData.session?.access_token) {
        // Fetch user profile
        const profileResponse = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/auth/profile`, {
          headers: {
            'Authorization': `Bearer ${loginData.session.access_token}`,
            'Content-Type': 'application/json'
          }
        });

        if (profileResponse.ok) {
          const profileData = await profileResponse.json();
          
          onRegister({
            ...profileData.user,
            accessToken: loginData.session.access_token,
            emailVerified: false // New users need email verification
          });
        }
      }
    } catch (error: any) {
      console.error('Registration error:', error);
      setError(error.message || 'Registration failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900 py-12">
      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-30 dark:opacity-20 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 via-transparent to-green-50/50 dark:from-blue-900/20 dark:via-transparent dark:to-green-900/20"></div>
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%234f46e5' fill-opacity='0.1'%3E%3Cpath d='m36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          backgroundRepeat: 'repeat'
        }}></div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 w-full max-w-md p-6"
      >
        <Card className="p-8 backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30 shadow-2xl">
          {/* Header */}
          <div className="text-center mb-8">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="mx-auto w-16 h-16 bg-gradient-to-r from-blue-600 to-green-600 rounded-full flex items-center justify-center mb-4"
            >
              <Zap className="w-8 h-8 text-white" />
            </motion.div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              Create Account
            </h1>
            <p className="text-gray-600 dark:text-gray-300">
              Register for BPDB Portal access
            </p>
          </div>

          {/* Registration Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-600 dark:text-red-400 text-sm"
              >
                {error}
              </motion.div>
            )}

            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <Input
                  id="name"
                  name="name"
                  type="text"
                  placeholder="Enter your full name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="pl-10 backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-white/20 dark:border-gray-700/30"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email Address *</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="pl-10 backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-white/20 dark:border-gray-700/30"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">Role/Designation *</Label>
              <div className="relative">
                <UserCheck className="absolute left-3 top-3 h-5 w-5 text-gray-400 z-10" />
                <Select onValueChange={(value) => handleSelectChange('role', value)}>
                  <SelectTrigger className="pl-10 backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-white/20 dark:border-gray-700/30">
                    <SelectValue placeholder="Select your role" />
                  </SelectTrigger>
                  <SelectContent>
                    {config?.roles?.map((role: string) => (
                      <SelectItem key={role} value={role}>{role}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="department">Department</Label>
              <div className="relative">
                <Building className="absolute left-3 top-3 h-5 w-5 text-gray-400 z-10" />
                <Select onValueChange={(value) => handleSelectChange('department', value)}>
                  <SelectTrigger className="pl-10 backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-white/20 dark:border-gray-700/30">
                    <SelectValue placeholder="Select department (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    {config?.departments?.map((dept: string) => (
                      <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="powerPlant">Power Plant</Label>
              <div className="relative">
                <Factory className="absolute left-3 top-3 h-5 w-5 text-gray-400 z-10" />
                <Select onValueChange={(value) => handleSelectChange('powerPlant', value)}>
                  <SelectTrigger className="pl-10 backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-white/20 dark:border-gray-700/30">
                    <SelectValue placeholder="Select power plant (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    {config?.powerPlants?.map((plant: string) => (
                      <SelectItem key={plant} value={plant}>{plant}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password *</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Create a password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className="pl-10 pr-10 backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-white/20 dark:border-gray-700/30"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password *</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  placeholder="Confirm your password"
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  className="pl-10 pr-10 backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-white/20 dark:border-gray-700/30"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  {showConfirmPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white shadow-lg"
            >
              {isLoading ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                />
              ) : (
                'Create Account'
              )}
            </Button>
          </form>

          {/* Login Link */}
          <div className="mt-6 text-center">
            <p className="text-gray-600 dark:text-gray-300 text-sm">
              Already have an account?{' '}
              <button
                onClick={onSwitchToLogin}
                className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium"
              >
                Sign in here
              </button>
            </p>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}