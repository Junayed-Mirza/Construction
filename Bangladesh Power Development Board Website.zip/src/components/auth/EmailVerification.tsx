import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Mail, CheckCircle, AlertCircle, RefreshCw, ArrowLeft } from 'lucide-react';
import { Button } from "../ui/button";
import { Card } from "../ui/card";
import { Alert, AlertDescription } from "../ui/alert";

interface EmailVerificationProps {
  email: string;
  onVerificationComplete: () => void;
  onBack: () => void;
}

export default function EmailVerification({ email, onVerificationComplete, onBack }: EmailVerificationProps) {
  const [isResending, setIsResending] = useState(false);
  const [resendStatus, setResendStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [countdown, setCountdown] = useState(60);
  const [canResend, setCanResend] = useState(false);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setCanResend(true);
    }
  }, [countdown]);

  useEffect(() => {
    // Check for verification status periodically
    const checkInterval = setInterval(async () => {
      try {
        const { supabase } = await import('../../utils/supabase/client');
        const { data: { session } } = await supabase.auth.getSession();
        
        if (session?.user?.email_confirmed_at) {
          clearInterval(checkInterval);
          onVerificationComplete();
        }
      } catch (error) {
        console.error('Error checking verification status:', error);
      }
    }, 3000);

    return () => clearInterval(checkInterval);
  }, [onVerificationComplete]);

  const handleResendEmail = async () => {
    setIsResending(true);
    setResendStatus('idle');

    try {
      const { supabase } = await import('../../utils/supabase/client');
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: email
      });

      if (error) {
        throw error;
      }

      setResendStatus('success');
      setCountdown(60);
      setCanResend(false);
    } catch (error: any) {
      console.error('Error resending verification email:', error);
      setResendStatus('error');
    } finally {
      setIsResending(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md"
      >
        <Card className="p-8 backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 border-white/20 dark:border-gray-700/30 shadow-2xl">
          <div className="text-center mb-8">
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="w-16 h-16 bg-gradient-to-r from-blue-600 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4"
            >
              <Mail className="w-8 h-8 text-white" />
            </motion.div>
            
            <h1 className="text-2xl mb-2">Verify Your Email</h1>
            <p className="text-gray-600 dark:text-gray-400">
              We've sent a verification link to
            </p>
            <p className="text-blue-600 dark:text-blue-400 break-all mt-1">
              {email}
            </p>
          </div>

          <div className="space-y-6">
            <Alert className="border-blue-200 dark:border-blue-800 bg-blue-50/50 dark:bg-blue-900/20">
              <Mail className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              <AlertDescription className="text-blue-800 dark:text-blue-200">
                Please check your email and click the verification link to activate your account. 
                The verification process may take a few minutes.
              </AlertDescription>
            </Alert>

            {resendStatus === 'success' && (
              <Alert className="border-green-200 dark:border-green-800 bg-green-50/50 dark:bg-green-900/20">
                <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                <AlertDescription className="text-green-800 dark:text-green-200">
                  Verification email sent successfully! Please check your inbox.
                </AlertDescription>
              </Alert>
            )}

            {resendStatus === 'error' && (
              <Alert className="border-red-200 dark:border-red-800 bg-red-50/50 dark:bg-red-900/20">
                <AlertCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
                <AlertDescription className="text-red-800 dark:text-red-200">
                  Failed to resend verification email. Please try again.
                </AlertDescription>
              </Alert>
            )}

            <div className="text-center space-y-4">
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Didn't receive the email? Check your spam folder or
              </div>
              
              <Button
                variant="outline"
                onClick={handleResendEmail}
                disabled={!canResend || isResending}
                className="w-full backdrop-blur-sm bg-white/60 dark:bg-gray-800/60 border-white/30 dark:border-gray-600/30"
              >
                {isResending ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : canResend ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Resend Email
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Resend in {countdown}s
                  </>
                )}
              </Button>
            </div>

            <div className="text-center text-sm text-gray-600 dark:text-gray-400">
              <div className="mb-2">Tips:</div>
              <ul className="text-xs space-y-1 text-left max-w-sm mx-auto">
                <li>• Check your spam/junk folder</li>
                <li>• Add noreply@bpdb.gov.bd to your contacts</li>
                <li>• Verification links expire after 24 hours</li>
                <li>• Make sure your email client supports HTML emails</li>
              </ul>
            </div>

            <Button
              variant="ghost"
              onClick={onBack}
              className="w-full text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Registration
            </Button>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}