import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Login from './Login';
import Register from './Register';
import ForgotPassword from './ForgotPassword';
import ResetPassword from './ResetPassword';
import EmailVerification from './EmailVerification';
import TwoFactorAuth from './TwoFactorAuth';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  department: string;
  powerPlant?: string;
  level: number;
  permissions: string[];
  accessToken: string;
  twoFactorEnabled?: boolean;
  twoFactorVerified?: boolean;
  emailVerified?: boolean;
  phone?: string;
}

export type AuthView = 
  | 'login' 
  | 'register' 
  | 'forgot-password' 
  | 'reset-password' 
  | 'email-verification' 
  | 'two-factor-email' 
  | 'two-factor-sms';

interface AuthRouterProps {
  initialView?: AuthView;
  onAuthenticated: (user: User) => void;
  onBack: () => void;
}

export default function AuthRouter({ initialView = 'login', onAuthenticated, onBack }: AuthRouterProps) {
  const [currentView, setCurrentView] = useState<AuthView>(initialView);
  const [pendingUser, setPendingUser] = useState<User | null>(null);
  const [verificationEmail, setVerificationEmail] = useState<string>('');

  const handleLoginSuccess = (user: User) => {
    // Check if user needs email verification
    if (!user.emailVerified) {
      setPendingUser(user);
      setVerificationEmail(user.email);
      setCurrentView('email-verification');
      return;
    }

    // Check if user has 2FA enabled but not verified in this session
    if (user.twoFactorEnabled && !user.twoFactorVerified) {
      setPendingUser(user);
      // Default to email 2FA, could be enhanced to let user choose
      setCurrentView('two-factor-email');
      return;
    }

    // User is fully authenticated
    onAuthenticated(user);
  };

  const handleRegistrationSuccess = (user: User) => {
    // New users always need email verification
    setPendingUser(user);
    setVerificationEmail(user.email);
    setCurrentView('email-verification');
  };

  const handleEmailVerificationComplete = () => {
    if (pendingUser) {
      const updatedUser = { ...pendingUser, emailVerified: true };
      
      // Check if 2FA is required after email verification
      if (updatedUser.twoFactorEnabled && !updatedUser.twoFactorVerified) {
        setPendingUser(updatedUser);
        setCurrentView('two-factor-email');
        return;
      }

      // User is fully authenticated
      onAuthenticated(updatedUser);
    }
  };

  const handle2FASuccess = (user: User) => {
    onAuthenticated(user);
  };

  const handlePasswordResetSuccess = () => {
    setCurrentView('login');
  };

  const handleBackToAuth = () => {
    setPendingUser(null);
    setVerificationEmail('');
    setCurrentView('login');
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'login':
        return (
          <Login
            onLogin={handleLoginSuccess}
            onSwitchToRegister={() => setCurrentView('register')}
            onSwitchToForgotPassword={() => setCurrentView('forgot-password')}
            onBack={onBack}
          />
        );

      case 'register':
        return (
          <Register
            onRegister={handleRegistrationSuccess}
            onSwitchToLogin={() => setCurrentView('login')}
            onBack={onBack}
          />
        );

      case 'forgot-password':
        return (
          <ForgotPassword
            onBack={() => setCurrentView('login')}
          />
        );

      case 'reset-password':
        return (
          <ResetPassword
            onSuccess={handlePasswordResetSuccess}
            onError={(error) => {
              console.error('Reset password error:', error);
              setCurrentView('login');
            }}
          />
        );

      case 'email-verification':
        return (
          <EmailVerification
            email={verificationEmail}
            onVerificationComplete={handleEmailVerificationComplete}
            onBack={handleBackToAuth}
          />
        );

      case 'two-factor-email':
        return pendingUser ? (
          <TwoFactorAuth
            user={pendingUser}
            method="email"
            onSuccess={handle2FASuccess}
            onBack={handleBackToAuth}
          />
        ) : null;

      case 'two-factor-sms':
        return pendingUser ? (
          <TwoFactorAuth
            user={pendingUser}
            method="sms"
            onSuccess={handle2FASuccess}
            onBack={handleBackToAuth}
          />
        ) : null;

      default:
        return null;
    }
  };

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={currentView}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ duration: 0.3 }}
      >
        {renderCurrentView()}
      </motion.div>
    </AnimatePresence>
  );
}