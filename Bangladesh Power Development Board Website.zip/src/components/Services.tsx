import React from 'react';
import { motion } from 'motion/react';
import { 
  Zap, Home, Building2, Factory, Shield, Wrench, 
  Phone, CreditCard, FileText, Users, TrendingUp, 
  Lightbulb, Settings, MapPin, Clock, ArrowRight 
} from 'lucide-react';
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

interface ServicesProps {
  expanded?: boolean;
}

export default function Services({ expanded = false }: ServicesProps) {
  const glassStyle = {
    background: 'rgba(255, 255, 255, 0.1)',
    backdropFilter: 'blur(20px)',
    border: '1px solid rgba(255, 255, 255, 0.2)',
  };

  const services = [
    {
      icon: Home,
      title: 'Residential Services',
      description: 'Reliable electricity supply for homes across Bangladesh',
      features: ['24/7 Power Supply', 'Online Bill Payment', 'Load Management', 'Emergency Support'],
      color: 'from-blue-500 to-cyan-500',
      category: 'Consumer'
    },
    {
      icon: Building2,
      title: 'Commercial Services',
      description: 'Tailored power solutions for businesses and offices',
      features: ['High Capacity Supply', 'Dedicated Support', 'Flexible Tariffs', 'Energy Audits'],
      color: 'from-green-500 to-emerald-500',
      category: 'Business'
    },
    {
      icon: Factory,
      title: 'Industrial Services',
      description: 'Heavy-duty power supply for manufacturing and industries',
      features: ['Uninterrupted Supply', 'Custom Solutions', 'Power Quality', 'Technical Support'],
      color: 'from-purple-500 to-pink-500',
      category: 'Industrial'
    },
    {
      icon: Shield,
      title: 'Grid Security',
      description: 'Advanced security and monitoring systems',
      features: ['Real-time Monitoring', 'Cyber Security', 'Equipment Protection', 'Backup Systems'],
      color: 'from-red-500 to-orange-500',
      category: 'Infrastructure'
    },
    {
      icon: Wrench,
      title: 'Maintenance Services',
      description: 'Comprehensive maintenance and repair services',
      features: ['Preventive Maintenance', 'Emergency Repairs', 'Equipment Upgrades', 'Technical Training'],
      color: 'from-yellow-500 to-amber-500',
      category: 'Support'
    },
    {
      icon: TrendingUp,
      title: 'Energy Analytics',
      description: 'Data-driven insights for energy optimization',
      features: ['Usage Analytics', 'Cost Optimization', 'Efficiency Reports', 'Predictive Analysis'],
      color: 'from-indigo-500 to-blue-500',
      category: 'Technology'
    }
  ];

  const customerServices = [
    {
      icon: CreditCard,
      title: 'Bill Payment',
      description: 'Multiple payment options for your convenience',
      link: 'Pay Now'
    },
    {
      icon: Phone,
      title: 'Customer Support',
      description: '24/7 helpline for all your queries',
      link: 'Call Now'
    },
    {
      icon: FileText,
      title: 'New Connection',
      description: 'Apply for new electricity connection online',
      link: 'Apply'
    },
    {
      icon: Users,
      title: 'Load Management',
      description: 'Manage your power load efficiently',
      link: 'Manage'
    }
  ];

  return (
    <section className={`${expanded ? 'pt-32' : 'py-16'} lg:py-24 px-4 lg:px-8`}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Badge className="mb-4 bg-green-500/20 text-green-600 dark:text-green-400 border border-green-500/30">
            Our Services
          </Badge>
          <h2 className="text-3xl lg:text-5xl font-bold mb-4">
            Comprehensive
            <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent"> Power Solutions</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            From residential to industrial, we provide reliable and efficient power services tailored to your needs
          </p>
        </motion.div>

        {/* Main Services Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16"
        >
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ 
                delay: index * 0.1, 
                duration: 0.6,
                type: "spring",
                stiffness: 100
              }}
              whileHover={{ 
                scale: 1.05, 
                rotateY: 5,
                transition: { duration: 0.3 }
              }}
              className="group"
            >
              <Card 
                className="p-6 h-full border-0 shadow-xl relative overflow-hidden cursor-pointer"
                style={glassStyle}
              >
                {/* Animated Background */}
                <motion.div
                  className={`absolute inset-0 bg-gradient-to-br ${service.color} opacity-10 group-hover:opacity-20 transition-opacity duration-300`}
                  animate={{
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    delay: index * 0.5,
                  }}
                />
                
                {/* Category Badge */}
                <Badge 
                  variant="outline" 
                  className="absolute top-4 right-4 bg-white/20 border-white/30 text-xs"
                >
                  {service.category}
                </Badge>
                
                {/* Icon */}
                <motion.div
                  className={`inline-flex p-4 rounded-xl bg-gradient-to-br ${service.color} text-white mb-6 shadow-lg relative z-10`}
                  animate={{
                    rotate: [0, 5, -5, 0],
                  }}
                  transition={{
                    duration: 6,
                    repeat: Infinity,
                    delay: index * 0.3,
                  }}
                >
                  <service.icon className="w-8 h-8" />
                </motion.div>
                
                {/* Content */}
                <div className="relative z-10">
                  <h3 className="text-xl font-bold mb-3 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-blue-600 group-hover:to-green-600 group-hover:bg-clip-text transition-all duration-300">
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    {service.description}
                  </p>
                  
                  {/* Features */}
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, featureIndex) => (
                      <motion.li
                        key={feature}
                        initial={{ opacity: 0, x: -10 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ delay: (index * 0.1) + (featureIndex * 0.05) }}
                        className="flex items-center text-sm text-muted-foreground"
                      >
                        <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${service.color} mr-3`} />
                        {feature}
                      </motion.li>
                    ))}
                  </ul>
                  
                  {/* CTA Button */}
                  <Button
                    variant="outline"
                    className="w-full group-hover:bg-white/20 transition-all duration-300 rounded-xl"
                  >
                    Learn More
                    <motion.div
                      animate={{ x: [0, 5, 0] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    >
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </motion.div>
                  </Button>
                </div>
                
                {/* Hover Border Effect */}
                <motion.div
                  className="absolute inset-0 border-2 border-transparent group-hover:border-white/30 rounded-xl transition-all duration-300"
                  initial={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                />
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Customer Services Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mb-16"
        >
          <div className="text-center mb-8">
            <h3 className="text-2xl lg:text-3xl font-bold mb-4">
              Quick Customer Services
            </h3>
            <p className="text-muted-foreground">
              Access essential services with just a few clicks
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {customerServices.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="group"
              >
                <Card 
                  className="p-6 text-center border-0 shadow-lg cursor-pointer"
                  style={glassStyle}
                >
                  <motion.div
                    className="inline-flex p-3 rounded-xl bg-gradient-to-br from-blue-500 to-green-500 text-white mb-4"
                    whileHover={{ rotate: 10 }}
                    transition={{ duration: 0.3 }}
                  >
                    <service.icon className="w-6 h-6" />
                  </motion.div>
                  <h4 className="font-bold mb-2">{service.title}</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    {service.description}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full group-hover:bg-blue-500 group-hover:text-white transition-all duration-300"
                  >
                    {service.link}
                  </Button>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* 24/7 Support Banner */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="relative overflow-hidden rounded-2xl"
        >
          <Card 
            className="p-8 lg:p-12 border-0 shadow-2xl text-center relative"
            style={glassStyle}
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-green-500/20"
              animate={{
                backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
              }}
            />
            
            <div className="relative z-10">
              <motion.div
                animate={{
                  scale: [1, 1.1, 1],
                  rotate: [0, 5, -5, 0],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                }}
                className="inline-flex p-4 rounded-full bg-gradient-to-br from-blue-500 to-green-500 text-white mb-6"
              >
                <Clock className="w-8 h-8" />
              </motion.div>
              
              <h3 className="text-2xl lg:text-3xl font-bold mb-4">
                24/7 Customer Support
              </h3>
              <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">
                Our dedicated support team is always ready to assist you with any power-related issues or queries
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white shadow-lg hover:shadow-xl rounded-xl px-8"
                >
                  <Phone className="mr-2 w-5 h-5" />
                  Call 16123
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="rounded-xl px-8"
                  style={glassStyle}
                >
                  <FileText className="mr-2 w-5 h-5" />
                  Submit Ticket
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}