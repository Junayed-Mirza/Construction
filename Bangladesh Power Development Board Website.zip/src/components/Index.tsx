import React from 'react';
import { motion } from 'motion/react';
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Zap, Users, BarChart3, Shield, Award, Globe, TrendingUp, Building, Power, Wrench, FileText, Calendar, Target } from 'lucide-react';

interface IndexProps {
  setActiveSection: (section: string) => void;
  onLoginClick: () => void;
}

export default function Index({ setActiveSection, onLoginClick }: IndexProps) {
  const features = [
    {
      icon: Building,
      title: "Project Management",
      description: "Comprehensive construction project oversight and management",
      color: "from-blue-500 to-blue-600"
    },
    {
      icon: Wrench,
      title: "Equipment Management", 
      description: "Track and maintain all construction equipment and machinery",
      color: "from-green-500 to-green-600"
    },
    {
      icon: FileText,
      title: "Document Management",
      description: "Centralized document storage and version control",
      color: "from-purple-500 to-purple-600"
    },
    {
      icon: Users,
      title: "Contractor Management",
      description: "Manage contractors, vendors and workforce efficiently",
      color: "from-orange-500 to-orange-600"
    },
    {
      icon: BarChart3,
      title: "Financial Management",
      description: "Budget tracking, cost analysis and financial reporting",
      color: "from-red-500 to-red-600"
    },
    {
      icon: Shield,
      title: "Quality & Safety",
      description: "Ensure safety standards and quality control measures",
      color: "from-teal-500 to-teal-600"
    },
    {
      icon: Calendar,
      title: "Maintenance Scheduling",
      description: "Preventive maintenance and equipment scheduling",
      color: "from-indigo-500 to-indigo-600"
    },
    {
      icon: Target,
      title: "Reporting & Analytics",
      description: "Real-time insights and comprehensive reporting",
      color: "from-pink-500 to-pink-600"
    }
  ];

  const stats = [
    { label: "Active Projects", value: "156", icon: Building },
    { label: "Total Capacity", value: "24,500 MW", icon: Zap },
    { label: "Registered Users", value: "2,847", icon: Users },
    { label: "Equipment Units", value: "8,392", icon: Wrench }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="mb-8"
            >
              <Badge variant="secondary" className="mb-4 px-4 py-2 text-sm backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 border border-white/20 dark:border-gray-700/30">
                <Zap className="w-4 h-4 mr-2" />
                BPDB Construction Management System
              </Badge>
              
              <h1 className="text-4xl md:text-6xl lg:text-7xl mb-6 bg-gradient-to-r from-blue-600 via-green-600 to-blue-800 dark:from-blue-400 dark:via-green-400 dark:to-blue-600 bg-clip-text text-transparent">
                Power Bangladesh's Future
              </h1>
              
              <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-8 leading-relaxed">
                Comprehensive construction management platform for Bangladesh Power Development Board. 
                Streamline projects, manage resources, and build the energy infrastructure of tomorrow.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="flex flex-col sm:flex-row gap-4 justify-center mb-12"
            >
              <Button 
                size="lg" 
                onClick={onLoginClick}
                className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white px-8 py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 backdrop-blur-sm"
              >
                <Power className="w-5 h-5 mr-2" />
                Access Portal
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => setActiveSection('about')}
                className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 border-white/20 dark:border-gray-700/30 px-8 py-3 rounded-xl hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300"
              >
                Learn More
              </Button>
            </motion.div>

            {/* Quick Stats */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto"
            >
              {stats.map((stat, index) => (
                <Card key={stat.label} className="p-4 backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 border-white/20 dark:border-gray-700/30">
                  <div className="flex items-center justify-center mb-2">
                    <stat.icon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div className="text-2xl mb-1">{stat.value}</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">{stat.label}</div>
                </Card>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl mb-4">
              Comprehensive Management Platform
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Nine integrated modules to manage every aspect of power infrastructure construction projects
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
              >
                <Card className="p-6 h-full backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 border-white/20 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300 group cursor-pointer">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-lg mb-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors duration-300">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
                    {feature.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Card className="p-12 backdrop-blur-sm bg-gradient-to-br from-blue-50/80 to-green-50/80 dark:from-blue-900/40 dark:to-green-900/40 border-white/20 dark:border-gray-700/30">
              <div className="flex items-center justify-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-green-600 rounded-full flex items-center justify-center">
                  <Zap className="w-8 h-8 text-white" />
                </div>
              </div>
              
              <h2 className="text-3xl md:text-4xl mb-4">
                Ready to Get Started?
              </h2>
              
              <p className="text-lg text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
                Join thousands of professionals using BPDB's construction management platform to deliver 
                world-class power infrastructure projects.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  onClick={onLoginClick}
                  className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white px-8 py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  <Power className="w-5 h-5 mr-2" />
                  Access Your Dashboard
                </Button>
                
                <Button 
                  variant="outline" 
                  size="lg"
                  onClick={() => setActiveSection('contact')}
                  className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 border-white/20 dark:border-gray-700/30 px-8 py-3 rounded-xl hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300"
                >
                  Contact Support
                </Button>
              </div>
            </Card>
          </motion.div>
        </div>
      </section>
    </div>
  );
}