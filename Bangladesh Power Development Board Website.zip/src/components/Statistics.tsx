import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { Activity, Zap, TrendingUp, MapPin, Calendar, Clock } from 'lucide-react';
import { Card } from "./ui/card";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

export default function Statistics() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [powerDemand, setPowerDemand] = useState(8500);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
      // Simulate real-time power demand fluctuation
      setPowerDemand(prev => {
        const variance = Math.random() * 1000 - 500;
        return Math.max(7000, Math.min(12000, prev + variance));
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const glassStyle = {
    background: 'rgba(255, 255, 255, 0.1)',
    backdropFilter: 'blur(20px)',
    border: '1px solid rgba(255, 255, 255, 0.2)',
  };

  // Sample data for charts
  const powerGenerationData = [
    { month: 'Jan', gas: 4000, coal: 2000, hydro: 1000, solar: 500, wind: 300 },
    { month: 'Feb', gas: 4200, coal: 2100, hydro: 1100, solar: 600, wind: 350 },
    { month: 'Mar', gas: 4500, coal: 2200, hydro: 1200, solar: 700, wind: 400 },
    { month: 'Apr', gas: 4800, coal: 2300, hydro: 1300, solar: 800, wind: 450 },
    { month: 'May', gas: 5000, coal: 2400, hydro: 1400, solar: 900, wind: 500 },
    { month: 'Jun', gas: 5200, coal: 2500, hydro: 1500, solar: 1000, wind: 550 },
    { month: 'Jul', gas: 5400, coal: 2600, hydro: 1600, solar: 1100, wind: 600 },
    { month: 'Aug', gas: 5300, coal: 2550, hydro: 1550, solar: 1050, wind: 580 },
    { month: 'Sep', gas: 5100, coal: 2450, hydro: 1450, solar: 950, wind: 520 },
    { month: 'Oct', gas: 4900, coal: 2350, hydro: 1350, solar: 850, wind: 480 },
    { month: 'Nov', gas: 4600, coal: 2200, hydro: 1200, solar: 700, wind: 420 },
    { month: 'Dec', gas: 4300, coal: 2100, hydro: 1100, solar: 600, wind: 380 }
  ];

  const demandSupplyData = [
    { time: '00:00', demand: 6500, supply: 7000 },
    { time: '04:00', demand: 5800, supply: 6200 },
    { time: '08:00', demand: 8200, supply: 8500 },
    { time: '12:00', demand: 9500, supply: 9800 },
    { time: '16:00', demand: 10200, supply: 10500 },
    { time: '20:00', demand: 11000, supply: 11300 },
  ];

  const fuelMixData = [
    { name: 'Natural Gas', value: 58, color: '#3b82f6' },
    { name: 'Coal', value: 25, color: '#374151' },
    { name: 'Hydro', value: 8, color: '#06b6d4' },
    { name: 'Solar', value: 6, color: '#fbbf24' },
    { name: 'Wind', value: 3, color: '#10b981' },
  ];

  const regionalData = [
    { region: 'Dhaka', capacity: 3200, demand: 2800, efficiency: 87 },
    { region: 'Chittagong', capacity: 2100, demand: 1900, efficiency: 90 },
    { region: 'Sylhet', capacity: 1200, demand: 1000, efficiency: 83 },
    { region: 'Rajshahi', capacity: 1800, demand: 1600, efficiency: 89 },
    { region: 'Khulna', capacity: 1500, demand: 1300, efficiency: 87 },
    { region: 'Barisal', capacity: 900, demand: 800, efficiency: 89 },
  ];

  return (
    <section className="py-16 lg:py-24 px-4 lg:px-8 bg-gradient-to-b from-transparent to-blue-50/30 dark:to-blue-900/30">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Badge className="mb-4 bg-blue-500/20 text-blue-600 dark:text-blue-400 border border-blue-500/30">
            Real-Time Data
          </Badge>
          <h2 className="text-3xl lg:text-5xl font-bold mb-4">
            Power Generation
            <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent"> Statistics</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Monitor Bangladesh's power generation, distribution, and consumption in real-time
          </p>
        </motion.div>

        {/* Live Status Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12"
        >
          {/* Current Demand */}
          <Card className="p-6 border-0 shadow-xl relative overflow-hidden" style={glassStyle}>
            <motion.div
              className="absolute inset-0 bg-gradient-to-br from-red-500/10 to-orange-500/10"
              animate={{ opacity: [0.1, 0.2, 0.1] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-4">
                <Activity className="w-8 h-8 text-red-500" />
                <motion.div
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 1, repeat: Infinity }}
                >
                  <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                </motion.div>
              </div>
              <h3 className="text-2xl font-bold mb-2">{powerDemand.toLocaleString()} MW</h3>
              <p className="text-muted-foreground">Current Demand</p>
              <div className="mt-4">
                <Progress value={(powerDemand / 12000) * 100} className="h-2" />
                <p className="text-xs text-muted-foreground mt-1">Peak Capacity: 12,000 MW</p>
              </div>
            </div>
          </Card>

          {/* Generation Status */}
          <Card className="p-6 border-0 shadow-xl relative overflow-hidden" style={glassStyle}>
            <motion.div
              className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-blue-500/10"
              animate={{ opacity: [0.1, 0.2, 0.1] }}
              transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
            />
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-4">
                <Zap className="w-8 h-8 text-green-500" />
                <Badge variant="outline" className="bg-green-500/20 text-green-600 border-green-500/30">
                  Active
                </Badge>
              </div>
              <h3 className="text-2xl font-bold mb-2">11,250 MW</h3>
              <p className="text-muted-foreground">Total Generation</p>
              <div className="mt-4">
                <Progress value={94} className="h-2" />
                <p className="text-xs text-muted-foreground mt-1">Efficiency: 94%</p>
              </div>
            </div>
          </Card>

          {/* System Status */}
          <Card className="p-6 border-0 shadow-xl relative overflow-hidden" style={glassStyle}>
            <motion.div
              className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10"
              animate={{ opacity: [0.1, 0.2, 0.1] }}
              transition={{ duration: 2, repeat: Infinity, delay: 1 }}
            />
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-4">
                <Clock className="w-8 h-8 text-blue-500" />
                <Badge variant="outline" className="bg-blue-500/20 text-blue-600 border-blue-500/30">
                  {currentTime.toLocaleTimeString()}
                </Badge>
              </div>
              <h3 className="text-2xl font-bold mb-2">99.2%</h3>
              <p className="text-muted-foreground">Grid Stability</p>
              <div className="mt-4">
                <Progress value={99.2} className="h-2" />
                <p className="text-xs text-muted-foreground mt-1">Last updated: {currentTime.toLocaleTimeString()}</p>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Charts Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <Tabs defaultValue="generation" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-white/10 dark:bg-white/5 backdrop-blur-md">
              <TabsTrigger value="generation">Generation</TabsTrigger>
              <TabsTrigger value="demand">Demand/Supply</TabsTrigger>
              <TabsTrigger value="fuel">Fuel Mix</TabsTrigger>
              <TabsTrigger value="regional">Regional</TabsTrigger>
            </TabsList>

            <TabsContent value="generation">
              <Card className="p-6 border-0 shadow-xl" style={glassStyle}>
                <h3 className="text-xl font-bold mb-6">Monthly Power Generation by Source</h3>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={powerGenerationData}>
                      <defs>
                        <linearGradient id="gasGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.1}/>
                        </linearGradient>
                        <linearGradient id="coalGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#374151" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#374151" stopOpacity={0.1}/>
                        </linearGradient>
                        <linearGradient id="hydroGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.1}/>
                        </linearGradient>
                        <linearGradient id="solarGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#fbbf24" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#fbbf24" stopOpacity={0.1}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                      <XAxis dataKey="month" stroke="rgba(255,255,255,0.6)" />
                      <YAxis stroke="rgba(255,255,255,0.6)" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'rgba(255,255,255,0.1)', 
                          backdropFilter: 'blur(20px)',
                          border: '1px solid rgba(255,255,255,0.2)',
                          borderRadius: '12px'
                        }} 
                      />
                      <Area type="monotone" dataKey="gas" stackId="1" stroke="#3b82f6" fill="url(#gasGradient)" />
                      <Area type="monotone" dataKey="coal" stackId="1" stroke="#374151" fill="url(#coalGradient)" />
                      <Area type="monotone" dataKey="hydro" stackId="1" stroke="#06b6d4" fill="url(#hydroGradient)" />
                      <Area type="monotone" dataKey="solar" stackId="1" stroke="#fbbf24" fill="url(#solarGradient)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="demand">
              <Card className="p-6 border-0 shadow-xl" style={glassStyle}>
                <h3 className="text-xl font-bold mb-6">Daily Demand vs Supply</h3>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={demandSupplyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                      <XAxis dataKey="time" stroke="rgba(255,255,255,0.6)" />
                      <YAxis stroke="rgba(255,255,255,0.6)" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'rgba(255,255,255,0.1)', 
                          backdropFilter: 'blur(20px)',
                          border: '1px solid rgba(255,255,255,0.2)',
                          borderRadius: '12px'
                        }} 
                      />
                      <Line type="monotone" dataKey="demand" stroke="#ef4444" strokeWidth={3} strokeDasharray="5 5" />
                      <Line type="monotone" dataKey="supply" stroke="#10b981" strokeWidth={3} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="fuel">
              <Card className="p-6 border-0 shadow-xl" style={glassStyle}>
                <h3 className="text-xl font-bold mb-6">Energy Source Distribution</h3>
                <div className="flex flex-col lg:flex-row items-center gap-8">
                  <div className="h-80 w-full lg:w-1/2">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={fuelMixData}
                          cx="50%"
                          cy="50%"
                          outerRadius={120}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                          {fuelMixData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="space-y-4 w-full lg:w-1/2">
                    {fuelMixData.map((fuel, index) => (
                      <motion.div
                        key={fuel.name}
                        initial={{ opacity: 0, x: 20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-center justify-between p-3 rounded-lg bg-white/5"
                      >
                        <div className="flex items-center space-x-3">
                          <div 
                            className="w-4 h-4 rounded-full" 
                            style={{ backgroundColor: fuel.color }}
                          />
                          <span>{fuel.name}</span>
                        </div>
                        <span className="font-bold">{fuel.value}%</span>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="regional">
              <Card className="p-6 border-0 shadow-xl" style={glassStyle}>
                <h3 className="text-xl font-bold mb-6">Regional Power Distribution</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {regionalData.map((region, index) => (
                    <motion.div
                      key={region.region}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="p-4 rounded-lg bg-white/5 border border-white/10"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-bold">{region.region}</h4>
                        <MapPin className="w-4 h-4 text-blue-500" />
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Capacity:</span>
                          <span className="font-medium">{region.capacity} MW</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Demand:</span>
                          <span className="font-medium">{region.demand} MW</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Efficiency:</span>
                          <span className="font-medium text-green-500">{region.efficiency}%</span>
                        </div>
                        <Progress value={(region.demand / region.capacity) * 100} className="h-2 mt-3" />
                      </div>
                    </motion.div>
                  ))}
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </section>
  );
}