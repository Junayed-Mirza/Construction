import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Zap } from 'lucide-react';
import { Button } from "./components/ui/button";
import Header from "./components/Header";
import Index from "./components/Index";
import About from "./components/About";
import Services from "./components/Services";
import Statistics from "./components/Statistics";
import Projects from "./components/Projects";
import News from "./components/News";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

// Authentication Components
import AuthRouter, { AuthView } from "./components/auth/AuthRouter";
import MainDashboard from "./components/dashboards/MainDashboard";

// Test Components
import RegistrationTest from "./components/test/RegistrationTest";

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  department: string;
  powerPlant?: string;
  level: number;
  permissions: string[];
  accessToken: string;
}

export default function App() {
  const [isDark, setIsDark] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authView, setAuthView] = useState<AuthView>('login');
  const [showAuthForms, setShowAuthForms] = useState(false);
  const [showTestMode, setShowTestMode] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  // Check for existing session on app load
  useEffect(() => {
    checkExistingSession();
    
    // Set up auth state listener
    const setupAuthListener = async () => {
      const { supabase } = await import('./utils/supabase/client');
      
      const { data: { subscription } } = supabase.auth.onAuthStateChange(
        async (event, session) => {
          if (event === 'SIGNED_OUT' || !session) {
            setCurrentUser(null);
            setIsAuthenticated(false);
            setIsLoading(false);
          } else if (event === 'SIGNED_IN' && session) {
            // Only fetch profile if we don't already have a user
            if (!currentUser) {
              try {
                const { projectId } = await import('./utils/supabase/info');
                const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/auth/profile`, {
                  headers: {
                    'Authorization': `Bearer ${session.access_token}`,
                    'Content-Type': 'application/json'
                  }
                });

                if (response.ok) {
                  const profileData = await response.json();
                  setCurrentUser({
                    ...profileData.user,
                    accessToken: session.access_token
                  });
                  setIsAuthenticated(true);
                }
              } catch (error) {
                console.error('Profile fetch failed:', error);
              } finally {
                setIsLoading(false);
              }
            }
          }
        }
      );

      return () => subscription.unsubscribe();
    };

    setupAuthListener();
  }, []);

  const checkExistingSession = async () => {
    try {
      const { supabase } = await import('./utils/supabase/client');
      const { projectId } = await import('./utils/supabase/info');

      const { data: { session }, error } = await supabase.auth.getSession();
      
      if (session?.access_token) {
        // Fetch user profile
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e/auth/profile`, {
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json'
          }
        });

        if (response.ok) {
          const profileData = await response.json();
          setCurrentUser({
            ...profileData.user,
            accessToken: session.access_token
          });
          setIsAuthenticated(true);
        }
      }
    } catch (error) {
      console.error('Session check failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setIsAuthenticated(true);
    setIsLoading(false);
  };

  const handleLogout = async () => {
    try {
      const { supabase } = await import('./utils/supabase/client');
      await supabase.auth.signOut();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setCurrentUser(null);
      setIsAuthenticated(false);
    }
  };

  const toggleTheme = () => {
    setIsDark(!isDark);
  };

  // Show loading state while checking session
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-green-600 rounded-full flex items-center justify-center">
            <Zap className="w-8 h-8 text-white animate-pulse" />
          </div>
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full"
          />
          <p className="text-gray-600 dark:text-gray-400">Loading BPDB Portal...</p>
        </div>
      </div>
    );
  }

  // If user is authenticated, show the dashboard
  if (isAuthenticated && currentUser) {
    return (
      <MainDashboard 
        user={currentUser} 
        onLogout={handleLogout}
        isDark={isDark}
        toggleTheme={toggleTheme}
      />
    );
  }

  // Show test mode if requested
  if (showTestMode) {
    return <RegistrationTest onBack={() => setShowTestMode(false)} />;
  }

  // Show authentication forms only if explicitly requested
  if (showAuthForms && !isAuthenticated) {
    return (
      <AuthRouter
        initialView={authView}
        onAuthenticated={handleLogin}
        onBack={() => setShowAuthForms(false)}
      />
    );
  }

  // Default public website view
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-blue-900 dark:to-green-900 transition-all duration-1000">
      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-30 dark:opacity-20 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 via-transparent to-green-50/50 dark:from-blue-900/20 dark:via-transparent dark:to-green-900/20"></div>
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%234f46e5' fill-opacity='0.1'%3E%3Cpath d='m36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          backgroundRepeat: 'repeat'
        }}></div>
      </div>

      <div className="relative z-10">
        <Header 
          isDark={isDark} 
          toggleTheme={toggleTheme} 
          activeSection={activeSection}
          setActiveSection={setActiveSection}
          showLoginButton={true}
          onLoginClick={() => setShowAuthForms(true)}
        />
        
        {/* Test Mode Button - Hidden in production */}
        <div className="fixed bottom-4 right-4 z-50">
          <Button
            onClick={() => setShowTestMode(true)}
            variant="outline"
            size="sm"
            className="backdrop-blur-sm bg-white/80 dark:bg-gray-900/80 border-white/20 dark:border-gray-700/30 text-xs"
          >
            Test Registration
          </Button>
        </div>
        
        <main>
          <AnimatePresence mode="wait">
            {activeSection === 'home' && (
              <motion.div
                key="home"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
              >
                <Index 
                  setActiveSection={setActiveSection} 
                  onLoginClick={() => setShowAuthForms(true)}
                />
                <Statistics />
                <Services />
                <Projects />
              </motion.div>
            )}
            
            {activeSection === 'about' && (
              <motion.div
                key="about"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
              >
                <About />
              </motion.div>
            )}
            
            {activeSection === 'services' && (
              <motion.div
                key="services"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
              >
                <Services expanded={true} />
              </motion.div>
            )}
            
            {activeSection === 'projects' && (
              <motion.div
                key="projects"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
              >
                <Projects expanded={true} />
              </motion.div>
            )}
            
            {activeSection === 'news' && (
              <motion.div
                key="news"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
              >
                <News />
              </motion.div>
            )}
            
            {activeSection === 'contact' && (
              <motion.div
                key="contact"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
              >
                <Contact />
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        <Footer setActiveSection={setActiveSection} />
      </div>
    </div>
  );
}