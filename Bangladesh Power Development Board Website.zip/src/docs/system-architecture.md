# BPDB Portal System Architecture

## Overview
The Bangladesh Power Development Board (BPDB) Portal is a comprehensive web application built using modern web technologies with a focus on glassmorphism design and role-based access control.

## Technology Stack

### Frontend
- **React 18** - Modern UI library with hooks and functional components
- **TypeScript** - Type-safe JavaScript development
- **Tailwind CSS v4** - Utility-first CSS framework with custom design system
- **Motion/React** - Animation library for smooth transitions and interactions
- **Shadcn/ui** - Pre-built accessible components
- **Lucide React** - Icon library
- **Recharts** - Chart and data visualization library

### Backend
- **Supabase** - Backend-as-a-Service platform
- **PostgreSQL** - Database (managed by Supabase)
- **Supabase Auth** - Authentication and user management
- **Supabase Edge Functions** - Serverless backend functions
- **Hono** - Lightweight web framework for Edge Functions
- **Key-Value Store** - Custom data storage solution

### Infrastructure
- **Supabase Cloud** - Hosted backend infrastructure
- **Edge Functions** - Serverless compute at the edge
- **Real-time Database** - PostgreSQL with real-time subscriptions
- **Object Storage** - File and media storage (when needed)

## System Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   React Client  │    │  Supabase Edge   │    │   PostgreSQL    │
│   (Frontend)    │────│    Functions     │────│   Database      │
│                 │    │   (Backend)      │    │                 │
└─────────────────┘    └──────────────────┘    └─────────────────┘
        │                        │                        │
        │                        │                        │
        ▼                        ▼                        ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Supabase      │    │   Hono Web       │    │   Key-Value     │
│   Auth          │    │   Server         │    │   Store         │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

## Features

### Authentication System
- **User Registration** with role-based signup
- **Email/Password Login** with session management
- **Password Reset** via email
- **Role-based Authorization** with hierarchical permissions
- **Session Management** with automatic token refresh

### User Roles & Permissions
- **10-Level Hierarchy** from operators to executives
- **Department-based Access Control**
- **Power Plant Specific Permissions**
- **Dynamic Permission System**

### Dashboard System
- **Executive Dashboard** - System-wide overview and management
- **Department Dashboard** - Department-specific metrics and controls
- **Power Plant Dashboard** - Plant-specific operational data
- **User Dashboard** - Personal tasks and assigned responsibilities

### Data Management
- **Real-time Power Generation Data**
- **Maintenance Scheduling**
- **User Management**
- **Performance Metrics**
- **Financial Reporting**

## Database Schema

### User Management
```typescript
interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  department: string;
  powerPlant?: string;
  level: number;
  permissions: string[];
  isActive: boolean;
  createdAt: string;
}
```

### Power Generation Data
```typescript
interface GenerationData {
  totalGeneration: number;
  currentLoad: number;
  peakLoad: number;
  powerPlants: PowerPlant[];
  lastUpdated: string;
}

interface PowerPlant {
  name: string;
  capacity: number;
  current: number;
  efficiency: number;
  status: 'online' | 'maintenance' | 'offline';
}
```

## API Endpoints

### Authentication
- `POST /auth/register` - User registration
- `POST /auth/forgot-password` - Password reset request
- `POST /auth/reset-password` - Password reset confirmation
- `GET /auth/profile` - Get user profile

### Data Management
- `GET /dashboard/overview` - Dashboard data based on user role
- `GET /data/generation` - Power generation data
- `GET /data/department/:dept` - Department-specific data
- `GET /data/powerplant/:plant` - Power plant specific data

### Configuration
- `GET /config` - System configuration (roles, departments, plants)

## Security Features

### Authentication Security
- **Secure Password Hashing** via Supabase Auth
- **JWT Token Authentication** with automatic refresh
- **Email Verification** for new accounts
- **Password Reset** with secure tokens
- **Session Management** with automatic expiration

### Authorization Security
- **Role-based Access Control (RBAC)**
- **Hierarchical Permissions** based on user level
- **Resource-level Authorization** for departments and plants
- **API Endpoint Protection** with token validation

### Data Security
- **Encrypted Database** connections
- **Environment Variable** protection for secrets
- **CORS Configuration** for API security
- **Input Validation** and sanitization

## Deployment Architecture

### Development Environment
- **Local Development** server with hot reload
- **Environment Variables** for configuration
- **TypeScript** compilation with error checking
- **ESLint/Prettier** for code quality

### Production Environment
- **Supabase Cloud** hosting for backend
- **Edge Functions** deployment for serverless backend
- **CDN Delivery** for static assets
- **SSL/TLS** encryption for all communications

## Migration Guide (Laravel/MySQL)

If you need to migrate to Laravel/MySQL in the future, here's what would be required:

### Backend Migration
1. **Laravel Installation** and project setup
2. **MySQL Database** configuration
3. **Migration Files** creation for all data structures
4. **Eloquent Models** for data relationships
5. **API Controllers** to replace Supabase Edge Functions
6. **Authentication System** using Laravel Sanctum or Passport

### Database Migration
1. **Export Data** from Supabase/PostgreSQL
2. **Create MySQL** equivalent tables
3. **Data Transformation** and import
4. **Index Optimization** for performance
5. **Relationship Setup** using foreign keys

### Frontend Changes
1. **API Endpoint Updates** to point to Laravel backend
2. **Authentication Flow** changes for Laravel
3. **Data Format** adjustments if needed
4. **Environment Configuration** updates

## Maintenance and Updates

### Regular Maintenance
- **Database Backup** and recovery procedures
- **Security Updates** for all dependencies
- **Performance Monitoring** and optimization
- **User Access Reviews** and role updates

### Feature Updates
- **Version Control** with Git
- **Testing Strategy** for new features
- **Deployment Pipeline** for updates
- **Rollback Procedures** for issues

### Monitoring and Analytics
- **Error Logging** and tracking
- **Performance Metrics** monitoring
- **User Activity** analytics
- **System Health** checks

## Support and Documentation

### For Developers
- **Code Documentation** with JSDoc comments
- **API Documentation** with examples
- **Database Schema** documentation
- **Deployment Guide** with step-by-step instructions

### For Users
- **User Manual** for each role level
- **Training Materials** for system usage
- **Help Documentation** and FAQs
- **Contact Information** for technical support

### For Administrators
- **System Administration** guide
- **User Management** procedures
- **Backup and Recovery** protocols
- **Security Best Practices** guidelines