# BPDB Portal Testing Guide

## Overview
This guide provides comprehensive instructions for testing the enhanced BPDB Portal registration system, two-factor authentication, and user profile management features.

## Test Access
Click the "Test Registration" button in the bottom-right corner of the public website to access the testing interface.

## 1. Enhanced Registration Form Testing

### Features to Test
- **Comprehensive Role Selection**: 60+ roles from operators to executives
- **Department Selection**: 31 departments covering all BPDB operations
- **Power Plant Selection**: 40+ power plants including major installations and substations
- **Real-time Validation**: Form validation and error handling
- **Auto-login**: Automatic login after successful registration

### Test Steps
1. Navigate to the registration form
2. Fill in all required fields:
   - Full Name
   - Email Address
   - Role/Designation (required)
   - Department (optional)
   - Power Plant (optional)
   - Password and confirmation
3. Test dropdown functionality:
   - Role dropdown should show all 60+ roles
   - Department dropdown should show all 31 departments
   - Power Plant dropdown should show all 40+ facilities
4. Test validation:
   - Try submitting with empty required fields
   - Test password mismatch
   - Test invalid email format
5. Complete registration and verify auto-login

### Expected Results
- All dropdowns should populate with comprehensive options
- Form validation should work properly
- Successful registration should automatically log in the user
- User should be redirected to the appropriate dashboard based on role level

## 2. Two-Factor Authentication Testing

### Features to Test
- **Email-based 2FA**: 6-digit verification codes
- **SMS-based 2FA**: Phone number verification (simulated)
- **Code Expiration**: 5-minute timeout
- **Retry Logic**: Code resending and attempt limits
- **Auto-verification**: Automatic submission when all digits are entered

### Test Steps
1. After login, click on "Security Verification" in the user menu
2. Select verification method (email/SMS)
3. Enter the 6-digit code (check console for test code)
4. Test various scenarios:
   - Correct code entry
   - Incorrect code entry
   - Expired code (wait 5 minutes)
   - Multiple failed attempts
   - Code resending

### Expected Results
- Verification code should be sent (check console for test code)
- Valid codes should verify successfully
- Invalid codes should show error messages
- Expired codes should prompt for new code
- Too many failed attempts should lock the verification

## 3. User Profile Management Testing

### Features to Test
- **Profile Information**: Name, email, phone, role, department, power plant
- **Password Changes**: Current password verification and new password setting
- **Security Settings**: 2FA toggle, notifications, login alerts
- **Role Updates**: Changing roles and departments (with proper permissions)
- **Real-time Updates**: Changes reflected immediately in the interface

### Test Steps
1. Access profile management through "Profile & Settings" in user menu
2. Test Profile Tab:
   - Enable editing mode
   - Update personal information
   - Change role/department (if allowed)
   - Save changes and verify updates
3. Test Security Tab:
   - Change password (test current password validation)
   - Toggle security settings
   - Update and verify changes
4. Test Preferences Tab:
   - View account information
   - Check permission levels and status

### Expected Results
- All profile information should be editable (based on permissions)
- Password changes should require current password verification
- Security settings should save and persist
- Changes should be reflected immediately in the dashboard

## 4. Password Reset System Testing

### Features to Test
- **Forgot Password**: Email-based password reset requests
- **Reset Links**: Secure token-based password reset
- **New Password**: Password strength validation and confirmation
- **Security**: Expired links and single-use tokens

### Test Steps
1. From login screen, click "Forgot your password?"
2. Enter registered email address
3. Check for reset confirmation (simulated)
4. Test password reset form:
   - Strong password requirements
   - Password confirmation matching
   - Form validation
5. Complete reset and test login with new password

### Expected Results
- Reset email should be "sent" (simulated)
- Reset form should validate password requirements
- New password should work for subsequent logins
- Old password should no longer work

## 5. Role-Based Access Control Testing

### Features to Test
- **Dashboard Content**: Different content based on user level
- **Menu Items**: Role-appropriate navigation options
- **Permissions**: Access restrictions for different features
- **Data Visibility**: Role-based data filtering

### Test Steps
1. Register users with different roles:
   - Executive (Level 8+): Chairman, Managing Director, Directors
   - Manager (Level 6-7): General Managers, Deputy General Managers
   - Senior (Level 4-5): Senior Engineers, AGMs
   - Regular (Level 1-3): Engineers, Operators, Technicians
2. Test dashboard access for each level:
   - Executive: Should see all departments and plants
   - Manager: Should see department-specific data
   - Senior: Should see project and team data
   - Regular: Should see personal and assigned tasks
3. Verify menu restrictions and data access

### Expected Results
- Higher-level users should have more menu options
- Data visibility should match user permissions
- Unauthorized access should be properly blocked
- Role changes should immediately update permissions

## 6. Security Features Testing

### Features to Test
- **Session Management**: Auto-logout and session timeouts
- **Authentication State**: Persistent login across browser sessions
- **Security Headers**: Proper API authentication
- **Data Protection**: Sensitive information handling

### Test Steps
1. Test session persistence:
   - Login and refresh browser
   - Close and reopen browser
   - Wait for session timeout
2. Test logout functionality:
   - Manual logout
   - Session expiration
   - Multiple device handling
3. Test API security:
   - Verify all requests use proper authentication
   - Test unauthorized access attempts

### Expected Results
- Sessions should persist appropriately
- Logout should clear all authentication data
- Unauthorized requests should be properly rejected
- Sensitive data should be protected

## 7. User Interface Testing

### Features to Test
- **Glassmorphism Design**: Backdrop blur and transparency effects
- **Dark/Light Mode**: Theme switching and persistence
- **Responsive Design**: Mobile and desktop compatibility
- **Animations**: Smooth transitions and loading states

### Test Steps
1. Test theme switching:
   - Toggle between light and dark modes
   - Verify theme persistence across sessions
2. Test responsive design:
   - Resize browser window
   - Test on different screen sizes
   - Verify mobile compatibility
3. Test animations and transitions:
   - Form transitions
   - Loading states
   - Modal animations

### Expected Results
- Themes should switch smoothly and persist
- Interface should adapt to different screen sizes
- Animations should be smooth and purposeful
- All interactive elements should provide feedback

## 8. Error Handling Testing

### Features to Test
- **Network Errors**: Connection failures and timeouts
- **Validation Errors**: Form validation and user feedback
- **Authentication Errors**: Invalid credentials and expired sessions
- **Permission Errors**: Unauthorized access attempts

### Test Steps
1. Test network error scenarios:
   - Disconnect internet during form submission
   - Test slow network conditions
2. Test validation errors:
   - Submit forms with invalid data
   - Test edge cases and boundary conditions
3. Test authentication errors:
   - Use expired tokens
   - Attempt unauthorized operations
4. Test error recovery:
   - Retry failed operations
   - Verify error messages are helpful

### Expected Results
- All errors should be handled gracefully
- Error messages should be clear and actionable
- Users should be able to recover from error states
- Critical operations should not fail silently

## Performance Testing

### Metrics to Monitor
- **Load Times**: Initial page load and navigation
- **API Response**: Backend response times
- **Form Submission**: Registration and update speeds
- **Memory Usage**: Browser memory consumption

### Tools for Testing
- Browser Developer Tools
- Network throttling
- Performance monitoring
- Memory profiling

### Expected Performance
- Initial load: < 3 seconds
- Form submissions: < 2 seconds
- API responses: < 1 second
- Smooth animations at 60fps

## Troubleshooting Common Issues

### Registration Issues
- **Dropdown not loading**: Check network connection and server status
- **Validation errors**: Verify all required fields are completed
- **Auto-login failing**: Check password confirmation and try manual login

### 2FA Issues
- **Code not received**: Check console for test code (development mode)
- **Code expired**: Request new code and enter quickly
- **Verification failing**: Ensure all 6 digits are entered correctly

### Profile Management Issues
- **Changes not saving**: Check network connection and permissions
- **Password change failing**: Verify current password is correct
- **Role updates not allowed**: Check user permission level

### General Issues
- **Interface not loading**: Clear browser cache and refresh
- **Theme issues**: Toggle theme or check browser compatibility
- **Performance issues**: Check browser resources and close other tabs

## Test Data Suggestions

### Test Users to Create
1. **Executive User**:
   - Role: Chairman or Managing Director
   - Department: ALL
   - Should have full system access

2. **Department Manager**:
   - Role: GM Generation or similar
   - Department: GENERATION
   - Should have department-specific access

3. **Plant Operator**:
   - Role: Plant Operator
   - Power Plant: Select any facility
   - Should have limited, plant-specific access

4. **Regular Employee**:
   - Role: Engineer or Officer
   - Department: Any specific department
   - Should have basic user access

### Test Scenarios
1. **New User Registration**: Complete end-to-end registration
2. **Role Change**: Update user role and verify permission changes
3. **Department Transfer**: Change user department and test access
4. **Security Update**: Enable 2FA and test various security settings
5. **Password Recovery**: Use forgot password and reset password flow

## Reporting Issues

When reporting issues, please include:
- **Steps to reproduce**: Detailed reproduction steps
- **Expected vs actual**: What should happen vs what actually happens
- **Browser information**: Browser type and version
- **Console errors**: Any JavaScript errors or warnings
- **Network information**: Any failed API requests

## Success Criteria

The system passes testing if:
- All registration form dropdowns populate correctly
- User authentication and authorization work properly
- Profile management functions operate as expected
- Security features provide appropriate protection
- The interface is responsive and user-friendly
- Error handling provides good user experience
- Performance meets acceptable standards

## Next Steps

After successful testing:
1. **Production Deployment**: Prepare for live environment
2. **User Training**: Develop training materials for end users
3. **Monitoring Setup**: Implement production monitoring
4. **Documentation**: Create user manuals and admin guides
5. **Maintenance Plan**: Establish ongoing maintenance procedures