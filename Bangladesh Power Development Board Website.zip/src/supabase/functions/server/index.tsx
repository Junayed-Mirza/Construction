import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'npm:@supabase/supabase-js@2'
import * as kv from './kv_store.tsx'

const app = new Hono()

// CORS configuration
app.use('*', cors({
  origin: [
    'https://figma.com', 
    'https://www.figma.com', 
    /^https:\/\/[\w-]+\.figma\.com$/,
    'http://localhost:3000',
    'http://localhost:5173',
    'http://127.0.0.1:3000',
    'http://127.0.0.1:5173'
  ],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  credentials: true,
}))

app.use('*', logger(console.log))

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
)

// User roles and departments configuration
const USER_ROLES = {
  // Executive Level
  'Chairman': { level: 10, departments: ['ALL'] },
  'Managing Director': { level: 9, departments: ['ALL'] },
  'Director (Generation)': { level: 8, departments: ['GENERATION'] },
  'Director (Transmission)': { level: 8, departments: ['TRANSMISSION'] },
  'Director (Distribution)': { level: 8, departments: ['DISTRIBUTION'] },
  'Director (Finance)': { level: 8, departments: ['FINANCE'] },
  'Director (HR)': { level: 8, departments: ['HR'] },
  'Director (Planning)': { level: 8, departments: ['PLANNING'] },
  
  // General Managers
  'GM Generation': { level: 7, departments: ['GENERATION'] },
  'GM Transmission': { level: 7, departments: ['TRANSMISSION'] },
  'GM Distribution': { level: 7, departments: ['DISTRIBUTION'] },
  'GM Finance': { level: 7, departments: ['FINANCE'] },
  'GM HR': { level: 7, departments: ['HR'] },
  'GM Planning': { level: 7, departments: ['PLANNING'] },
  'GM Operations': { level: 7, departments: ['OPERATIONS'] },
  'GM Maintenance': { level: 7, departments: ['MAINTENANCE'] },
  'GM IT': { level: 7, departments: ['IT'] },
  'GM Audit': { level: 7, departments: ['AUDIT'] },
  
  // Deputy General Managers
  'DGM Generation': { level: 6, departments: ['GENERATION'] },
  'DGM Transmission': { level: 6, departments: ['TRANSMISSION'] },
  'DGM Distribution': { level: 6, departments: ['DISTRIBUTION'] },
  'DGM Finance': { level: 6, departments: ['FINANCE'] },
  'DGM HR': { level: 6, departments: ['HR'] },
  'DGM Planning': { level: 6, departments: ['PLANNING'] },
  'DGM Operations': { level: 6, departments: ['OPERATIONS'] },
  'DGM Maintenance': { level: 6, departments: ['MAINTENANCE'] },
  'DGM IT': { level: 6, departments: ['IT'] },
  'DGM Audit': { level: 6, departments: ['AUDIT'] },
  
  // Assistant General Managers
  'AGM Generation': { level: 5, departments: ['GENERATION'] },
  'AGM Transmission': { level: 5, departments: ['TRANSMISSION'] },
  'AGM Distribution': { level: 5, departments: ['DISTRIBUTION'] },
  'AGM Finance': { level: 5, departments: ['FINANCE'] },
  'AGM HR': { level: 5, departments: ['HR'] },
  'AGM Planning': { level: 5, departments: ['PLANNING'] },
  'AGM Operations': { level: 5, departments: ['OPERATIONS'] },
  'AGM Maintenance': { level: 5, departments: ['MAINTENANCE'] },
  'AGM IT': { level: 5, departments: ['IT'] },
  'AGM Audit': { level: 5, departments: ['AUDIT'] },
  
  // Senior Level Engineers/Officers
  'Chief Engineer': { level: 4, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION', 'PLANNING'] },
  'Senior Engineer (Electrical)': { level: 4, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Senior Engineer (Mechanical)': { level: 4, departments: ['GENERATION', 'MAINTENANCE'] },
  'Senior Engineer (Civil)': { level: 4, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Senior Engineer (Control & Instrumentation)': { level: 4, departments: ['GENERATION', 'OPERATIONS'] },
  'Senior System Analyst': { level: 4, departments: ['IT'] },
  'Senior Financial Officer': { level: 4, departments: ['FINANCE'] },
  'Senior HR Officer': { level: 4, departments: ['HR'] },
  'Senior Planning Officer': { level: 4, departments: ['PLANNING'] },
  'Senior Audit Officer': { level: 4, departments: ['AUDIT'] },
  
  // Engineers/Officers
  'Engineer (Electrical)': { level: 3, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Engineer (Mechanical)': { level: 3, departments: ['GENERATION', 'MAINTENANCE'] },
  'Engineer (Civil)': { level: 3, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Engineer (Control & Instrumentation)': { level: 3, departments: ['GENERATION', 'OPERATIONS'] },
  'Engineer (Electronics)': { level: 3, departments: ['GENERATION', 'TRANSMISSION', 'IT'] },
  'System Analyst': { level: 3, departments: ['IT'] },
  'Financial Officer': { level: 3, departments: ['FINANCE'] },
  'HR Officer': { level: 3, departments: ['HR'] },
  'Planning Officer': { level: 3, departments: ['PLANNING'] },
  'Audit Officer': { level: 3, departments: ['AUDIT'] },
  'Operations Officer': { level: 3, departments: ['OPERATIONS'] },
  'Maintenance Officer': { level: 3, departments: ['MAINTENANCE'] },
  
  // Assistant Level
  'Assistant Engineer (Electrical)': { level: 2, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Assistant Engineer (Mechanical)': { level: 2, departments: ['GENERATION', 'MAINTENANCE'] },
  'Assistant Engineer (Civil)': { level: 2, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Assistant Engineer (Control & Instrumentation)': { level: 2, departments: ['GENERATION', 'OPERATIONS'] },
  'Assistant System Analyst': { level: 2, departments: ['IT'] },
  'Assistant Financial Officer': { level: 2, departments: ['FINANCE'] },
  'Assistant HR Officer': { level: 2, departments: ['HR'] },
  'Assistant Planning Officer': { level: 2, departments: ['PLANNING'] },
  'Assistant Audit Officer': { level: 2, departments: ['AUDIT'] },
  'Assistant Operations Officer': { level: 2, departments: ['OPERATIONS'] },
  'Assistant Maintenance Officer': { level: 2, departments: ['MAINTENANCE'] },
  
  // Operators and Technical Staff
  'Chief Plant Operator': { level: 2, departments: ['GENERATION'] },
  'Senior Plant Operator': { level: 1, departments: ['GENERATION'] },
  'Plant Operator': { level: 1, departments: ['GENERATION'] },
  'Control Room Operator': { level: 1, departments: ['GENERATION', 'TRANSMISSION'] },
  'Substation Operator': { level: 1, departments: ['TRANSMISSION', 'DISTRIBUTION'] },
  'Senior Technician': { level: 1, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION', 'MAINTENANCE'] },
  'Technician (Electrical)': { level: 1, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Technician (Mechanical)': { level: 1, departments: ['GENERATION', 'MAINTENANCE'] },
  'Technician (Instrumentation)': { level: 1, departments: ['GENERATION', 'OPERATIONS'] },
  'IT Support Technician': { level: 1, departments: ['IT'] },
  'Lab Technician': { level: 1, departments: ['GENERATION', 'MAINTENANCE'] },
  'Safety Officer': { level: 2, departments: ['ALL'] },
  'Security Officer': { level: 1, departments: ['ALL'] },
  'Data Entry Operator': { level: 1, departments: ['ALL'] },
  'Administrative Assistant': { level: 1, departments: ['ALL'] },
  'Accounts Assistant': { level: 1, departments: ['FINANCE'] },
  'Store Keeper': { level: 1, departments: ['ALL'] },
  'Driver': { level: 1, departments: ['ALL'] }
}

const POWER_PLANTS = [
  // Major Power Plants
  'Barapukuria Coal Power Plant (525 MW)',
  'Payra Coal Power Plant (1320 MW)',
  'Rampal Coal Power Plant (1320 MW)',
  'Rooppur Nuclear Power Plant (2400 MW)',
  'Matarbari Coal Power Plant (1200 MW)',
  
  // Gas-fired Power Plants
  'Ashuganj Power Plant (450 MW)',
  'Ghorashal Power Plant (210 MW)',
  'Siddhirganj Power Plant (150 MW)',
  'Raozan Power Plant (52.5 MW)',
  'Khulna Power Plant (210 MW)',
  'Barisal Power Plant (150 MW)',
  'Sylhet Power Plant (150 MW)',
  'Rangpur Power Plant (210 MW)',
  'Comilla Power Plant (60 MW)',
  'Mymensingh Power Plant (210 MW)',
  
  // Dual Fuel Power Plants
  'Ashuganj South Power Plant (450 MW)',
  'Meghnaghat Power Plant (450 MW)',
  'Haripur Power Plant (360 MW)',
  'Keraniganj Power Plant (190 MW)',
  'Bhola Power Plant (225 MW)',
  
  // Furnace Oil Power Plants
  'Ghorashal Unit 6 (210 MW)',
  'Ashuganj Unit 3 & 4 (210 MW)',
  'Shahjibazar Peaking Power Plant (210 MW)',
  
  // Small Power Plants
  'Shikalbaha Power Plant (150 MW)',
  'Shahjibazar Power Plant (150 MW)',
  'Sirajganj Power Plant (450 MW)',
  'Bheramara Combined Cycle Power Plant (410 MW)',
  
  // Renewable Energy
  'Kaptai Hydro Power Plant (230 MW)',
  'Solar Power Plant (50 MW)',
  'Wind Power Plant (60 MW)',
  
  // Distribution Substations
  'Ashuganj 230kV Substation',
  'Comilla 230kV Substation',
  'Cumilla 132kV Substation',
  'Dhaka 230kV Substation',
  'Bogra 230kV Substation',
  'Rangpur 230kV Substation',
  'Sylhet 230kV Substation',
  'Barisal 230kV Substation',
  'Khulna 230kV Substation',
  'Chittagong 230kV Substation',
  
  // Grid Substations
  'Maddhapara 132kV Substation',
  'Tongi 132kV Substation',
  'Siddhirganj 132kV Substation',
  'Ghorashal 132kV Substation',
  'Meghnaghat 132kV Substation',
  'Haripur 132kV Substation',
  'Keraniganj 132kV Substation',
  'Bhola 132kV Substation'
]

const DEPARTMENTS = [
  'GENERATION',
  'TRANSMISSION', 
  'DISTRIBUTION',
  'FINANCE & ACCOUNTS',
  'HUMAN RESOURCES',
  'PLANNING & DEVELOPMENT',
  'MAINTENANCE & ENGINEERING',
  'OPERATIONS & CONTROL',
  'INFORMATION TECHNOLOGY',
  'AUDIT & INSPECTION',
  'PROCUREMENT & LOGISTICS',
  'SAFETY & ENVIRONMENT',
  'LEGAL & REGULATORY',
  'CORPORATE AFFAIRS',
  'TRAINING & DEVELOPMENT',
  'QUALITY ASSURANCE',
  'PROJECT MANAGEMENT',
  'RESEARCH & DEVELOPMENT',
  'CUSTOMER SERVICES',
  'SECURITY SERVICES',
  'TRANSPORT & VEHICLE',
  'STORE & INVENTORY',
  'CONSTRUCTION & CIVIL',
  'ELECTRICAL MAINTENANCE',
  'MECHANICAL MAINTENANCE',
  'INSTRUMENTATION & CONTROL',
  'COMMUNICATION & TELECOM',
  'COAL HANDLING',
  'WATER TREATMENT',
  'LABORATORY SERVICES',
  'GENERAL ADMINISTRATION'
]

// Configuration endpoint
app.get('/make-server-cb8f959e/config', async (c) => {
  try {
    return c.json({
      roles: Object.keys(USER_ROLES),
      departments: DEPARTMENTS,
      powerPlants: POWER_PLANTS
    })
  } catch (error) {
    console.log(`Config fetch error: ${error}`)
    return c.json({ error: 'Failed to fetch configuration' }, 500)
  }
})

// Password Reset Request
app.post('/make-server-cb8f959e/auth/forgot-password', async (c) => {
  try {
    const { email } = await c.req.json()
    
    if (!email) {
      return c.json({ error: 'Email is required' }, 400)
    }

    const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: 'https://figma.com/make/reset-password'
    })

    if (error) {
      console.log(`Password reset error: ${error.message}`)
      return c.json({ error: 'Failed to send reset email' }, 400)
    }

    return c.json({ 
      message: 'Password reset email sent. Please check your inbox.',
      data 
    })
  } catch (error) {
    console.log(`Password reset request error: ${error}`)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Password Reset Confirmation
app.post('/make-server-cb8f959e/auth/reset-password', async (c) => {
  try {
    const { accessToken, newPassword } = await c.req.json()
    
    if (!accessToken || !newPassword) {
      return c.json({ error: 'Access token and new password are required' }, 400)
    }

    const { data, error } = await supabase.auth.updateUser({
      password: newPassword
    })

    if (error) {
      console.log(`Password update error: ${error.message}`)
      return c.json({ error: 'Failed to update password' }, 400)
    }

    return c.json({ 
      message: 'Password updated successfully',
      user: data.user
    })
  } catch (error) {
    console.log(`Password reset confirmation error: ${error}`)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Authentication Routes
app.post('/make-server-cb8f959e/auth/register', async (c) => {
  try {
    const { email, password, name, role, department, powerPlant } = await c.req.json()
    
    if (!email || !password || !name || !role) {
      return c.json({ error: 'Missing required fields' }, 400)
    }

    if (!USER_ROLES[role]) {
      return c.json({ error: 'Invalid role' }, 400)
    }

    // Create user
    const { data: userData, error: userError } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { 
        name,
        role,
        department: department || 'GENERAL',
        powerPlant: powerPlant || null,
        level: USER_ROLES[role].level
      },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    })

    if (userError) {
      console.log(`User registration error: ${userError.message}`)
      return c.json({ error: userError.message }, 400)
    }

    // Store additional user data in KV store
    await kv.set(`user:${userData.user.id}`, {
      id: userData.user.id,
      email,
      name,
      role,
      department: department || 'GENERAL',
      powerPlant: powerPlant || null,
      level: USER_ROLES[role].level,
      createdAt: new Date().toISOString(),
      isActive: true
    })

    return c.json({ 
      message: 'User registered successfully',
      user: {
        id: userData.user.id,
        email,
        name,
        role,
        department: department || 'GENERAL',
        powerPlant
      }
    })
  } catch (error) {
    console.log(`Registration error: ${error}`)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Get user profile
app.get('/make-server-cb8f959e/auth/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'Invalid access token' }, 401)
    }

    // Get additional user data from KV store
    const userData = await kv.get(`user:${user.id}`)
    
    return c.json({
      user: {
        id: user.id,
        email: user.email,
        ...userData,
        permissions: getUserPermissions(userData?.role, userData?.department)
      }
    })
  } catch (error) {
    console.log(`Profile fetch error: ${error}`)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Dashboard data routes
app.get('/make-server-cb8f959e/dashboard/overview', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const userData = await kv.get(`user:${user.id}`)
    if (!userData) {
      return c.json({ error: 'User data not found' }, 404)
    }

    // Generate dashboard data based on user role and permissions
    const dashboardData = await generateDashboardData(userData.role, userData.department, userData.powerPlant)
    
    return c.json(dashboardData)
  } catch (error) {
    console.log(`Dashboard overview error: ${error}`)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Power generation data
app.get('/make-server-cb8f959e/data/generation', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    // Get power generation data
    let generationData = await kv.get('generation:current')
    if (!generationData) {
      // Initialize with sample data
      generationData = {
        totalGeneration: 15420,
        currentLoad: 14230,
        peakLoad: 16500,
        powerPlants: POWER_PLANTS.map(plant => ({
          name: plant,
          capacity: Math.floor(Math.random() * 2000) + 500,
          current: Math.floor(Math.random() * 1800) + 400,
          efficiency: Math.floor(Math.random() * 20) + 80,
          status: Math.random() > 0.1 ? 'online' : 'maintenance'
        })),
        lastUpdated: new Date().toISOString()
      }
      await kv.set('generation:current', generationData)
    }

    return c.json(generationData)
  } catch (error) {
    console.log(`Generation data error: ${error}`)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Department specific data
app.get('/make-server-cb8f959e/data/department/:dept', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const department = c.req.param('dept')
    const userData = await kv.get(`user:${user.id}`)
    
    if (!hasPermission(userData.role, userData.department, department)) {
      return c.json({ error: 'Insufficient permissions' }, 403)
    }

    const departmentData = await generateDepartmentData(department)
    return c.json(departmentData)
  } catch (error) {
    console.log(`Department data error: ${error}`)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Power plant specific data
app.get('/make-server-cb8f959e/data/powerplant/:plant', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const plant = c.req.param('plant')
    const userData = await kv.get(`user:${user.id}`)
    
    if (!hasPlantAccess(userData.role, userData.powerPlant, plant)) {
      return c.json({ error: 'Insufficient permissions' }, 403)
    }

    const plantData = await generatePowerPlantData(plant)
    return c.json(plantData)
  } catch (error) {
    console.log(`Power plant data error: ${error}`)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Utility functions
function getUserPermissions(role: string, department: string) {
  const roleInfo = USER_ROLES[role]
  if (!roleInfo) return []

  const permissions = []
  
  if (roleInfo.level >= 8) {
    permissions.push('view_all_departments', 'view_all_plants', 'manage_users', 'system_admin')
  } else if (roleInfo.level >= 6) {
    permissions.push('view_department', 'manage_department_users')
  } else if (roleInfo.level >= 4) {
    permissions.push('view_department', 'manage_projects')
  } else {
    permissions.push('view_assigned')
  }

  return permissions
}

function hasPermission(userRole: string, userDept: string, targetDept: string) {
  const roleInfo = USER_ROLES[userRole]
  if (!roleInfo) return false

  if (roleInfo.level >= 8) return true
  if (roleInfo.departments.includes('ALL')) return true
  if (roleInfo.departments.includes(targetDept)) return true
  if (userDept === targetDept) return true

  return false
}

function hasPlantAccess(userRole: string, userPlant: string, targetPlant: string) {
  const roleInfo = USER_ROLES[userRole]
  if (!roleInfo) return false

  if (roleInfo.level >= 7) return true
  if (userPlant === targetPlant) return true

  return false
}

async function generateDashboardData(role: string, department: string, powerPlant: string) {
  const roleInfo = USER_ROLES[role]
  
  const baseData = {
    role,
    department,
    powerPlant,
    level: roleInfo.level,
    widgets: []
  }

  // Add widgets based on role level
  if (roleInfo.level >= 8) {
    baseData.widgets = [
      'system_overview',
      'all_departments',
      'all_plants',
      'user_management',
      'financial_summary',
      'performance_metrics'
    ]
  } else if (roleInfo.level >= 6) {
    baseData.widgets = [
      'department_overview',
      'team_performance',
      'project_status',
      'resource_allocation'
    ]
  } else if (roleInfo.level >= 4) {
    baseData.widgets = [
      'project_dashboard',
      'team_status',
      'technical_metrics'
    ]
  } else {
    baseData.widgets = [
      'personal_dashboard',
      'assigned_tasks',
      'plant_status'
    ]
  }

  return baseData
}

async function generateDepartmentData(department: string) {
  return {
    department,
    overview: {
      totalStaff: Math.floor(Math.random() * 500) + 50,
      activeProjects: Math.floor(Math.random() * 20) + 5,
      budget: Math.floor(Math.random() * 1000000) + 100000,
      performance: Math.floor(Math.random() * 20) + 80
    },
    recentActivity: [
      { type: 'project_update', message: 'New project milestone reached', timestamp: new Date().toISOString() },
      { type: 'staff_update', message: 'New team member joined', timestamp: new Date().toISOString() }
    ]
  }
}

async function generatePowerPlantData(plant: string) {
  return {
    plant,
    capacity: Math.floor(Math.random() * 2000) + 500,
    currentOutput: Math.floor(Math.random() * 1800) + 400,
    efficiency: Math.floor(Math.random() * 20) + 80,
    status: Math.random() > 0.1 ? 'operational' : 'maintenance',
    lastMaintenance: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
    nextMaintenance: new Date(Date.now() + Math.random() * 60 * 24 * 60 * 60 * 1000).toISOString(),
    staff: Math.floor(Math.random() * 50) + 20,
    alerts: Math.floor(Math.random() * 5)
  }
}

// Two-Factor Authentication Routes
app.post('/make-server-cb8f959e/auth/send-2fa', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { userId, method, contact } = await c.req.json()
    
    // Generate 6-digit verification code
    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString()
    
    // Store verification code with expiration (5 minutes)
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString()
    await kv.set(`2fa:${userId}:${method}`, {
      code: verificationCode,
      contact,
      expiresAt,
      attempts: 0
    })

    // In a real implementation, you would send SMS or email here
    console.log(`2FA Code for ${contact}: ${verificationCode}`)
    
    return c.json({ 
      message: `Verification code sent to ${method === 'email' ? 'email' : 'phone'}`,
      // For testing purposes, include the code in response (remove in production)
      testCode: verificationCode
    })
  } catch (error) {
    console.log(`2FA send error: ${error}`)
    return c.json({ error: 'Failed to send verification code' }, 500)
  }
})

app.post('/make-server-cb8f959e/auth/verify-2fa', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { userId, code, method } = await c.req.json()
    
    const stored2FA = await kv.get(`2fa:${userId}:${method}`)
    if (!stored2FA) {
      return c.json({ error: 'No verification code found' }, 400)
    }

    // Check if code has expired
    if (new Date() > new Date(stored2FA.expiresAt)) {
      await kv.del(`2fa:${userId}:${method}`)
      return c.json({ error: 'Verification code has expired' }, 400)
    }

    // Check attempts limit
    if (stored2FA.attempts >= 3) {
      await kv.del(`2fa:${userId}:${method}`)
      return c.json({ error: 'Too many failed attempts' }, 400)
    }

    // Verify code
    if (stored2FA.code !== code) {
      stored2FA.attempts += 1
      await kv.set(`2fa:${userId}:${method}`, stored2FA)
      return c.json({ error: 'Invalid verification code' }, 400)
    }

    // Success - clean up and update user
    await kv.del(`2fa:${userId}:${method}`)
    
    // Update user data with 2FA verification
    const userData = await kv.get(`user:${userId}`)
    if (userData) {
      userData.twoFactorVerified = true
      userData.lastVerification = new Date().toISOString()
      await kv.set(`user:${userId}`, userData)
    }

    return c.json({ 
      message: 'Verification successful',
      verified: true
    })
  } catch (error) {
    console.log(`2FA verification error: ${error}`)
    return c.json({ error: 'Verification failed' }, 500)
  }
})

// Profile Management Routes
app.put('/make-server-cb8f959e/auth/update-profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { userId, name, email, phone, role, department, powerPlant } = await c.req.json()
    
    // Validate role if provided
    if (role && !USER_ROLES[role]) {
      return c.json({ error: 'Invalid role' }, 400)
    }

    // Update Supabase user metadata
    const { error: updateError } = await supabase.auth.admin.updateUserById(userId, {
      email: email || user.email,
      user_metadata: {
        name,
        role,
        department,
        powerPlant,
        phone
      }
    })

    if (updateError) {
      return c.json({ error: updateError.message }, 400)
    }

    // Update KV store data
    const userData = await kv.get(`user:${userId}`) || {}
    const updatedUserData = {
      ...userData,
      name,
      email,
      phone,
      role,
      department,
      powerPlant,
      level: role ? USER_ROLES[role].level : userData.level,
      updatedAt: new Date().toISOString()
    }
    
    await kv.set(`user:${userId}`, updatedUserData)

    return c.json({ 
      message: 'Profile updated successfully',
      user: updatedUserData
    })
  } catch (error) {
    console.log(`Profile update error: ${error}`)
    return c.json({ error: 'Failed to update profile' }, 500)
  }
})

app.put('/make-server-cb8f959e/auth/change-password', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { currentPassword, newPassword } = await c.req.json()
    
    // Verify current password by attempting to sign in
    const { error: verifyError } = await supabase.auth.signInWithPassword({
      email: user.email!,
      password: currentPassword
    })

    if (verifyError) {
      return c.json({ error: 'Current password is incorrect' }, 400)
    }

    // Update password
    const { error: updateError } = await supabase.auth.admin.updateUserById(user.id, {
      password: newPassword
    })

    if (updateError) {
      return c.json({ error: updateError.message }, 400)
    }

    return c.json({ message: 'Password changed successfully' })
  } catch (error) {
    console.log(`Password change error: ${error}`)
    return c.json({ error: 'Failed to change password' }, 500)
  }
})

app.put('/make-server-cb8f959e/auth/update-security', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { userId, twoFactorEnabled, emailNotifications, loginAlerts, sessionTimeout } = await c.req.json()
    
    // Update user security settings in KV store
    const userData = await kv.get(`user:${userId}`) || {}
    const updatedUserData = {
      ...userData,
      twoFactorEnabled,
      emailNotifications,
      loginAlerts,
      sessionTimeout,
      securityUpdatedAt: new Date().toISOString()
    }
    
    await kv.set(`user:${userId}`, updatedUserData)

    return c.json({ 
      message: 'Security settings updated successfully',
      settings: {
        twoFactorEnabled,
        emailNotifications,
        loginAlerts,
        sessionTimeout
      }
    })
  } catch (error) {
    console.log(`Security update error: ${error}`)
    return c.json({ error: 'Failed to update security settings' }, 500)
  }
})

// Get system configuration
app.get('/make-server-cb8f959e/config', async (c) => {
  return c.json({
    roles: Object.keys(USER_ROLES),
    departments: DEPARTMENTS,
    powerPlants: POWER_PLANTS
  })
})

Deno.serve(app.fetch)