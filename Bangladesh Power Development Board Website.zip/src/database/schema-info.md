# Database Schema Information for BPDB Portal

## Important Note
This project uses **Supabase** (PostgreSQL) as the backend, not Laravel/MySQL. The database is managed through Supabase's interface and uses a key-value store for data persistence.

## Current Database Structure

### 1. Supabase Auth Users Table
Supabase automatically manages user authentication with the following structure:
```sql
-- This table is managed by Supabase Auth
CREATE TABLE auth.users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR UNIQUE NOT NULL,
  encrypted_password VARCHAR,
  email_confirmed_at TIMESTAMPTZ,
  invited_at TIMESTAMPTZ,
  confirmation_token VARCHAR,
  confirmation_sent_at TIMESTAMPTZ,
  recovery_token VARCHAR,
  recovery_sent_at TIMESTAMPTZ,
  email_change_token_new VARCHAR,
  email_change VARCHAR,
  email_change_sent_at TIMESTAMPTZ,
  last_sign_in_at TIMESTAMPTZ,
  raw_app_meta_data JSONB,
  raw_user_meta_data JSONB,
  is_super_admin BOOLEAN,
  created_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ,
  phone TEXT UNIQUE,
  phone_confirmed_at TIMESTAMPTZ,
  phone_change TEXT DEFAULT '',
  phone_change_token VARCHAR DEFAULT '',
  phone_change_sent_at TIMESTAMPTZ,
  confirmed_at TIMESTAMPTZ GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
  email_change_token_current VARCHAR DEFAULT '',
  email_change_confirm_status SMALLINT DEFAULT 0,
  banned_until TIMESTAMPTZ,
  reauthentication_token VARCHAR DEFAULT '',
  reauthentication_sent_at TIMESTAMPTZ,
  is_sso_user BOOLEAN NOT NULL DEFAULT false,
  deleted_at TIMESTAMPTZ
);
```

### 2. Key-Value Store Table
Used for storing application-specific data:
```sql
-- Table: kv_store_cb8f959e
CREATE TABLE IF NOT EXISTS kv_store_cb8f959e (
  key TEXT PRIMARY KEY,
  value JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

## Data Storage Structure

### User Profile Data
Stored in KV store with key pattern: `user:{user_id}`
```json
{
  "id": "uuid",
  "email": "user@example.com",
  "name": "Full Name",
  "role": "Engineer",
  "department": "GENERATION",
  "powerPlant": "Barapukuria Coal Power Plant (525 MW)",
  "level": 3,
  "createdAt": "2024-01-01T00:00:00.000Z",
  "isActive": true
}
```

### Generation Data
Stored in KV store with key: `generation:current`
```json
{
  "totalGeneration": 15420,
  "currentLoad": 14230,
  "peakLoad": 16500,
  "powerPlants": [
    {
      "name": "Plant Name",
      "capacity": 1000,
      "current": 850,
      "efficiency": 85,
      "status": "online"
    }
  ],
  "lastUpdated": "2024-01-01T00:00:00.000Z"
}
```

## Roles and Permissions

### Available Roles
- **Executive Level (Level 8-10)**
  - Chairman (Level 10)
  - Managing Director (Level 9)
  - Directors (Level 8)

- **General Managers (Level 7)**
  - GM Generation, Transmission, Distribution, Finance, HR, Planning, Operations, Maintenance, IT, Audit

- **Deputy General Managers (Level 6)**
  - DGM for all departments

- **Assistant General Managers (Level 5)**
  - AGM for all departments

- **Senior Level (Level 4)**
  - Chief Engineer, Senior Engineers, Senior Officers

- **Regular Level (Level 3)**
  - Engineers, Officers, System Analysts

- **Assistant Level (Level 2)**
  - Assistant Engineers, Assistant Officers

- **Operational Level (Level 1)**
  - Plant Operators, Technicians, Administrative Staff

### Departments
- GENERATION
- TRANSMISSION
- DISTRIBUTION
- FINANCE & ACCOUNTS
- HUMAN RESOURCES
- PLANNING & DEVELOPMENT
- MAINTENANCE & ENGINEERING
- OPERATIONS & CONTROL
- INFORMATION TECHNOLOGY
- AUDIT & INSPECTION
- PROCUREMENT & LOGISTICS
- SAFETY & ENVIRONMENT
- LEGAL & REGULATORY
- CORPORATE AFFAIRS
- TRAINING & DEVELOPMENT
- QUALITY ASSURANCE
- PROJECT MANAGEMENT
- RESEARCH & DEVELOPMENT
- CUSTOMER SERVICES
- SECURITY SERVICES
- TRANSPORT & VEHICLE
- STORE & INVENTORY
- CONSTRUCTION & CIVIL
- ELECTRICAL MAINTENANCE
- MECHANICAL MAINTENANCE
- INSTRUMENTATION & CONTROL
- COMMUNICATION & TELECOM
- COAL HANDLING
- WATER TREATMENT
- LABORATORY SERVICES
- GENERAL ADMINISTRATION

### Power Plants
- Major coal-fired plants (Barapukuria, Payra, Rampal, Matarbari)
- Nuclear plant (Rooppur)
- Gas-fired plants (Ashuganj, Ghorashal, etc.)
- Renewable energy facilities
- Distribution substations
- Grid substations

## If You Need MySQL/Laravel Equivalent

If you want to migrate this to Laravel/MySQL, here's the equivalent structure:

### Laravel Migration Files

#### create_users_table.php
```php
<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('role');
            $table->string('department')->nullable();
            $table->string('power_plant')->nullable();
            $table->integer('level')->default(1);
            $table->boolean('is_active')->default(true);
            $table->rememberToken();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('users');
    }
};
```

#### create_power_generation_data_table.php
```php
<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('power_generation_data', function (Blueprint $table) {
            $table->id();
            $table->decimal('total_generation', 10, 2);
            $table->decimal('current_load', 10, 2);
            $table->decimal('peak_load', 10, 2);
            $table->json('power_plants_data');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('power_generation_data');
    }
};
```

However, **this project is designed to work with Supabase**, and converting to Laravel would require significant restructuring of the entire application.