import { projectId, publicAnonKey } from '../supabase/info';

interface HealthCheckResult {
  isServerOnline: boolean;
  serverUrl: string;
  lastChecked: string;
  responseTime?: number;
  error?: string;
}

export async function checkServerHealth(): Promise<HealthCheckResult> {
  const startTime = Date.now();
  const serverUrl = `https://${projectId}.supabase.co/functions/v1/make-server-cb8f959e`;
  
  try {
    const response = await fetch(`${serverUrl}/config`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
        'Content-Type': 'application/json'
      },
      signal: AbortSignal.timeout(10000) // 10 second timeout
    });

    const responseTime = Date.now() - startTime;

    if (response.ok) {
      return {
        isServerOnline: true,
        serverUrl,
        lastChecked: new Date().toISOString(),
        responseTime
      };
    } else {
      return {
        isServerOnline: false,
        serverUrl,
        lastChecked: new Date().toISOString(),
        responseTime,
        error: `Server responded with status: ${response.status}`
      };
    }
  } catch (error) {
    const responseTime = Date.now() - startTime;
    
    return {
      isServerOnline: false,
      serverUrl,
      lastChecked: new Date().toISOString(),
      responseTime,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

export function getErrorMessage(error: any): string {
  if (error?.message?.includes('Failed to fetch')) {
    return 'Server is currently unavailable. The application will use fallback data.';
  }
  
  if (error?.message?.includes('timeout')) {
    return 'Server request timed out. Please check your internet connection.';
  }
  
  if (error?.message?.includes('Network request failed')) {
    return 'Network error. Please check your internet connection.';
  }
  
  return error?.message || 'An unexpected error occurred.';
}

export async function retryWithFallback<T>(
  primaryRequest: () => Promise<T>,
  fallbackData: T,
  maxRetries: number = 2
): Promise<{ data: T; isFromServer: boolean; error?: string }> {
  let lastError: any;
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const data = await primaryRequest();
      return { data, isFromServer: true };
    } catch (error) {
      lastError = error;
      console.warn(`Request attempt ${attempt + 1} failed:`, error);
      
      // Wait before retrying (exponential backoff)
      if (attempt < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempt) * 1000));
      }
    }
  }
  
  console.warn('All request attempts failed, using fallback data:', lastError);
  return { 
    data: fallbackData, 
    isFromServer: false, 
    error: getErrorMessage(lastError) 
  };
}