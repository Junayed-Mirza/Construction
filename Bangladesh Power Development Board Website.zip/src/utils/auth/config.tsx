// Authentication configuration and utilities

export const USER_ROLES = {
  // Executive Level
  'Chairman': { level: 10, departments: ['ALL'] },
  'Managing Director': { level: 9, departments: ['ALL'] },
  'Director (Generation)': { level: 8, departments: ['GENERATION'] },
  'Director (Transmission)': { level: 8, departments: ['TRANSMISSION'] },
  'Director (Distribution)': { level: 8, departments: ['DISTRIBUTION'] },
  'Director (Finance)': { level: 8, departments: ['FINANCE'] },
  'Director (HR)': { level: 8, departments: ['HR'] },
  'Director (Planning)': { level: 8, departments: ['PLANNING'] },
  
  // General Managers
  'GM Generation': { level: 7, departments: ['GENERATION'] },
  'GM Transmission': { level: 7, departments: ['TRANSMISSION'] },
  'GM Distribution': { level: 7, departments: ['DISTRIBUTION'] },
  'GM Finance': { level: 7, departments: ['FINANCE'] },
  'GM HR': { level: 7, departments: ['HR'] },
  'GM Planning': { level: 7, departments: ['PLANNING'] },
  'GM Operations': { level: 7, departments: ['OPERATIONS'] },
  'GM Maintenance': { level: 7, departments: ['MAINTENANCE'] },
  'GM IT': { level: 7, departments: ['IT'] },
  'GM Audit': { level: 7, departments: ['AUDIT'] },
  
  // Deputy General Managers
  'DGM Generation': { level: 6, departments: ['GENERATION'] },
  'DGM Transmission': { level: 6, departments: ['TRANSMISSION'] },
  'DGM Distribution': { level: 6, departments: ['DISTRIBUTION'] },
  'DGM Finance': { level: 6, departments: ['FINANCE'] },
  'DGM HR': { level: 6, departments: ['HR'] },
  'DGM Planning': { level: 6, departments: ['PLANNING'] },
  'DGM Operations': { level: 6, departments: ['OPERATIONS'] },
  'DGM Maintenance': { level: 6, departments: ['MAINTENANCE'] },
  'DGM IT': { level: 6, departments: ['IT'] },
  'DGM Audit': { level: 6, departments: ['AUDIT'] },
  
  // Assistant General Managers
  'AGM Generation': { level: 5, departments: ['GENERATION'] },
  'AGM Transmission': { level: 5, departments: ['TRANSMISSION'] },
  'AGM Distribution': { level: 5, departments: ['DISTRIBUTION'] },
  'AGM Finance': { level: 5, departments: ['FINANCE'] },
  'AGM HR': { level: 5, departments: ['HR'] },
  'AGM Planning': { level: 5, departments: ['PLANNING'] },
  'AGM Operations': { level: 5, departments: ['OPERATIONS'] },
  'AGM Maintenance': { level: 5, departments: ['MAINTENANCE'] },
  'AGM IT': { level: 5, departments: ['IT'] },
  'AGM Audit': { level: 5, departments: ['AUDIT'] },
  
  // Senior Level Engineers/Officers
  'Chief Engineer': { level: 4, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION', 'PLANNING'] },
  'Senior Engineer (Electrical)': { level: 4, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Senior Engineer (Mechanical)': { level: 4, departments: ['GENERATION', 'MAINTENANCE'] },
  'Senior Engineer (Civil)': { level: 4, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Senior Engineer (Control & Instrumentation)': { level: 4, departments: ['GENERATION', 'OPERATIONS'] },
  'Senior System Analyst': { level: 4, departments: ['IT'] },
  'Senior Financial Officer': { level: 4, departments: ['FINANCE'] },
  'Senior HR Officer': { level: 4, departments: ['HR'] },
  'Senior Planning Officer': { level: 4, departments: ['PLANNING'] },
  'Senior Audit Officer': { level: 4, departments: ['AUDIT'] },
  
  // Engineers/Officers
  'Engineer (Electrical)': { level: 3, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Engineer (Mechanical)': { level: 3, departments: ['GENERATION', 'MAINTENANCE'] },
  'Engineer (Civil)': { level: 3, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Engineer (Control & Instrumentation)': { level: 3, departments: ['GENERATION', 'OPERATIONS'] },
  'Engineer (Electronics)': { level: 3, departments: ['GENERATION', 'TRANSMISSION', 'IT'] },
  'System Analyst': { level: 3, departments: ['IT'] },
  'Financial Officer': { level: 3, departments: ['FINANCE'] },
  'HR Officer': { level: 3, departments: ['HR'] },
  'Planning Officer': { level: 3, departments: ['PLANNING'] },
  'Audit Officer': { level: 3, departments: ['AUDIT'] },
  'Operations Officer': { level: 3, departments: ['OPERATIONS'] },
  'Maintenance Officer': { level: 3, departments: ['MAINTENANCE'] },
  
  // Assistant Level
  'Assistant Engineer (Electrical)': { level: 2, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Assistant Engineer (Mechanical)': { level: 2, departments: ['GENERATION', 'MAINTENANCE'] },
  'Assistant Engineer (Civil)': { level: 2, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Assistant Engineer (Control & Instrumentation)': { level: 2, departments: ['GENERATION', 'OPERATIONS'] },
  'Assistant System Analyst': { level: 2, departments: ['IT'] },
  'Assistant Financial Officer': { level: 2, departments: ['FINANCE'] },
  'Assistant HR Officer': { level: 2, departments: ['HR'] },
  'Assistant Planning Officer': { level: 2, departments: ['PLANNING'] },
  'Assistant Audit Officer': { level: 2, departments: ['AUDIT'] },
  'Assistant Operations Officer': { level: 2, departments: ['OPERATIONS'] },
  'Assistant Maintenance Officer': { level: 2, departments: ['MAINTENANCE'] },
  
  // Operators and Technical Staff
  'Chief Plant Operator': { level: 2, departments: ['GENERATION'] },
  'Senior Plant Operator': { level: 1, departments: ['GENERATION'] },
  'Plant Operator': { level: 1, departments: ['GENERATION'] },
  'Control Room Operator': { level: 1, departments: ['GENERATION', 'TRANSMISSION'] },
  'Substation Operator': { level: 1, departments: ['TRANSMISSION', 'DISTRIBUTION'] },
  'Senior Technician': { level: 1, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION', 'MAINTENANCE'] },
  'Technician (Electrical)': { level: 1, departments: ['GENERATION', 'TRANSMISSION', 'DISTRIBUTION'] },
  'Technician (Mechanical)': { level: 1, departments: ['GENERATION', 'MAINTENANCE'] },
  'Technician (Instrumentation)': { level: 1, departments: ['GENERATION', 'OPERATIONS'] },
  'IT Support Technician': { level: 1, departments: ['IT'] },
  'Lab Technician': { level: 1, departments: ['GENERATION', 'MAINTENANCE'] },
  'Safety Officer': { level: 2, departments: ['ALL'] },
  'Security Officer': { level: 1, departments: ['ALL'] },
  'Data Entry Operator': { level: 1, departments: ['ALL'] },
  'Administrative Assistant': { level: 1, departments: ['ALL'] },
  'Accounts Assistant': { level: 1, departments: ['FINANCE'] },
  'Store Keeper': { level: 1, departments: ['ALL'] },
  'Driver': { level: 1, departments: ['ALL'] }
};

export const POWER_PLANTS = [
  // Major Power Plants
  'Barapukuria Coal Power Plant (525 MW)',
  'Payra Coal Power Plant (1320 MW)',
  'Rampal Coal Power Plant (1320 MW)',
  'Rooppur Nuclear Power Plant (2400 MW)',
  'Matarbari Coal Power Plant (1200 MW)',
  
  // Gas-fired Power Plants
  'Ashuganj Power Plant (450 MW)',
  'Ghorashal Power Plant (210 MW)',
  'Siddhirganj Power Plant (150 MW)',
  'Raozan Power Plant (52.5 MW)',
  'Khulna Power Plant (210 MW)',
  'Barisal Power Plant (150 MW)',
  'Sylhet Power Plant (150 MW)',
  'Rangpur Power Plant (210 MW)',
  'Comilla Power Plant (60 MW)',
  'Mymensingh Power Plant (210 MW)',
  
  // Dual Fuel Power Plants
  'Ashuganj South Power Plant (450 MW)',
  'Meghnaghat Power Plant (450 MW)',
  'Haripur Power Plant (360 MW)',
  'Keraniganj Power Plant (190 MW)',
  'Bhola Power Plant (225 MW)',
  
  // Furnace Oil Power Plants
  'Ghorashal Unit 6 (210 MW)',
  'Ashuganj Unit 3 & 4 (210 MW)',
  'Shahjibazar Peaking Power Plant (210 MW)',
  
  // Small Power Plants
  'Shikalbaha Power Plant (150 MW)',
  'Shahjibazar Power Plant (150 MW)',
  'Sirajganj Power Plant (450 MW)',
  'Bheramara Combined Cycle Power Plant (410 MW)',
  
  // Renewable Energy
  'Kaptai Hydro Power Plant (230 MW)',
  'Solar Power Plant (50 MW)',
  'Wind Power Plant (60 MW)',
  
  // Distribution Substations
  'Ashuganj 230kV Substation',
  'Comilla 230kV Substation',
  'Cumilla 132kV Substation',
  'Dhaka 230kV Substation',
  'Bogra 230kV Substation',
  'Rangpur 230kV Substation',
  'Sylhet 230kV Substation',
  'Barisal 230kV Substation',
  'Khulna 230kV Substation',
  'Chittagong 230kV Substation',
  
  // Grid Substations
  'Maddhapara 132kV Substation',
  'Tongi 132kV Substation',
  'Siddhirganj 132kV Substation',
  'Ghorashal 132kV Substation',
  'Meghnaghat 132kV Substation',
  'Haripur 132kV Substation',
  'Keraniganj 132kV Substation',
  'Bhola 132kV Substation'
];

export const DEPARTMENTS = [
  'GENERATION',
  'TRANSMISSION', 
  'DISTRIBUTION',
  'FINANCE & ACCOUNTS',
  'HUMAN RESOURCES',
  'PLANNING & DEVELOPMENT',
  'MAINTENANCE & ENGINEERING',
  'OPERATIONS & CONTROL',
  'INFORMATION TECHNOLOGY',
  'AUDIT & INSPECTION',
  'PROCUREMENT & LOGISTICS',
  'SAFETY & ENVIRONMENT',
  'LEGAL & REGULATORY',
  'CORPORATE AFFAIRS',
  'TRAINING & DEVELOPMENT',
  'QUALITY ASSURANCE',
  'PROJECT MANAGEMENT',
  'RESEARCH & DEVELOPMENT',
  'CUSTOMER SERVICES',
  'SECURITY SERVICES',
  'TRANSPORT & VEHICLE',
  'STORE & INVENTORY',
  'CONSTRUCTION & CIVIL',
  'ELECTRICAL MAINTENANCE',
  'MECHANICAL MAINTENANCE',
  'INSTRUMENTATION & CONTROL',
  'COMMUNICATION & TELECOM',
  'COAL HANDLING',
  'WATER TREATMENT',
  'LABORATORY SERVICES',
  'GENERAL ADMINISTRATION'
];

// Helper functions
export function getRolesByDepartment(department: string): string[] {
  return Object.keys(USER_ROLES).filter(role => {
    const roleInfo = USER_ROLES[role as keyof typeof USER_ROLES];
    return roleInfo.departments.includes('ALL') || roleInfo.departments.includes(department);
  });
}

export function getDepartmentsByRole(role: string): string[] {
  const roleInfo = USER_ROLES[role as keyof typeof USER_ROLES];
  if (!roleInfo) return [];
  
  if (roleInfo.departments.includes('ALL')) {
    return DEPARTMENTS;
  }
  
  return roleInfo.departments;
}

export function getUserPermissions(role: string, department: string): string[] {
  const roleInfo = USER_ROLES[role as keyof typeof USER_ROLES];
  if (!roleInfo) return [];

  const permissions: string[] = [];
  
  if (roleInfo.level >= 8) {
    permissions.push('view_all_departments', 'view_all_plants', 'manage_users', 'system_admin');
  } else if (roleInfo.level >= 6) {
    permissions.push('view_department', 'manage_department_users');
  } else if (roleInfo.level >= 4) {
    permissions.push('view_department', 'manage_projects');
  } else {
    permissions.push('view_assigned');
  }

  return permissions;
}

export function validateUserRole(role: string): boolean {
  return role in USER_ROLES;
}

export function validateDepartment(department: string): boolean {
  return DEPARTMENTS.includes(department);
}

export function validatePowerPlant(plant: string): boolean {
  return POWER_PLANTS.includes(plant);
}