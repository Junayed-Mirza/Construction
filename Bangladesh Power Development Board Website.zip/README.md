
  # Bangladesh Power Development Board Website

  This is a code bundle for Bangladesh Power Development Board Website. The original project is available at https://www.figma.com/design/dWQqgbRbUcZHryLIkMDemq/Bangladesh-Power-Development-Board-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  